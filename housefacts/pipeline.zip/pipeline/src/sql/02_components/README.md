# HouseFacts Data Components

**HouseFacts Data Components:**
* Geographic Features
* Renovations
* Property Demographics
* Business Firmographics

***
### Geographic Features

* GeoIDs
* Weather / Risks
* USCB Census - (A)merican (C)ommunity (S)urvey
* Competitive Index (TSI)

***
### Renovations

* Installations
* Projects
* Building Permits

***
### Property Demographics

* Tax Assessments
* Deeds
* Mortgage/Equity
* MLS Listings

***
### Business Firmographics

* Dunn & Bradstreet Business Data

***
