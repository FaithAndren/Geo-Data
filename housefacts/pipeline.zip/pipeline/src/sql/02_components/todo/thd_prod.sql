/* =====================================================================
  Create Date:    
  As of Date:     

  Purpose:        Create a CLIP x subclass x-ref table of specific
                  products, e.g. tools, that be great to know exist at
                  the property - if we know for a fact the person still
                  lives there - that were shipped to home.

  Steps:          1)  Grab all product COM lines that were STH/DEL
                  2)  

  Notes:          - To do:
                    -- '028-007' -- GENERATORS
                    -- '028-035' -- WALKS    (lawn mower)
                    -- '028-034' -- RIDERS   (lawn mower)
                    -- Etc.

  Enhancements?   - Need to remove THD stores that may have snuck in.

===================================================================== */

CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_pr.thd_prod_`
OPTIONS(
  DESCRIPTION="""
    Products known to be associated with property. Shipped to home and
    purchaser is still an owner of the property, or the property hasn't
    been sold since the item was delivered (and the home isn't being 
    rented out).
    """
) AS
;

