/* =====================================================================
  Create Date:    2022-09-15    Faith Andren, Celine Wang
  As of Date:

  Purpose:        Create a table of the latest completed permit for HVAC
                  installation and the property address associated with it.
  Steps:          1) Grab the latest permit issued and completed from BUILDFAX_PERMITS
                     table
  Notes:          Permit data is from BuildFax, which collects the data from 19k
                  local authorities. Some jurisdictions report permits on an
                  automated basis at weekly or monthly cadence, but others are
                  manually collected at unpredictable cadence. THD has a daily
                  data pipeline landing permit information into EDW tables.
  Enhancements?   - confirm the definition and chronological order of permit status

===================================================================== */

CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_dev.building_permit_hvac`
  (   STRT STRING NOT NULL OPTIONS(DESCRIPTION = "Interally standardized street (addr 1 + addr 2)")
    , CITY_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Interally standardized city name")
    , ST_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Internally standardized state code")
    , PSTL_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Internally standardized postal code")
    , PERMIT_DT DATE NOT NULL OPTIONS(DESCRIPTION= "the applied date / status date of the permit is was received from the jurisdiction")
    , VAL_AMT_ORIG FLOAT64 NOT NULL OPTIONS(DESCRIPTION= "the original valuation amount of the permit")
    , VAL_AMT_EST FLOAT64 NOT NULL OPTIONS(DESCRIPTION= "the valuation amount estimate of the permit based on the geography, permit category, residential type, and number of contractors")
    , MATERIALS_EST FLOAT64 NOT NULL OPTIONS(DESCRIPTION= "percent estimate of the VAL_AMT_EST based on permit category and number of contractors")
  )
OPTIONS(
  DESCRIPTION="""
    the latest permit issued for HVAC
    Atomic Level: STRT, CITY_NM, ST_CD, PSTL_CD
    """
) AS


SELECT
  `analytics-views-thd.GEO.udf_strt_std`(PERMIT_ADDRESS, '') STRT
  , `analytics-views-thd.GEO.udf_clns_city`(PERMIT_CITY) AS CITY_NM
  , `analytics-views-thd.GEO.udf_clns_stcd`(PERMIT_STATE) AS ST_CD
  , `analytics-views-thd.GEO.udf_clns_zip`(PERMIT_ZIP) AS PSTL_CD
  , ARRAY_AGG(
      STRUCT(SAFE_CAST(PERMIT_DT AS DATE) AS HVAC_permit_date, VAL_AMT_ORIG, VAL_AMT_EST, MATERIALS_EST)
      ORDER BY PERMIT_DT DESC
      LIMIT 1
    )[SAFE_OFFSET(0)].*
FROM
  `pr-edw-views-thd.CUSTOMER_ANALYTICS_CONF.BUILDFAX_PERMITS`
WHERE 1=1
  -- HVAC Replacement
  AND (REGEXP_CONTAINS(PERMIT_DESC, '(?i)HVAC|HEATING VENT') OR PERMIT_CATEGORY = 'HVAC')
  -- Residential Property
  AND RESIDENTIAL_OR_COMMERCIAL = 'Residential'
  -- Completed ?? / Inspection Finaled / Done
  AND REGEXP_CONTAINS(PERMITSTATUS, '(?i)COMPLETE|FINAL|DONE|INSPECTION APPR')
  -- Material Filter for Reducing Noise
  AND MATERIALS_EST >= 1000
GROUP BY 1, 2, 3, 4
HAVING STRT IS NOT NULL
  AND ST_CD IS NOT NULL
  AND CITY_NM IS NOT NULL
  AND PSTL_CD IS NOT NULL
;
