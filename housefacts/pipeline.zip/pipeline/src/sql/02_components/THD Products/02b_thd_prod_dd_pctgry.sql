/* =====================================================================
  Create Date:    2022-12-27    Faith Andren 
  As of Date:     

  Purpose:        Create table of major appliances still known to be at
                  property.

  Steps:          1)  HVAC
                  2)  Water Heaters

  Notes:          - 

  Enhancements?   - To Do:
                      Freezer?
                      '029-015' -- COOKING
                      '029-017' -- A/CS AND FANS
                      '029-007' -- DISHWASHERS
                      '029-030' -- AIR QUALITY
                      '029-014' -- DISPOSERS

===================================================================== */


CREATE OR REPLACE TABLE 
  `analytics-mkt-analytics-thd.hf_pr.thd_prod_dd_pctgry`
OPTIONS(DESCRIPTION =
  """
  """
  ) AS
SELECT
  A.CLIP

  /*  ================================================================== 
      REFRIGERATION: REFRIGERATOR
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN CLASS.EXT_CLASS_NBR = '029-013' -- REFRIGERATION
        AND SUB_CLASS.EXT_SUB_CLASS_NBR NOT IN
          ( "029-013-009" -- UPRIGHT FREEZER
            , "029-013-010" -- CHEST FREEZER
            , "029-013-015" -- ICEMAKER INSTALL KIT
            , "029-013-011" -- ICEMAKERS
            , "029-013-003" -- WINE COOLERS
          )
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, DD_ORD_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY DD_ORD_DT DESC
      LIMIT 5
    ) FRDG

  /*  ================================================================== 
      REFRIGERATION: FREEZER
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR IN
          ( "029-013-009" -- UPRIGHT FREEZER
            , "029-013-010" -- CHEST FREEZER
          )
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, DD_ORD_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY DD_ORD_DT DESC
      LIMIT 5
    ) FRZR

  /*  ================================================================== 
      LAUNDRY: WASHING MACHINE
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR IN
        ( "029-008-018" -- HE TL WITHOUT HOSES
          , "029-008-003" -- TOP LOAD WASHER W/O HOSE
          , "029-008-019" -- FL WASHERS W/OUT HOSES
          , "029-008-004" -- FRONTLOAD WASHERS W/HOSE
          , "029-008-009" -- COMBO WASHER/DRYER ELECT
          , "029-008-023" -- GE REVERSIBLE WASHER DR
          , "029-008-021" -- PED WASHERS W/OUT HOSES
          , "029-008-020" -- COMBO WASHER/DRYER GAS
          , "029-008-024" -- WASHTOWER ELECTRIC
          , "029-008-026" -- WASHTOWER ELEC-NO STEAM
          , "029-008-025" -- WASHTOWER GAS
          , "029-008-028" -- SAMSUNG WSHER MULTICNTRL
          , "029-008-027" -- WASHTOWER GAS-NO STEAM
          , "029-008-002" -- TOP LOAD WASHERS W/HOSES
          , "029-008-015" -- HE TL WITH HOSES
        )
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, DD_ORD_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY DD_ORD_DT DESC
      LIMIT 5
    ) WASH

  /*  ================================================================== 
      LAUNDRY: DRYER
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR IN
        ( "029-008-007" -- FRONTLOAD ELECTRIC DRYER
          , "029-008-016" -- HE TL ELECTRIC DRYERS
          , "029-008-005" -- DRYERS ELECTRIC
          , "029-008-013" -- STEAM DRY ELEC W/O HOSES
          , "029-008-008" -- FRONT LOAD GAS DRYERS
          , "029-008-017" -- HE TL GAS DRYERS
          , "029-008-006" -- DRYERS GAS
          , "029-008-009" -- COMBO WASHER/DRYER ELECT
          , "029-008-014" -- STEAM DRY GAS W/O HOSES
          , "029-008-020" -- COMBO WASHER/DRYER GAS
          , "029-008-024" -- WASHTOWER ELECTRIC
          , "029-008-026" -- WASHTOWER ELEC-NO STEAM
          , "029-008-025" -- WASHTOWER GAS
          , "029-008-027" -- WASHTOWER GAS-NO STEAM
        )
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, DD_ORD_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY DD_ORD_DT DESC
      LIMIT 5
    ) DRY
    
  /*  ================================================================== 
      TO DO
  =================================================================== */

FROM `analytics-mkt-analytics-thd.hf_pr.thd_prod_dd` A
INNER JOIN `pr-edw-views-thd.SHARED.SKU_HIER` B
  ON A.SKU_NBR = B.SKU_NBR
    AND A.SKU_CRT_DT = B.SKU_CRT_DT
GROUP BY 1;






CREATE OR REPLACE TABLE 
  `analytics-mkt-analytics-thd.hf_pr.thd_prod_dd_pctgry2`
OPTIONS(DESCRIPTION =
  """
  """
  ) AS
WITH
  t01 AS
    ( SELECT 
        CLIP
        , DT AS EFF_BGN_DT
        , COALESCE(
            LEAD(DT) OVER(PARTITION BY CLIP ORDER BY DT)
          , DATE('9999-12-31')
        ) EFF_END_DT
      FROM 
        `analytics-mkt-analytics-thd.hf_pr.thd_prod_dd`
        , UNNEST([MAX_APPLNC_DT, DD_ORD_DT]) DT
      WHERE DT != '9999-12-31'
      GROUP BY 1, 2
    )
  , t02 AS 
    ( SELECT
        C.CLIP
        , C.EFF_BGN_DT, C.EFF_END_DT

        /*  ================================================================== 
            REFRIGERATION: REFRIGERATOR
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN CLASS.EXT_CLASS_NBR = '029-013' -- REFRIGERATION
              AND SUB_CLASS.EXT_SUB_CLASS_NBR NOT IN
                ( "029-013-009" -- UPRIGHT FREEZER
                  , "029-013-010" -- CHEST FREEZER
                  , "029-013-015" -- ICEMAKER INSTALL KIT
                  , "029-013-011" -- ICEMAKERS
                  , "029-013-003" -- WINE COOLERS
                )
            THEN DD_ORD_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY DD_ORD_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] FRDG

        /*  ================================================================== 
            REFRIGERATION: FREEZER
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR IN
                ( "029-013-009" -- UPRIGHT FREEZER
                  , "029-013-010" -- CHEST FREEZER
                )
            THEN DD_ORD_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY DD_ORD_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] FRZR

        /*  ================================================================== 
            LAUNDRY: WASHING MACHINE
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR IN
              ( "029-008-018" -- HE TL WITHOUT HOSES
                , "029-008-003" -- TOP LOAD WASHER W/O HOSE
                , "029-008-019" -- FL WASHERS W/OUT HOSES
                , "029-008-004" -- FRONTLOAD WASHERS W/HOSE
                , "029-008-009" -- COMBO WASHER/DRYER ELECT
                , "029-008-023" -- GE REVERSIBLE WASHER DR
                , "029-008-021" -- PED WASHERS W/OUT HOSES
                , "029-008-020" -- COMBO WASHER/DRYER GAS
                , "029-008-024" -- WASHTOWER ELECTRIC
                , "029-008-026" -- WASHTOWER ELEC-NO STEAM
                , "029-008-025" -- WASHTOWER GAS
                , "029-008-028" -- SAMSUNG WSHER MULTICNTRL
                , "029-008-027" -- WASHTOWER GAS-NO STEAM
                , "029-008-002" -- TOP LOAD WASHERS W/HOSES
                , "029-008-015" -- HE TL WITH HOSES
              )
            THEN DD_ORD_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY DD_ORD_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] WASH

        /*  ================================================================== 
            LAUNDRY: DRYER
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR IN
              ( "029-008-007" -- FRONTLOAD ELECTRIC DRYER
                , "029-008-016" -- HE TL ELECTRIC DRYERS
                , "029-008-005" -- DRYERS ELECTRIC
                , "029-008-013" -- STEAM DRY ELEC W/O HOSES
                , "029-008-008" -- FRONT LOAD GAS DRYERS
                , "029-008-017" -- HE TL GAS DRYERS
                , "029-008-006" -- DRYERS GAS
                , "029-008-009" -- COMBO WASHER/DRYER ELECT
                , "029-008-014" -- STEAM DRY GAS W/O HOSES
                , "029-008-020" -- COMBO WASHER/DRYER GAS
                , "029-008-024" -- WASHTOWER ELECTRIC
                , "029-008-026" -- WASHTOWER ELEC-NO STEAM
                , "029-008-025" -- WASHTOWER GAS
                , "029-008-027" -- WASHTOWER GAS-NO STEAM
              )
            THEN DD_ORD_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY DD_ORD_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] DRY
          
        /*  ================================================================== 
            TO DO
        =================================================================== */

      FROM `analytics-mkt-analytics-thd.hf_pr.thd_prod_dd` A
      INNER JOIN `pr-edw-views-thd.SHARED.SKU_HIER` B
        ON A.SKU_NBR = B.SKU_NBR
          AND A.SKU_CRT_DT = B.SKU_CRT_DT
      INNER JOIN t01 C
        ON A.CLIP = C.CLIP
          AND A.DD_ORD_DT <= C.EFF_BGN_DT
      GROUP BY 1, 2, 3
    )
  , t03 AS 
    ( SELECT 
        A.* EXCEPT(EFF_BGN_DT, EFF_END_DT)
        , `analytics-views-thd.GEO.udf_mrg_intvls`(
            ARRAY_AGG(
              STRUCT(
                UNIX_MILLIS(TIMESTAMP(EFF_BGN_DT)) AS intervalStart
                , UNIX_MILLIS(TIMESTAMP(EFF_END_DT)) AS intervalEnd
              )
            ) ) AS intervals
      FROM t02 A
      GROUP BY 1, 2, 3, 4, 5
    )
SELECT
  CAST(TIMESTAMP_MILLIS(i.intervalStart) AS DATE) EFF_BGN_DT
  , CASE WHEN
      CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE) = '9999-12-31'
      THEN CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE)
      ELSE DATE_SUB( CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE), INTERVAL 1 DAY)
      END EFF_END_DT
  , A.* EXCEPT(intervals)
FROM
  t03 A
  , UNNEST(intervals) i

;