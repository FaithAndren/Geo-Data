/* =====================================================================
  Create Date:    2022-12-20    Faith Andren
  As of Date:     

  Purpose:        Create a CLIP x subclass x-ref table of direct depot
                  appliances purchased by homeowners who we know are 
                  still living at the property or were delivered after 
                  the last know sale date of the property.

  Steps:          1)  Grab specified subclass product order COM lines.
                  2)  Grab COM lines that haven't been cancelled and had
                      appliance order placed with product vendor.
                  4)  Grab the last know sale date of a property (clip)
                  5)  Join vendor ordered DD lines to major appliance
                      order lines and keep only the records where the
                      order was placed after the last known sale date
                      or the purchaser is known to still own the home.

  Notes:          - We add the owner name condition as an OR since it 
                    could be possible for residents to pre-order 
                    appliances in anticipation of moving into new home
                    (since we don't have delivery date in those tables).

  Enhancements?   - Need to remove THD stores that may have snuck in.

===================================================================== */

CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_pr.thd_prod_dd`
OPTIONS(
  DESCRIPTION="""
    Latest completed THD installation date by SKU and property.
    """
) AS
WITH
  -- Grab major appliance product order COM lines
  t01 AS
    ( SELECT
        NULLIF(TRIM(UPPER(A.EXTN_HOST_ORDER_REF)), '') ORD_NBR
        , SAFE_CAST(A.EXTN_HOST_ORDER_LINE_REF AS INT64) ORD_LN
        , ANY_VALUE( -- Just incase Dups
            STRUCT(
              A.ORDER_DATE
              , `analytics-views-thd.GEO.udf_strt_std`(
                    A.ADDR_LINE1_TXT, A.ADDR_LINE2_TXT) AS STRT
              , `analytics-views-thd.GEO.udf_clns_city`(A.CITY) AS CITY_NM
              , `analytics-views-thd.GEO.udf_clns_stcd`(A.STATE) AS ST_CD
              , `analytics-views-thd.GEO.udf_clns_zip`(A.ZIP_CODE) AS PSTL_CD
              , A.SKU_NBR, A.SKU_CRT_DT
              , NULLIF(TRIM(UPPER(FIRST_NAME)), '') AS FRST_NM
              , NULLIF(TRIM(UPPER(LAST_NAME)), '')  AS LAST_NM
              , EXT_CLASS_NBR
              , EXT_SUB_CLASS_NBR
            )
          ).*
      FROM `pr-edw-views-thd.ORD_COM_CONF.COM_LINE` A
      LEFT JOIN `pr-edw-views-thd.SHARED.SKU_HIER_FD` B
        ON A.SKU_NBR = B.SKU_NBR
          AND A.SKU_CRT_DT = B.SKU_CRT_DT
      WHERE TRIM(A.EXTN_HOST_ORDER_REF) != ''
        AND SAFE_CAST(A.EXTN_HOST_ORDER_LINE_REF AS INT64) IS NOT NULL
        AND A.DOCUMENT_TYPE = '0001' -- sale
        AND A.DRAFT_ORDER_FLAG = 'N' -- Not a draft (e.g. quote)
        AND NULLIF(TRIM(ADDR_LINE1_TXT), '') IS NOT NULL
        AND NULLIF(TRIM(CITY), '') IS NOT NULL
        AND NULLIF(TRIM(STATE), '') IS NOT NULL
        AND NULLIF(TRIM(ZIP_CODE), '') IS NOT NULL
        AND DELIVERY_METHOD IN ("SHP", "DEL")
        AND LINE_TYPE IN ("SO", "SL")
        AND SKU_TYP_CD IN ("N", "S")
        AND EXT_CLASS_NBR IN -- Major Appliances
          ( '029-008'   -- LAUNDRY
            , '029-013' -- REFRIGERATION
            , '029-015' -- COOKING
            , '029-017' -- A/CS AND FANS
            , '029-007' -- DISHWASHERS
            , '029-030' -- AIR QUALITY
            , '029-014' -- DISPOSERS
            -- etc...
          )
        -- Todo: validate DD with CORD_SRC_PRCSS_CD (DD=10)
      GROUP BY 1, 2
    )
  -- Grab Direct Depot (DD) ordered COM lines
  , t02 AS
    ( SELECT
        TRIM(UPPER(EXTN_HOST_ORDER_REF)) ORD_NBR
        , SAFE_CAST(EXTN_HOST_ORDER_LINE_REF AS INT64) ORD_LN
        , MAX( CASE WHEN COALESCE(STATUS_DESC, '') IN ('Vendor ordered')
          THEN STATUS_EFFECTIVE_TS END) DD_ORD_DT -- Direct Depot
        , MAX( CASE WHEN REGEXP_CONTAINS(STATUS_DESC, '(?i)cancel') 
          THEN STATUS_EFFECTIVE_TS END) CAN_DT
      FROM `pr-edw-views-thd.ORD_COM.COM_LINE_STATUS`
      GROUP BY 1, 2
      HAVING ORD_NBR IS NOT NULL
        AND ORD_LN IS NOT NULL
        AND DD_ORD_DT IS NOT NULL -- Major Appliance Ordered
        -- remove noise of cancels 
        -- (may be rescheduled - need further investigation)
        AND CAN_DT IS NULL        
    )
  -- Last known sale date of a CLIP 
  -- (remember to not pull refinances by filtering with trans type)
  , t03 AS
    ( SELECT
        B.CLIP
        , MAX(SALE_DT) SALE_DT
      FROM 
        `analytics-views-thd.GEO_CONF.prop_deed` A
        , `analytics-mkt-analytics-thd.hf_pr.prop_xref` B
      WHERE A.STRT = B.STRT
        AND A.CITY_NM = B.CITY_NM
        AND A.ST_CD = B.ST_CD
        AND A.PSTL_CD = B.PSTL_CD
        AND A.TRANS_TYP IN
          ( "1"   -- RESALE (45% records)
            , "3" -- SUBDIVISION/NEW CONSTRUCTION (3.4% records)
            , "7" -- SELLER CARRYBACK (0.5% records)
          )
        AND A.SALE_DT IS NOT NULL
      GROUP BY 1
      UNION DISTINCT
      SELECT
        B.CLIP
        , MAX(SALE_DT) SALE_DT
      FROM 
        `analytics-views-thd.GEO_CONF.prop_tax` A
        , `analytics-mkt-analytics-thd.hf_pr.prop_xref` B
      WHERE A.STRT = B.STRT
        AND A.CITY_NM = B.CITY_NM
        AND A.ST_CD = B.ST_CD
        AND A.PSTL_CD = B.PSTL_CD
        AND A.SALE_DT IS NOT NULL
      GROUP BY 1
    )
  , t04 AS
    ( SELECT CLIP, MAX(SALE_DT) AS SALE_DT
      FROM t03
      GROUP BY 1
    )
-- Grab last known major appliance placed order per subclass
SELECT
  C.CLIP
  , EXT_SUB_CLASS_NBR
  , ARRAY_AGG(
      STRUCT(
        DATE(DD_ORD_DT) AS DD_ORD_DT
        , SKU_NBR, SKU_CRT_DT
      )
      ORDER BY DD_ORD_DT DESC
      LIMIT 1
    )[SAFE_OFFSET(0)].*
  , MAX(CASE 
      WHEN DD_ORD_DT >= SALE_DT THEN '9999-12-31'
      ELSE MAX_OWNR_DT
    END) MAX_APPLNC_DT
FROM t01 A -- Initiated Major Appliance Order Lines
INNER JOIN t02 B -- Direct Depot Ordered Com Lines
  ON A.ORD_NBR = B.ORD_NBR
    AND A.ORD_LN = B.ORD_LN
INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` C
  ON A.STRT = C.STRT
    AND A.CITY_NM = C.CITY_NM
    AND A.ST_CD = C.ST_CD
    AND A.PSTL_CD = C.PSTL_CD
LEFT JOIN `analytics-mkt-analytics-thd.hf_pr.clip_last_nm` D 
  ON C.CLIP = D.CLIP
    AND CASE WHEN A.LAST_NM IS NULL AND REGEXP_CONTAINS(A.FRST_NM, ' ')
        THEN SPLIT(A.FRST_NM, ' ')[SAFE_OFFSET(1)]
        ELSE A.LAST_NM END = D.OWNR_LAST_NM
LEFT JOIN t04 E -- Home's last known sale date
  ON C.CLIP = E.CLIP
WHERE 1 = 1
  AND 
    ( -- Appliances were delivered after latest property sale date
      DD_ORD_DT >= SALE_DT
      -- Or we know the appliance purchasers ownership date
      OR DD_ORD_DT BETWEEN COALESCE(MIN_OWNR_DT, DD_ORD_DT) AND MAX_OWNR_DT
      -- 
    )
  AND A.STRT IS NOT NULL
  AND A.CITY_NM IS NOT NULL
  AND A.ST_CD IS NOT NULL
  AND A.PSTL_CD IS NOT NULL
GROUP BY 1, 2;
