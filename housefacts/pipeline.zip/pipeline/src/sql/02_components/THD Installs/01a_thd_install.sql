/* =====================================================================
  Create Date:    2022-09-15    Celine Wang
  As of Date:     2022-12-02    Faith Andren

  Purpose:        Create a CLIPxSKU xref table of all THD completed
                  installations with its latest completed install date.

  Steps:          1)  Grab all Install order lines from COM.
                  2)  Grab the latest status for all order lines.
                  3)  Join latest order status to COM Install
                      order lines and aggregate to CLIP.

  Notes:          - If a product is shipped to the store for pick-up,
                    the order's shipping address will most likely be the
                    store's location; in those cases, we grab the
                    billing address from the order header (COM_HDR).

  Enhancements?   - Finding out how to find the true site address for
                    installation orders instead of using shipping
                    address (COM_LINE) or billing address (COM_HDR).

===================================================================== */

CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_pr.thd_instl_sku`
OPTIONS(
  DESCRIPTION="""
    Latest completed THD installation date by SKU and property
    """
) AS
WITH
  -- Installation Order Lines
  t01 AS
    ( SELECT
        NULLIF(TRIM(UPPER(A.EXTN_HOST_ORDER_REF)), '') ORD_NBR
        , SAFE_CAST(A.EXTN_HOST_ORDER_LINE_REF AS INT64) ORD_LN
        , ANY_VALUE( -- Just incase Dups
            STRUCT(
              A.ORDER_DATE
              , `analytics-views-thd.GEO.udf_strt_std`(
                    A.ADDR_LINE1_TXT, A.ADDR_LINE2_TXT) AS STRT
              , `analytics-views-thd.GEO.udf_clns_city`(A.CITY) AS CITY_NM
              , `analytics-views-thd.GEO.udf_clns_stcd`(A.STATE) AS ST_CD
              , `analytics-views-thd.GEO.udf_clns_zip`(A.ZIP_CODE) AS PSTL_CD
              , A.SKU_NBR, A.SKU_CRT_DT
              , NULLIF(TRIM(UPPER(FIRST_NAME)), '') AS FRST_NM
              , NULLIF(TRIM(UPPER(LAST_NAME)), '')  AS LAST_NM
            )
          ).*
      FROM `pr-edw-views-thd.ORD_COM_CONF.COM_LINE` A
      WHERE TRIM(A.EXTN_HOST_ORDER_REF) != ''
        AND SAFE_CAST(A.EXTN_HOST_ORDER_LINE_REF AS INT64) IS NOT NULL
        AND A.DOCUMENT_TYPE = '0001' -- sale
        AND A.DRAFT_ORDER_FLAG = 'N' -- Not a draft (e.g. quote)
        AND A.LINE_TYPE = 'IN' -- Installation Line
        AND NULLIF(TRIM(ADDR_LINE1_TXT), '') IS NOT NULL
        AND NULLIF(TRIM(CITY), '') IS NOT NULL
        AND NULLIF(TRIM(STATE), '') IS NOT NULL
        AND NULLIF(TRIM(ZIP_CODE), '') IS NOT NULL
        AND SKU_NBR IS NOT NULL 
        AND SKU_CRT_DT IS NOT NULL
      GROUP BY 1, 2
    )
  -- Grab Order Status Dates
  , t02 AS
    ( SELECT
        TRIM(UPPER(EXTN_HOST_ORDER_REF)) ORD_NBR
        , SAFE_CAST(EXTN_HOST_ORDER_LINE_REF AS INT64) ORD_LN
        , MIN( CASE WHEN COALESCE(STATUS_DESC, '') 
              IN ('Sold', 'Service validated')
            OR COALESCE(STATUS_CODE, '') IN ('130', '175')
          THEN STATUS_EFFECTIVE_TS END) SOLD_DT
        , MAX( CASE WHEN COALESCE(STATUS_DESC, '') IN ('Done')
            OR COALESCE(STATUS_CODE, '') = '1000'
          THEN STATUS_EFFECTIVE_TS END) DONE_DT
        , MAX( CASE WHEN REGEXP_CONTAINS(STATUS_DESC, '(?i)cancel') 
          THEN STATUS_EFFECTIVE_TS END) CAN_DT
      FROM `pr-edw-views-thd.ORD_COM.COM_LINE_STATUS`
      GROUP BY 1, 2
      HAVING ORD_NBR IS NOT NULL
        AND ORD_LN IS NOT NULL
        AND DONE_DT IS NOT NULL -- completed installation
        -- remove noise of cancels 
        -- (may be rescheduled - need further investigation)
        AND CAN_DT IS NULL 
    )
  -- Grab last known installation complete date for each SKU
SELECT
  CLIP
  , SKU_NBR, SKU_CRT_DT
  , DATE(MAX(B.DONE_DT)) LAST_INSTL_DT
FROM t01 A
INNER JOIN t02 B
  ON A.ORD_NBR = B.ORD_NBR
    AND A.ORD_LN = B.ORD_LN
INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` C
  ON A.STRT = C.STRT
    AND A.CITY_NM = C.CITY_NM
    AND A.ST_CD = C.ST_CD
    AND A.PSTL_CD = C.PSTL_CD
WHERE DONE_DT IS NOT NULL -- Completed Installs
  AND A.STRT IS NOT NULL
  AND A.CITY_NM IS NOT NULL
  AND A.ST_CD IS NOT NULL
  AND A.PSTL_CD IS NOT NULL
GROUP BY 1, 2, 3;
