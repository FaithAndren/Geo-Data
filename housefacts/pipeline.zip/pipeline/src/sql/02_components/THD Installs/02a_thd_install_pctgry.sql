/* =====================================================================
  Create Date:                  Celine Wang / Rajat Verma
  As of Date:     2022-12-20    Faith Andren 

  Purpose:        Create completed installation views per clip by
                  product category ordered by complete date descending.

  Steps:          1)  Aggregate product category latest 5 installs.

  Notes:          - Todo:
                    - [v] Validate Solar Logic w/ Merchant & Comment
                    - [ ] Validate Generator Logic w/ Merchant & Comment
                    - [ ] Validate Battery Logic w/ Merchant & Comment
                    - [v] Validate Flooring Logic w/ Merchant & Comment
                    - [ ] Validate Installed Structure Logic w/ Merchant & Comment
                    - [v] Validate Fencing Logic w/ Merchant & Comment
                    - [v] Validate Door Logic w/ Merchant & Comment
                    - [ ] Validate Water Treatment Logic w/ Merchant & Comment

  Enhancements?   - Completed Installs To Do:
                      [ ] https://www.homedepot.com/services/c/kitchen-remodel/f8b9df102
                      [ ] https://www.homedepot.com/services/c/windows-doors-h/dwh789876
                      [ ] https://www.homedepot.com/services/h/hvac-services
                      [ ] https://www.homedepot.com/services/h/exterior-home
                      [v] https://www.homedepot.com/services/c/water-heaters-treatment-h/3w64hts8
                      [ ] https://www.homedepot.com/services/c/bathroom-installation/0e8607fc5
                      [ ] https://www.homedepot.com/services/c/home-organization/22ef3e97b
                      [ ] https://www.homedepot.com/services/h/electrical
                      [ ] https://www.homedepot.com/services/h/carpentry-masonry
                      [ ] https://www.homedepot.com/services/h/painting
                      [ ] https://www.homedepot.com/services/h/landscape
                      [ ] https://www.homedepot.com/services/h/assembly-mounting
                      [ ] https://www.homedepot.com/services/c/plumbing/16ff694b2
                      [ ] https://www.homedepot.com/services/h/smart-home-installation
                      [ ] https://www.homedepot.com/services/h/cleaning
                      [ ] https://www.homedepot.com/services/all
                      [v] Roofing (no longer offered, but grab historical)
                  - Leverage Pro referral data (low priority)
                  - SFI Investigation

===================================================================== */


CREATE OR REPLACE TABLE 
  `analytics-mkt-analytics-thd.hf_pr.thd_instl_pctgry`
OPTIONS(DESCRIPTION =
  "Latest completed THD installations per property(CLIP) by category"
  ) AS
SELECT
  A.CLIP
  /* ================================================================== 
    HVAC Installations
 
    According to merchant, everything under '026-052-010' is HVAC 
    install. Lifespan depends on area (based on run time hours/cooling 
    degree days) however generally its between 10-17 years.
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
        = '026-052-010' -- D26P/HVAC/HVAC
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) HVAC

  /*  ================================================================== 
    WATER HEATER INSTALLATIONS

    - Class 51: water heater installs, Class 10: unit purchases.
    - Use only customer purchases for class 10.
    - Customers usually install the water heater within 48 hours after 
      purchase.
    - Product lifespan is 8-10 years on average, depending on the 
      weather and water quality. They don’t have data recording the 
      product lifespan.
    - Information for the model installed for SF&I are saved in 
      salesforce, contact: Lisa Sents. 
      (Only have data for the past year)
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR IN
        ( --'026-051-040' -- WATER HEATERS - SOLAR HEATERS
          '026-051-030' -- WATER HEATERS - TANKLESS HEATERS
          , '026-051-060' -- WATER HEATERS - SFI TANKLESS WATERHEATE
          , '026-051-020' -- WATER HEATERS - F & I WATER HEATERS
          , '026-051-080' -- WATER HEATERS - SFI ELEC HEAT PUMP WH
          , '026-051-010' -- WATER HEATERS - WATER HEATERS
          , '026-051-070' -- WATER HEATERS - SF & I WATER HEATERS
        )
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) WHTR

  /*  ================================================================== 
    RENEWABLE ENERGY - SOLAR PANELS
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
        = '027-054-020' -- SOLAR PANELS
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) SOLR

  /*  ================================================================== 
    RENEWABLE ENERGY - HOME BATTERY BACKUP
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
        = '027-054-003' -- HOME BATTERY BACKUP
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) BTTRY

  /*  ================================================================== 
    GENERATOR INSTALL/ELEC S - STAND-BY GENERATOR INSTL
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
        = '027-057-010' -- STAND-BY GENERATOR INSTL
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) GNRTR

/*  ================================================================== 
    FLOORING: CARPET
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
        IN (
          "023-056-010" -- CARPET INSTALL: CARPET
          , "023-056-012" -- CARPET INSTALL: CARPET RAPID
          , "023-056-050" -- CARPET INSTALL: CARPET INSTALL 72 HR/5 D
        )
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) CRPT

/*  ================================================================== 
    FLOORING: HARDWOOD
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
        IN (
          "023-058-010" -- HARDWOOD INSTL: HARDWOOD NAIL
          , "023-058-080" -- HARDWOOD INSTL: HARDWOOD CLICK LOCK
        )
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) WOOD

/*  ================================================================== 
    FLOORING: TILE
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
        IN (
          "023-057-010" -- TILE INSTALL: TILE FLOOR
          , "023-057-070" -- TILE INSTALL: TILE CLICK LOCK
        )
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) TILE

/*  ================================================================== 
    FLOORING: VINYL / VINYL PLANK
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN CLASS.EXT_CLASS_NBR = "023-062" 
      -- VINYL/VINYL PLANK INSTALL
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) VINYL

/*  ================================================================== 
    FLOORING: LAMINATE
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN CLASS.EXT_CLASS_NBR = "023-060" -- LAMINATE INSTALL
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) LAM

/*  ================================================================== 
    INSTALLED STRUCTURES: Storm Shelter
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
        IN (
          "028-052-020" -- INSTALLED STRUCTURES: GARAGES
          , "028-052-040" -- INSTALLED STRUCTURES: SPECIALTY
        )
        AND REGEXP_CONTAINS(SKU.SKU_DESC
          , '(?i)st(o)?rm|shelter|torando|safe( )?room')
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) STORM

/*  ================================================================== 
    INSTALLED STRUCTURES: GAZEBO
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN CLASS.EXT_CLASS_NBR = "028-052" -- INSTALLED STRUCTURES
        AND REGEXP_CONTAINS(SKU.SKU_DESC, '(?i)gazebo')
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) GZBO

 /*  ================================================================== 
    INSTALLED STRUCTURES: PERGOLA
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN CLASS.EXT_CLASS_NBR IN
        ( "028-052" -- INSTALLED STRUCTURES
          , '028-058' -- EXT. PATIO STRUCTURES
        )
        AND REGEXP_CONTAINS(SKU.SKU_DESC, '(?i)pergola')
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) PRGL

 /*  ================================================================== 
    INSTALLED STRUCTURES: SHED
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN CLASS.EXT_CLASS_NBR = "028-052" -- INSTALLED STRUCTURES
        AND REGEXP_CONTAINS(SKU.SKU_DESC, '(?i)(^| )shed(s)?($| )')
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) SHED

 /*  ================================================================== 
    INSTALLED STRUCTURES: CARPORT
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN CLASS.EXT_CLASS_NBR = "028-052" -- INSTALLED STRUCTURES
        AND REGEXP_CONTAINS(SKU.SKU_DESC, '(?i)CARPORT')
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) CRPRT

 /*  ================================================================== 
    FENCING
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN CLASS.EXT_CLASS_NBR = "021-051" -- FENCING
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) FENCE

 /*  ================================================================== 
    DOOR: STORM
    - storm door: life span is 5-10 years
    - security door: life span is 10 years
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
        IN (
          "030-054-020" -- EXTERIOR DOOR INSTALL: STORM/SECURITY DR INSTL
        )
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) DOOR_STRM

 /*  ================================================================== 
    DOOR: EXTERIOR
    - Entry Door life span is 20 years. Trend and weather play a role in 
      this life span. Most entry doors will be out of trend within 20 years.          
    - Fiberglass Entry Doors have a life span of 20 years.
    - Steel Entry Doors have a life span of 20 years.
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
        IN (
          "030-054-010" -- EXTERIOR DOOR INSTALL: ENTRY DOOR INSTALL
          , "030-054-011" -- EXTERIOR DOOR INSTALL: SF&I EXTERIOR DOORS
          , "030-054-041" -- EXTERIOR DOOR INSTALL: IRON DOOR INSTALLS
          , "030-059-010" -- SF&I EXTERIOR DOOR
        )
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) DOOR_EXTR

 /*  ================================================================== 
    DOOR: PATIO
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN CLASS.EXT_CLASS_NBR = "030-057" -- PATIO DOOR INSTALL
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) DOOR_PATIO

 /*  ================================================================== 
    DOOR: INTERIOR
    - Solid Core Doors 7 Years
    -Hollow Core Doors 5 years
  =================================================================== */
  , ARRAY_AGG(
      CASE WHEN CLASS.EXT_CLASS_NBR = "030-056" -- INTERIOR DOOR INSTA
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) DOOR_INTR
    
    /*  ==================================================================
    Roofing
    - average lifespan is around 15-20 year, but may be cut short due to
      storms (hirricanes,hail damage,tornados,etc)
  =================================================================== */
    , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR
        IN
           ( "022-051-010" -- SF & I ROOFING
            ,"022-051-020" -- PUERTO RICO ROOFING
           )
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) ROOF

  /*  ==================================================================
    Water treatment: Water filters
    https://www.homedepot.com/services/c/water-treatment/879700ce6
  =================================================================== */
    , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR
        IN
           ( "026-053-010" -- WATER FILTERS
            ,"026-053-020" -- F & I WATER FILTERS
            )
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) WFLTR
      
/*  ==================================================================
    Water treatment: Water softners
    https://www.homedepot.com/services/c/water-treatment/879700ce6
    verify with Merchant if SF & I WATER TREATMENT & SFI WATER 
    SOFT/FILTER = water softners or water filters
  =================================================================== */
   , ARRAY_AGG(
      CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR
        IN
           ( "026-053-030" -- WATER SOFTENERS
            ,"026-053-040" -- F & I WATER SOFTENERS
            -- ,"026-053-050" -- SF & I WATER TREATMENT
            -- ,"026-053-051" -- SFI WATER SOFT/FILTER
            )
      THEN
        STRUCT(
          A.SKU_NBR, A.SKU_CRT_DT, LAST_INSTL_DT
        )
      ELSE NULL END IGNORE NULLS
      ORDER BY LAST_INSTL_DT DESC
      LIMIT 5
    ) WSFTR
  /*  ==================================================================
    Countertop
    - need further investigation, SKUs under 029-056 seem to exist in
      both kithchen countertop and bath vanity top
  =================================================================== */
    
    
    
    

  /*  ================================================================== 
    TO DO
  =================================================================== */
FROM `analytics-mkt-analytics-thd.hf_pr.thd_instl_sku` A
INNER JOIN `pr-edw-views-thd.SHARED.SKU_HIER` B
  ON A.SKU_NBR = B.SKU_NBR
    AND A.SKU_CRT_DT = B.SKU_CRT_DT
WHERE SKU.SKU_TYP_CD = 'I' -- Installer
GROUP BY 1;
















CREATE OR REPLACE TABLE 
  `analytics-mkt-analytics-thd.hf_pr.thd_instl_pctgry2`
OPTIONS(DESCRIPTION =
  "Latest completed THD installations per property(CLIP) by category"
  ) AS
WITH
  t01 AS
    ( SELECT 
        CLIP
        , LAST_INSTL_DT AS EFF_BGN_DT
        , COALESCE(
            LEAD(LAST_INSTL_DT) OVER(PARTITION BY CLIP ORDER BY LAST_INSTL_DT)
          , DATE('9999-12-31')
        ) EFF_END_DT
      FROM `analytics-mkt-analytics-thd.hf_pr.thd_instl_sku`
      GROUP BY 1, 2
    )
  , t02 AS 
    ( SELECT
        C.CLIP
        , C.EFF_BGN_DT, C.EFF_END_DT
        /* ================================================================== 
          HVAC Installations
      
          According to merchant, everything under '026-052-010' is HVAC 
          install. Lifespan depends on area (based on run time hours/cooling 
          degree days) however generally its between 10-17 years.
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
              = '026-052-010' -- D26P/HVAC/HVAC
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] HVAC

        /*  ================================================================== 
          WATER HEATER INSTALLATIONS

          - Class 51: water heater installs, Class 10: unit purchases.
          - Use only customer purchases for class 10.
          - Customers usually install the water heater within 48 hours after 
            purchase.
          - Product lifespan is 8-10 years on average, depending on the 
            weather and water quality. They don’t have data recording the 
            product lifespan.
          - Information for the model installed for SF&I are saved in 
            salesforce, contact: Lisa Sents. 
            (Only have data for the past year)
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR IN
              ( --'026-051-040' -- WATER HEATERS - SOLAR HEATERS
                '026-051-030' -- WATER HEATERS - TANKLESS HEATERS
                , '026-051-060' -- WATER HEATERS - SFI TANKLESS WATERHEATE
                , '026-051-020' -- WATER HEATERS - F & I WATER HEATERS
                , '026-051-080' -- WATER HEATERS - SFI ELEC HEAT PUMP WH
                , '026-051-010' -- WATER HEATERS - WATER HEATERS
                , '026-051-070' -- WATER HEATERS - SF & I WATER HEATERS
              )
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] WHTR

        /*  ================================================================== 
          RENEWABLE ENERGY - SOLAR PANELS
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
              = '027-054-020' -- SOLAR PANELS
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] SOLR

        /*  ================================================================== 
          RENEWABLE ENERGY - HOME BATTERY BACKUP
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
              = '027-054-003' -- HOME BATTERY BACKUP
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] BTTRY

        /*  ================================================================== 
          GENERATOR INSTALL/ELEC S - STAND-BY GENERATOR INSTL
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
              = '027-057-010' -- STAND-BY GENERATOR INSTL
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] GNRTR

      /*  ================================================================== 
          FLOORING: CARPET
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
              IN (
                "023-056-010" -- CARPET INSTALL: CARPET
                , "023-056-012" -- CARPET INSTALL: CARPET RAPID
                , "023-056-050" -- CARPET INSTALL: CARPET INSTALL 72 HR/5 D
              )
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] CRPT

      /*  ================================================================== 
          FLOORING: HARDWOOD
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
              IN (
                "023-058-010" -- HARDWOOD INSTL: HARDWOOD NAIL
                , "023-058-080" -- HARDWOOD INSTL: HARDWOOD CLICK LOCK
              )
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] WOOD

      /*  ================================================================== 
          FLOORING: TILE
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
              IN (
                "023-057-010" -- TILE INSTALL: TILE FLOOR
                , "023-057-070" -- TILE INSTALL: TILE CLICK LOCK
              )
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] TILE

      /*  ================================================================== 
          FLOORING: VINYL / VINYL PLANK
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN CLASS.EXT_CLASS_NBR = "023-062" 
            -- VINYL/VINYL PLANK INSTALL
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] VINYL

      /*  ================================================================== 
          FLOORING: LAMINATE
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN CLASS.EXT_CLASS_NBR = "023-060" -- LAMINATE INSTALL
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] LAM

      /*  ================================================================== 
          INSTALLED STRUCTURES: Storm Shelter
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
              IN (
                "028-052-020" -- INSTALLED STRUCTURES: GARAGES
                , "028-052-040" -- INSTALLED STRUCTURES: SPECIALTY
              )
              AND REGEXP_CONTAINS(SKU.SKU_DESC
                , '(?i)st(o)?rm|shelter|torando|safe( )?room')
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] STORM

      /*  ================================================================== 
          INSTALLED STRUCTURES: GAZEBO
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN CLASS.EXT_CLASS_NBR = "028-052" -- INSTALLED STRUCTURES
              AND REGEXP_CONTAINS(SKU.SKU_DESC, '(?i)gazebo')
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] GZBO

      /*  ================================================================== 
          INSTALLED STRUCTURES: PERGOLA
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN CLASS.EXT_CLASS_NBR IN
              ( "028-052" -- INSTALLED STRUCTURES
                , '028-058' -- EXT. PATIO STRUCTURES
              )
              AND REGEXP_CONTAINS(SKU.SKU_DESC, '(?i)pergola')
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] PRGL

      /*  ================================================================== 
          INSTALLED STRUCTURES: SHED
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN CLASS.EXT_CLASS_NBR = "028-052" -- INSTALLED STRUCTURES
              AND REGEXP_CONTAINS(SKU.SKU_DESC, '(?i)(^| )shed(s)?($| )')
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] SHED

      /*  ================================================================== 
          INSTALLED STRUCTURES: CARPORT
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN CLASS.EXT_CLASS_NBR = "028-052" -- INSTALLED STRUCTURES
              AND REGEXP_CONTAINS(SKU.SKU_DESC, '(?i)CARPORT')
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] CRPRT

      /*  ================================================================== 
          FENCING
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN CLASS.EXT_CLASS_NBR = "021-051" -- FENCING
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] FENCE

      /*  ================================================================== 
          DOOR: STORM
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
              IN (
                "030-054-020" -- EXTERIOR DOOR INSTALL: STORM/SECURITY DR INSTL
              )
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] DOOR_STRM

      /*  ================================================================== 
          DOOR: EXTERIOR
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN SUB_CLASS.EXT_SUB_CLASS_NBR 
              IN (
                "030-054-010" -- EXTERIOR DOOR INSTALL: ENTRY DOOR INSTALL
                , "030-054-011" -- EXTERIOR DOOR INSTALL: SF&I EXTERIOR DOORS
                , "030-054-041" -- EXTERIOR DOOR INSTALL: IRON DOOR INSTALLS
                , "030-059-010" -- SF&I EXTERIOR DOOR
              )
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] DOOR_EXTR

      /*  ================================================================== 
          DOOR: PATIO
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN CLASS.EXT_CLASS_NBR = "030-057" -- PATIO DOOR INSTALL
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] DOOR_PATIO

      /*  ================================================================== 
          DOOR: PATIO
        =================================================================== */
        , ARRAY_AGG(
            CASE WHEN CLASS.EXT_CLASS_NBR = "030-056" -- INTERIOR DOOR INSTA
            THEN LAST_INSTL_DT
            ELSE NULL END IGNORE NULLS
            ORDER BY LAST_INSTL_DT DESC
            LIMIT 1
          )[SAFE_OFFSET(0)] DOOR_INTR
      FROM `analytics-mkt-analytics-thd.hf_pr.thd_instl_sku` A
      INNER JOIN `pr-edw-views-thd.SHARED.SKU_HIER` B
        ON A.SKU_NBR = B.SKU_NBR
          AND A.SKU_CRT_DT = B.SKU_CRT_DT
      INNER JOIN t01 C
        ON A.CLIP = C.CLIP
          AND A.LAST_INSTL_DT <= C.EFF_BGN_DT
      WHERE SKU.SKU_TYP_CD = 'I' -- Installer
        --AND A.CLIP = "5778030112"
      GROUP BY 1, 2, 3
    )
  , t03 AS 
    ( SELECT 
        A.* EXCEPT(EFF_BGN_DT, EFF_END_DT)
        , `analytics-views-thd.GEO.udf_mrg_intvls`(
            ARRAY_AGG(
              STRUCT(
                UNIX_MILLIS(TIMESTAMP(EFF_BGN_DT)) AS intervalStart
                , UNIX_MILLIS(TIMESTAMP(EFF_END_DT)) AS intervalEnd
              )
            ) ) AS intervals
      FROM t02 A
      GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21
    )
SELECT
  CAST(TIMESTAMP_MILLIS(i.intervalStart) AS DATE) EFF_BGN_DT
  , CASE WHEN
      CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE) = '9999-12-31'
      THEN CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE)
      ELSE DATE_SUB( CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE), INTERVAL 1 DAY)
      END EFF_END_DT
  , A.* EXCEPT(intervals)
FROM
  t03 A
  , UNNEST(intervals) i

;


