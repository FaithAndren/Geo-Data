/* =====================================================================
  Create Date:    2022-07-22    Faith Andren 
                  2022-10-31    Celine Wang
                  2022-12-03    Faith Andren
  
  Purpose:        Join current property lien information to our property
                  ID.
                  
  Steps:          1)  Grab current lien information on properties.
  
  Notes:          - We use the lien_curr table instead of lien_hist
                    since we're only interested in current state.
                  - Home equity is an estimate based on our internal
                    amoritization function that assumes the owners are
                    paying the minimum required monthly amount.
                  - Note: negative home equities are replaced with $0.
                  - Not including renters for these features.
                  
  Enhancements?   - Add more features in iteration two.
  
===================================================================== */

CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_lien`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
) AS
SELECT
  B.CLIP
  , ARRAY_AGG(
      STRUCT(
        CAST(OWNR_OCC_IND AS BOOL) AS OWNR_OCC_IND -- Owner occupied
         , CURR_HOME_VAL -- Current Home Value
         , HOME_EQUITY -- Current Estimated Home Equity
         , CURR_LTV
         , NUM_LIENS
         , TOT_MRTG_AMT
         , TOT_MRTG_CURR_BAL
      )
      ORDER BY CURR_HOME_VAL DESC
      LIMIT 1
    )[SAFE_OFFSET(0)].*
FROM `analytics-views-thd.GEO_CONF.prop_lien_curr` A
INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` B
  ON A.STRT = B.STRT
    AND A.CITY_NM = B.CITY_NM
    AND A.ST_CD = B.ST_CD
    AND A.PSTL_CD = B.PSTL_CD
WHERE NOT REGEXP_CONTAINS(B.CLIP, "-")
GROUP BY 1;











CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_lien2`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
) AS
WITH
  t01 AS
    ( SELECT DT
      FROM UNNEST(GENERATE_DATE_ARRAY(CURRENT_DATE-1095, CURRENT_DATE, INTERVAL 3 MONTH)) DT
    )
  , t02 AS
    ( SELECT DISTINCT
        A.CLIP
        , C.EFF_BGN_DT
        , C.EFF_END_DT
        , CAST(C.OWNR_OCC_IND AS BOOL) AS OWNR_OCC_IND -- Owner occupied
        , ( CASE WHEN C.EFF_BGN_DT BETWEEN CURRENT_DATE - 90 AND CURRENT_DATE
            THEN STRUCT(
                B.CURR_HOME_VAL AS HOME_VAL
                , B.CURR_HOME_VAL - COALESCE(C.TOT_MRTG_CURR_BAL, 0) AS HOME_EQUITY
                , SAFE_DIVIDE(
                    COALESCE(C.TOT_MRTG_CURR_BAL, 0)
                    , B.CURR_HOME_VAL
                  ) AS LTV
              )
            END
          ).*
        --, CURR_LTV
        , C.NUM_LIENS
        , C.TOT_MRTG_AMT
        , C.TOT_MRTG_CURR_BAL
        
      FROM t01 BASE
      INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` A ON 1=1
      INNER JOIN `analytics-views-thd.GEO_CONF.prop_lien_curr` B
        ON A.STRT = B.STRT
          AND A.CITY_NM = B.CITY_NM
          AND A.ST_CD = B.ST_CD
          AND A.PSTL_CD = B.PSTL_CD
      INNER JOIN `analytics-views-thd.GEO_CONF.prop_lien_hist` C
        ON B.STRT = C.STRT 
          AND B.CITY_NM = C.CITY_NM
          AND B.ST_CD = C.ST_CD
          AND B.PSTL_CD = C.PSTL_CD
          AND C.EFF_END_DT BETWEEN CURRENT_DATE-1095 AND CURRENT_DATE
          AND BASE.DT BETWEEN C.EFF_BGN_DT AND C.EFF_END_DT
      WHERE NOT REGEXP_CONTAINS(A.CLIP, "-")

    )
SELECT
  A.CLIP 
  , A.EFF_BGN_DT 
  , COALESCE(
        LEAD(EFF_BGN_DT) OVER(PARTITION BY CLIP ORDER BY EFF_BGN_DT)-1
      , DATE('9999-12-31')
    ) EFF_END_DT
  , ARRAY_AGG(
      STRUCT(
          OWNR_OCC_IND, HOME_VAL, HOME_EQUITY, LTV, NUM_LIENS
          , TOT_MRTG_AMT, TOT_MRTG_CURR_BAL
        )
      ORDER BY
        TOT_MRTG_CURR_BAL DESC
        , TOT_MRTG_AMT DESC
        , HOME_VAL DESC
        , EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)].* 
FROM t02 A
GROUP BY 1, 2