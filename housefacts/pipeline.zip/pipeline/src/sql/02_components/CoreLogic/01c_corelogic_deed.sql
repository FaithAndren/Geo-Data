/* =====================================================================

  Create Date:    2022-07-22    Faith Andren
  As of Date:     2022-12-02    Faith Andren

  Purpose:        Create a table of property list from deed data, along
                  with the up-to-date features of a property, including
                  sales date, sale amount etc..

  Steps:          1)  Grab latest deed property attributes from deed
                      records.
                  2)  For properties that only map into deed records
                      using their parent clip (e.g. apartment units),
                      grab only certain columns
                  3)  Join together both sets of data.

  Notes:          - A single record in the deed table does not indicate
                    a transfer sale of the home. Any update to a deed
                    could have a record (e.g. refinance); when pulling
                    features that indicate move in date for a particular
                    person, you'll want to consider the transaction type
                    column.

                  - The logic for assigning the owner occupied indicator
                    is the recommendation from the deed source vendor.

  Enhancements?   - Add more features from deed table in iteration 2.
                  - Code only currently accomodates join on CLIP, future
                    code may need to be rewritten to account for units
                    that can only be joined using parent clip
                    (e.g. apartments).


===================================================================== */

CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_deed`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
 ) AS
-- directly map to legal records
SELECT
  B.CLIP
  -- Grab latest values for property from records that indicate a sale
  , ARRAY_AGG(
      STRUCT(
        SALE_DT
        , SALE_AMT
        , CASE
            WHEN OWNR_OCC_CD IN
              ( 'M' -- SITUS ADDRESS TAKEN FROM MAIL
                , 'O' -- OWNER OCCUPIED
                , 'S' -- SITUS FROM SALE (OCCUPIED)
              ) THEN TRUE
            WHEN OWNR_OCC_CD IS NOT NULL THEN FALSE
            ELSE NULL
          END AS OWNR_OCC_IND
        -- Investor Purchase Indicator
        , CAST(INV_PRCH_IND AS BOOL) AS INV_PRCH_IND
        , LAND_USE_CD
      )
      ORDER BY
        -- Latest transfer of sale of the home
        CASE WHEN TRANS_TYP IN
          ( "1"   -- RESALE (45% records)
            , "3" -- SUBDIVISION/NEW CONSTRUCTION (3.4% records)
            , "7" -- SELLER CARRYBACK (0.5% records)
          ) THEN 0 ELSE 1 END
        , EFF_END_DT DESC
      LIMIT 1
    )[SAFE_OFFSET(0)].*
FROM `analytics-views-thd.GEO_CONF.prop_deed` A
INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` B
  ON A.STRT = B.STRT
    AND A.CITY_NM = B.CITY_NM
    AND A.ST_CD = B.ST_CD
    AND A.PSTL_CD = B.PSTL_CD
GROUP BY 1;

INSERT `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_deed`
WITH
  -- map to legal records using parent address (e.g. apartment complex)
  t02 AS
    ( SELECT
        A.CLIP
        , CAST(NULL AS DATE) AS SALE_DT
        , CAST(NULL AS FLOAT64) AS SALE_AMT
        , FALSE AS OWNR_OCC_IND
        , CAST(NULL AS BOOL) AS INV_PRCH_IND
        , ARRAY_AGG(LAND_USE_CD
            ORDER BY
              CASE WHEN LAND_USE_CD IS NOT NULL
              THEN 0 ELSE 1 END
              , EFF_END_DT DESC
            LIMIT 1
        )[SAFE_OFFSET(0)] LAND_USE_CD
      FROM `analytics-mkt-analytics-thd.hf_pr.clip_curr` A
      INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` B
        ON A.PRNT_CLIP = B.CLIP
      INNER JOIN `analytics-views-thd.GEO_CONF.prop_deed` C
        ON B.STRT = C.STRT
          AND B.CITY_NM = C.CITY_NM
          AND B.ST_CD = C.ST_CD
          AND B.PSTL_CD = C.PSTL_CD
      WHERE A.PRNT_CLIP IS NOT NULL
      GROUP BY 1
    )
SELECT A.*
FROM t02 A
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_deed` B
  ON A.CLIP = B.CLIP
WHERE B.CLIP IS NULL;





CREATE OR REPLACE TEMP TABLE t01 AS
SELECT DISTINCT
  B.CLIP
  , A.EFF_BGN_DT
  , A.EFF_END_DT
  , ( CASE WHEN TRANS_TYP IN
        ( "1"   -- RESALE (45% records)
          , "3" -- SUBDIVISION/NEW CONSTRUCTION (3.4% records)
          , "7" -- SELLER CARRYBACK (0.5% records)
        ) 
      THEN STRUCT(SALE_DT, SALE_AMT)
      END
    ).*
  , CASE
      WHEN OWNR_OCC_CD IN
        ( 'M' -- SITUS ADDRESS TAKEN FROM MAIL
          , 'O' -- OWNER OCCUPIED
          , 'S' -- SITUS FROM SALE (OCCUPIED)
        ) THEN TRUE
      WHEN OWNR_OCC_CD IS NOT NULL THEN FALSE
      ELSE NULL
    END AS OWNR_OCC_IND
  -- Investor Purchase Indicator
  , CAST(INV_PRCH_IND AS BOOL) AS INV_PRCH_IND
  , LAND_USE_CD
FROM `analytics-views-thd.GEO_CONF.prop_deed` A
INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` B
  ON A.STRT = B.STRT
    AND A.CITY_NM = B.CITY_NM
    AND A.ST_CD = B.ST_CD
    AND A.PSTL_CD = B.PSTL_CD
--WHERE REGEXP_CONTAINS(A.STRT, '5072 BRIGHT( )?HAMPTON')
--  AND A.ST_CD = 'GA'
;

CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_deed2`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
 ) AS
WITH
  t02 AS
    ( SELECT 
        CLIP
        , EFF_BGN_DT
        , COALESCE(
            LEAD(EFF_BGN_DT) OVER(PARTITION BY CLIP ORDER BY EFF_BGN_DT)
          , DATE('9999-12-31')
        ) EFF_END_DT
      FROM t01
      GROUP BY 1, 2
    )
  , t03 AS
    ( SELECT
        A.*
        , ARRAY_AGG(STRUCT(SALE_DT, SALE_AMT, INV_PRCH_IND)
            ORDER BY
            CASE WHEN SALE_DT IS NOT NULL THEN 0 ELSE 1 END
            , CASE WHEN SALE_AMT IS NOT NULL THEN 0 ELSE 1 END
            , CASE WHEN B.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
            , B.EFF_END_DT DESC
            LIMIT 1)[SAFE_OFFSET(0)].* 
        , ARRAY_AGG(OWNR_OCC_IND
            ORDER BY
            CASE WHEN OWNR_OCC_IND IS NOT NULL THEN 0 ELSE 1 END
            , CASE WHEN B.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
            , B.EFF_END_DT DESC
            LIMIT 1)[SAFE_OFFSET(0)] AS OWNR_OCC_IND
        , ARRAY_AGG(LAND_USE_CD
          ORDER BY
          CASE WHEN LAND_USE_CD IS NOT NULL THEN 0 ELSE 1 END
          , CASE WHEN B.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
          , B.EFF_END_DT DESC
          LIMIT 1)[SAFE_OFFSET(0)] AS LAND_USE_CD
      FROM t02 A
      LEFT JOIN t01 B
        ON A.CLIP = B.CLIP
          AND B.EFF_BGN_DT <= A.EFF_BGN_DT
      GROUP BY 1, 2, 3
    )
  , t04 AS 
    ( SELECT 
        A.* EXCEPT(EFF_BGN_DT, EFF_END_DT)
        , `analytics-views-thd.GEO.udf_mrg_intvls`(
            ARRAY_AGG(
              STRUCT(
                UNIX_MILLIS(TIMESTAMP(EFF_BGN_DT)) AS intervalStart
                , UNIX_MILLIS(TIMESTAMP(EFF_END_DT)) AS intervalEnd
              )
            ) ) AS intervals
      FROM t03 A
      GROUP BY 1, 2, 3, 4, 5, 6
    )
SELECT
  CAST(TIMESTAMP_MILLIS(i.intervalStart) AS DATE) EFF_BGN_DT
  , CASE WHEN
      CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE) = '9999-12-31'
      THEN CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE)
      ELSE DATE_SUB( CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE), INTERVAL 1 DAY)
      END EFF_END_DT
  , A.* EXCEPT(intervals)
FROM
  t04 A
  , UNNEST(intervals) i
ORDER BY 2 DESC
;
