/* =====================================================================
  Create Date:    2022-07-22    Faith Andren 
                  2022-10-31    Celine Wang
                  2022-12-02    Faith Andren
  Purpose:        Create a table of property list from listing data,
                  which contains the features of a house, such as
                  remodel year, data of kitchen and bath update storm
                  indicator etc..
                  
  Steps:          1)  Grab data from GEO_CONF.prop_list
  
  Notes:          - When this source MLS listing table is built,
                    the majority of the demographic features have logic
                    that carries over the latest known value from
                    previous effective date period when the current
                    period has nulls.
                  - Updates to a listing will create a new row in the
                    data, so the feature ORIG_LIST_DT allows for
                    identifying the first date for the many edits to the
                    listing.
                  - Source listing data does not have 100% U.S. coverage
                    from MLS, and THD has only licensed a certain number
                    or years worth of data. Due to this, properties
                    without listings in MLS covered counties within that
                    timeframe were inserted with all null values.
                  - Not including rental clips
                    
  Enhancements?   - Add more features from list table that might be valuable
===================================================================== */

CREATE OR REPLACE TABLE
`analytics-mkt-analytics-thd.hf_dev.stg_cpnt_list`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
) AS
SELECT
  CLIP
  , ARRAY_AGG(
      STRUCT(
        -- Indicates whether the home is currently on the market
        ON_MKT_IND
        -- Number of days currently on market (if on market)
        , CASE WHEN ON_MKT_IND IS TRUE
            THEN DATE_DIFF(CURRENT_DATE, ORIG_LIST_DT, DAY)
          END AS CURR_ON_MKT_DAYS
        -- Number of days off market (if off market)
        , CASE WHEN ON_MKT_IND IS FALSE
            THEN DATE_DIFF(CURRENT_DATE, CURR_OFF_MKT_DT, DAY)
          END AS CURR_OFF_MKT_DAYS -- you will see nulls for inserted props
        -- Property's last listing had it listed for rent
        , LIST_RENT_IND
        -- last year the home was listed as having been remodeled
        , YR_BUILT
        , CASE
            WHEN YR_BUILT IS NULL THEN CAST(RMDL_YR AS INT64)
            ELSE
              IF( CAST(RMDL_YR AS INT64) > YR_BUILT
                  , CAST(RMDL_YR AS INT64)
                  , NULL
                )
          END AS RMDL_YR
        , CASE WHEN PATIO_IND = 1 THEN TRUE END AS PATIO_IND
        , CASE WHEN DECK_IND = 1 THEN TRUE END AS DECK_IND
        , CASE WHEN SHED_IND = 1 THEN TRUE END AS SHED_IND
        , CASE WHEN IRRIGATION_IND = 1 THEN TRUE END AS IRRIGATION_IND
        -- comments regarding storm/hurricane/high impact features
        , CASE WHEN STORM_IND = 1 THEN TRUE END AS STORM_IND
        , CASE WHEN STORM_DOOR_IND = 1 THEN TRUE END AS STORM_DOOR_IND
        , CASE WHEN STORM_WNDW_IND = 1 THEN TRUE END AS STORM_WNDW_IND
        , CASE WHEN STORM_SHUTT_IND = 1 THEN TRUE END AS STORM_SHUTT_IND
        , CASE WHEN STORM_ROOM_IND = 1 THEN TRUE END AS STORM_ROOM_IND
        -- Last date listed as having a kitchen renovation
        , KIT_UPD_DT AS LAST_KIT_UPD_DT
        -- Last date listed as having a bathroom renovation
        , BATH_UPD_DT AS LAST_BATH_UPD_DT --
        , CASE WHEN BALCONY_IND = 1 THEN TRUE END AS BALCONY_IND
        , CASE WHEN PORCH_IND = 1 THEN TRUE END AS PORCH_IND
        , CASE WHEN BBQ_AREA_IND = 1 THEN TRUE END AS BBQ_AREA_IND
        , CASE WHEN FIREPLACE_IND = 1 THEN TRUE END AS FIREPLACE_IND
        , CASE WHEN FIREPIT_IND = 1 THEN TRUE END AS FIREPIT_IND
        , CASE WHEN SOLAR_IND = 1 THEN TRUE END AS SOLAR_IND
        -- comments regarding the condition of fence (not fenced/ partially fenced/fenced)
        , FENCE
        , CASE WHEN UNFNSHD_BSMT_IND = 1 THEN TRUE END AS UNFNSHD_BSMT_IND
        , CASE WHEN FLR_WOOD_IND = 1 THEN TRUE END AS FLR_WOOD_IND
        , FLR_WOOD_UPD_DT
        , CASE WHEN FLR_CRPT_IND = 1 THEN TRUE END AS FLR_CRPT_IND
        , FLR_CRPT_UPD_DT
        , CASE WHEN FLR_TILE_IND = 1 THEN TRUE END AS FLR_TILE_IND
        , FLR_TILE_UPD_DT
        , CASE WHEN FLR_VINYL_IND = 1 THEN TRUE END AS FLR_VINYL_IND
        , FLR_VINYL_UPD_DT
        , CASE WHEN FLR_LAMINATE_IND = 1 THEN TRUE END AS FLR_LAMINATE_IND
        , FLR_LAMINATE_UPD_DT
        , WNDW_UPD_DT
        , CASE WHEN WNDW_TRTMNT_IND = 1 THEN TRUE END AS WNDW_TRTMNT_IND
        , CASE WHEN WNDW_BAY_IND = 1 THEN TRUE END  AS WNDW_BAY_IND
        , CASE WHEN WNDW_INSULATED_IND = 1 THEN TRUE END AS WNDW_INSULATED_IND
         -- Last date listed as having cabinets updated
        , CBNT_UPD_DT
        , CNTR_UPD_DT
        , CASE WHEN GRG_IND = 1 THEN TRUE END AS GRG_IND
        , CASE WHEN GRG_ATTACHED_IND = 1 THEN TRUE END AS GRG_ATTACHED_IND
        , CASE WHEN GRG_DETACHED_IND = 1 THEN TRUE END AS GRG_DETACHED_IND
        , CASE WHEN GRG_UNFINISHED_IND = 1 THEN TRUE END AS GRG_UNFINISHED_IND
        , CASE WHEN GRG_DOOR_OPENER_IND = 1 THEN TRUE END AS GRG_DOOR_OPENER_IND
        , CASE WHEN GRG_1CAR_IND = 1 THEN TRUE END AS GRG_1CAR_IND
        , CASE WHEN GRG_2CAR_IND = 1 THEN TRUE END AS GRG_2CAR_IND
        , CASE WHEN GRG_3CARPLUS_IND = 1 THEN TRUE END AS GRG_3CARPLUS_IND
        , CASE WHEN GRG_CARPORT_IND = 1 THEN TRUE END AS GRG_CARPORT_IND
        , CASE WHEN GRG_CABINETS_IND = 1 THEN TRUE END AS GRG_CABINETS_IND
        , CASE WHEN GRG_STORAGE_IND = 1 THEN TRUE END AS GRG_STORAGE_IND
        , GRG_SPACES
        , GRG_AREA
      )
      ORDER BY EFF_BGN_DT DESC
      LIMIT 1
    )[SAFE_OFFSET(0)].*
FROM `analytics-views-thd.GEO_CONF.prop_list` A
INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` B
  ON A.STRT = B.STRT
    AND A.CITY_NM = B.CITY_NM
    AND A.ST_CD = B.ST_CD
    AND A.PSTL_CD = B.PSTL_CD
WHERE EFF_END_DT = '9999-12-31' -- Current Record for the Property
  AND A.STRT IS NOT NULL
  AND A.CITY_NM IS NOT NULL
  AND A.ST_CD IS NOT NULL
  AND A.PSTL_CD IS NOT NULL
GROUP BY 1
;

















CREATE OR REPLACE TABLE
`analytics-mkt-analytics-thd.hf_dev.stg_cpnt_list2`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
) AS
WITH
  t01 AS 
    ( SELECT 
        B.CLIP
        , ARRAY_AGG(DISTINCT KIT_UPD_DT IGNORE NULLS) KIT_UPD_DTS
        , ARRAY_AGG(DISTINCT BATH_UPD_DT IGNORE NULLS) BATH_UPD_DTS
        , ARRAY_AGG(DISTINCT FLR_WOOD_UPD_DT IGNORE NULLS) FLR_WOOD_UPD_DTS
        , ARRAY_AGG(DISTINCT FLR_CRPT_UPD_DT IGNORE NULLS) FLR_CRPT_UPD_DTS
        , ARRAY_AGG(DISTINCT FLR_TILE_UPD_DT IGNORE NULLS) FLR_TILE_UPD_DTS
        , ARRAY_AGG(DISTINCT FLR_VINYL_UPD_DT IGNORE NULLS) FLR_VINYL_UPD_DTS
        , ARRAY_AGG(DISTINCT FLR_LAMINATE_UPD_DT IGNORE NULLS) FLR_LAMINATE_UPD_DTS
        , ARRAY_AGG(DISTINCT WNDW_UPD_DT IGNORE NULLS) WNDW_UPD_DTS
        , ARRAY_AGG(DISTINCT CBNT_UPD_DT IGNORE NULLS) CBNT_UPD_DTS
        , ARRAY_AGG(DISTINCT CNTR_UPD_DT IGNORE NULLS) CNTR_UPD_DTS
      FROM `analytics-views-thd.GEO_CONF.prop_list` A
      INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` B
        ON A.STRT = B.STRT
          AND A.CITY_NM = B.CITY_NM
          AND A.ST_CD = B.ST_CD
          AND A.PSTL_CD = B.PSTL_CD
      GROUP BY 1
    )
  , t02 AS
    ( SELECT 
        B.CLIP
        , CASE WHEN DT < EFF_BGN_DT THEN DT ELSE EFF_BGN_DT END EFF_BGN_DT
        , CASE WHEN DT < EFF_BGN_DT THEN EFF_BGN_DT-1 ELSE EFF_END_DT END EFF_END_DT 
        -- Indicates whether the home is currently on the market
        , CASE WHEN DT < EFF_BGN_DT THEN TRUE ELSE ON_MKT_IND END ON_MKT_IND

        -- Property's last listing had it listed for rent
        , LIST_RENT_IND
        -- last year the home was listed as having been remodeled
        , YR_BUILT
        , CASE
            WHEN YR_BUILT IS NULL THEN CAST(RMDL_YR AS INT64)
            ELSE
              IF( CAST(RMDL_YR AS INT64) > YR_BUILT
                  , CAST(RMDL_YR AS INT64)
                  , NULL
                )
          END AS RMDL_YR
        , CASE WHEN PATIO_IND = 1 THEN TRUE END AS PATIO_IND
        , CASE WHEN DECK_IND = 1 THEN TRUE END AS DECK_IND
        , CASE WHEN SHED_IND = 1 THEN TRUE END AS SHED_IND
        , CASE WHEN IRRIGATION_IND = 1 THEN TRUE END AS IRRIGATION_IND
        -- comments regarding storm/hurricane/high impact features
        , CASE WHEN STORM_IND = 1 THEN TRUE END AS STORM_IND
        , CASE WHEN STORM_DOOR_IND = 1 THEN TRUE END AS STORM_DOOR_IND
        , CASE WHEN STORM_WNDW_IND = 1 THEN TRUE END AS STORM_WNDW_IND
        , CASE WHEN STORM_SHUTT_IND = 1 THEN TRUE END AS STORM_SHUTT_IND
        , CASE WHEN STORM_ROOM_IND = 1 THEN TRUE END AS STORM_ROOM_IND
        -- Last date listed as having a kitchen renovation
        , ( SELECT MIN(X)
            FROM UNNEST(ARRAY_CONCAT([KIT_UPD_DT], IFNULL(KIT_UPD_DTS, []))) X
            WHERE X >= CASE WHEN DT < EFF_BGN_DT THEN DT ELSE EFF_BGN_DT END
          ) AS LAST_KIT_UPD_DT
        -- Last date listed as having a bathroom renovation
        , ( SELECT MIN(X)
            FROM UNNEST(ARRAY_CONCAT([BATH_UPD_DT], IFNULL(BATH_UPD_DTS, []))) X
            WHERE X >= CASE WHEN DT < EFF_BGN_DT THEN DT ELSE EFF_BGN_DT END
          ) AS LAST_BATH_UPD_DT --
        , CASE WHEN BALCONY_IND = 1 THEN TRUE END AS BALCONY_IND
        , CASE WHEN PORCH_IND = 1 THEN TRUE END AS PORCH_IND
        , CASE WHEN BBQ_AREA_IND = 1 THEN TRUE END AS BBQ_AREA_IND
        , CASE WHEN FIREPLACE_IND = 1 THEN TRUE END AS FIREPLACE_IND
        , CASE WHEN FIREPIT_IND = 1 THEN TRUE END AS FIREPIT_IND
        , CASE WHEN SOLAR_IND = 1 THEN TRUE END AS SOLAR_IND
        -- comments regarding the condition of fence (not fenced/ partially fenced/fenced)
        , FENCE
        , CASE WHEN UNFNSHD_BSMT_IND = 1 THEN TRUE END AS UNFNSHD_BSMT_IND
        , CASE WHEN FLR_WOOD_IND = 1 THEN TRUE END AS FLR_WOOD_IND
        , ( SELECT MIN(X)
            FROM UNNEST(ARRAY_CONCAT([FLR_WOOD_UPD_DT], IFNULL(FLR_WOOD_UPD_DTS, []))) X
            WHERE X >= CASE WHEN DT < EFF_BGN_DT THEN DT ELSE EFF_BGN_DT END
          ) AS FLR_WOOD_UPD_DT
        , CASE WHEN FLR_CRPT_IND = 1 THEN TRUE END AS FLR_CRPT_IND
        , ( SELECT MIN(X)
            FROM UNNEST(ARRAY_CONCAT([FLR_CRPT_UPD_DT], IFNULL(FLR_CRPT_UPD_DTS, []))) X
            WHERE X >= CASE WHEN DT < EFF_BGN_DT THEN DT ELSE EFF_BGN_DT END
          ) AS FLR_CRPT_UPD_DT
        , CASE WHEN FLR_TILE_IND = 1 THEN TRUE END AS FLR_TILE_IND
        , ( SELECT MIN(X)
            FROM UNNEST(ARRAY_CONCAT([FLR_TILE_UPD_DT], IFNULL(FLR_TILE_UPD_DTS, []))) X
            WHERE X >= CASE WHEN DT < EFF_BGN_DT THEN DT ELSE EFF_BGN_DT END
          ) AS FLR_TILE_UPD_DT
        , CASE WHEN FLR_VINYL_IND = 1 THEN TRUE END AS FLR_VINYL_IND
        , ( SELECT MIN(X)
            FROM UNNEST(ARRAY_CONCAT([FLR_VINYL_UPD_DT], IFNULL(FLR_VINYL_UPD_DTS, []))) X
            WHERE X >= CASE WHEN DT < EFF_BGN_DT THEN DT ELSE EFF_BGN_DT END
          ) AS FLR_VINYL_UPD_DT
        , CASE WHEN FLR_LAMINATE_IND = 1 THEN TRUE END AS FLR_LAMINATE_IND
        , ( SELECT MIN(X)
            FROM UNNEST(ARRAY_CONCAT([FLR_LAMINATE_UPD_DT], IFNULL(FLR_LAMINATE_UPD_DTS, []))) X
            WHERE X >= CASE WHEN DT < EFF_BGN_DT THEN DT ELSE EFF_BGN_DT END
          ) AS FLR_LAMINATE_UPD_DT
        , ( SELECT MIN(X)
            FROM UNNEST(ARRAY_CONCAT([WNDW_UPD_DT], IFNULL(WNDW_UPD_DTS, []))) X
            WHERE X >= CASE WHEN DT < EFF_BGN_DT THEN DT ELSE EFF_BGN_DT END
          ) AS WNDW_UPD_DT
        , CASE WHEN WNDW_TRTMNT_IND = 1 THEN TRUE END AS WNDW_TRTMNT_IND
        , CASE WHEN WNDW_BAY_IND = 1 THEN TRUE END  AS WNDW_BAY_IND
        , CASE WHEN WNDW_INSULATED_IND = 1 THEN TRUE END AS WNDW_INSULATED_IND
          -- Last date listed as having cabinets updated
        , ( SELECT MIN(X)
            FROM UNNEST(ARRAY_CONCAT([CBNT_UPD_DT], IFNULL(CBNT_UPD_DTS, []))) X
            WHERE X >= CASE WHEN DT < EFF_BGN_DT THEN DT ELSE EFF_BGN_DT END
          ) AS CBNT_UPD_DT
        , ( SELECT MIN(X)
            FROM UNNEST(ARRAY_CONCAT([CNTR_UPD_DT], IFNULL(CNTR_UPD_DTS, []))) X
            WHERE X >= CASE WHEN DT < EFF_BGN_DT THEN DT ELSE EFF_BGN_DT END
          ) AS CNTR_UPD_DT
        , CASE WHEN GRG_IND = 1 THEN TRUE END AS GRG_IND
        , CASE WHEN GRG_ATTACHED_IND = 1 THEN TRUE END AS GRG_ATTACHED_IND
        , CASE WHEN GRG_DETACHED_IND = 1 THEN TRUE END AS GRG_DETACHED_IND
        , CASE WHEN GRG_UNFINISHED_IND = 1 THEN TRUE END AS GRG_UNFINISHED_IND
        , CASE WHEN GRG_DOOR_OPENER_IND = 1 THEN TRUE END AS GRG_DOOR_OPENER_IND
        , CASE WHEN GRG_1CAR_IND = 1 THEN TRUE END AS GRG_1CAR_IND
        , CASE WHEN GRG_2CAR_IND = 1 THEN TRUE END AS GRG_2CAR_IND
        , CASE WHEN GRG_3CARPLUS_IND = 1 THEN TRUE END AS GRG_3CARPLUS_IND
        , CASE WHEN GRG_CARPORT_IND = 1 THEN TRUE END AS GRG_CARPORT_IND
        , CASE WHEN GRG_CABINETS_IND = 1 THEN TRUE END AS GRG_CABINETS_IND
        , CASE WHEN GRG_STORAGE_IND = 1 THEN TRUE END AS GRG_STORAGE_IND
        , GRG_SPACES
        , GRG_AREA
        , ORIG_LIST_DT
        , CURR_OFF_MKT_DT AS OFF_MKT_DT 
      FROM `analytics-views-thd.GEO_CONF.prop_list` A
      INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` B
        ON A.STRT = B.STRT
          AND A.CITY_NM = B.CITY_NM
          AND A.ST_CD = B.ST_CD
          AND A.PSTL_CD = B.PSTL_CD
      LEFT JOIN UNNEST([CASE WHEN ORIG_LIST_DT< EFF_BGN_DT THEN ORIG_LIST_DT END, EFF_BGN_DT]) DT
      LEFT JOIN t01 C ON B.CLIP = C.CLIP
      
    )
  , t03 AS 
    ( SELECT
        CLIP
        , EFF_BGN_DT
        ,  COALESCE(
              LEAD(EFF_BGN_DT) OVER(PARTITION BY CLIP ORDER BY EFF_BGN_DT)
            , DATE('9999-12-31')
          ) EFF_END_DT
        , ARRAY_AGG(
            ( SELECT AS STRUCT 
                A.* EXCEPT(EFF_BGN_DT, EFF_END_DT, CLIP)

            )
            ORDER BY 
              CASE WHEN ON_MKT_IND IS TRUE THEN 0 ELSE 1 END
              , EFF_END_DT DESC
        )[SAFE_OFFSET(0)].*
      FROM t02 A
      GROUP BY 1, 2
    )
   , t04 AS 
    ( SELECT 
        A.* EXCEPT(EFF_BGN_DT, EFF_END_DT)
        , `analytics-views-thd.GEO.udf_mrg_intvls`(
            ARRAY_AGG(
              STRUCT(
                UNIX_MILLIS(TIMESTAMP(EFF_BGN_DT)) AS intervalStart
                , UNIX_MILLIS(TIMESTAMP(EFF_END_DT)) AS intervalEnd
              )
            ) ) AS intervals
      FROM t03 A
      
      WHERE EFF_END_DT >= CURRENT_DATE-1095
      GROUP BY 
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10
        , 11, 12, 13, 14, 15, 16, 17, 18, 19, 20
        , 21, 22, 23, 24, 25, 26, 27, 28, 29, 30
        , 31, 32, 33, 34, 35, 36, 37, 38, 39, 40
        , 41, 42, 43, 44, 45, 46, 47, 48, 49, 50
        , 51, 52, 53, 54, 55
    )
SELECT
  CAST(TIMESTAMP_MILLIS(i.intervalStart) AS DATE) EFF_BGN_DT
  , CASE WHEN
      CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE) = '9999-12-31'
      THEN CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE)
      ELSE DATE_SUB( CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE), INTERVAL 1 DAY)
      END EFF_END_DT
  , A.* EXCEPT(intervals)
FROM
  t04 A
  , UNNEST(intervals) i
ORDER BY 2 DESC
;