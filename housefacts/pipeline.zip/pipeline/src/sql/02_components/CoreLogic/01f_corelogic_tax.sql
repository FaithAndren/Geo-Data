/* =====================================================================
  Create Date:    2022-07-22    Faith Andren
                  2022-10-31    Celine Wang
                  2022-12-02    Faith Andren
                  
  Purpose:        Create a table of property list from tax data, along
                  with the up-to-date features of a property, including
                  property land use, Living squarefeet, # of baths etc..
                  
  Steps:          1)  Grab latest assessed property features of homes.
  
  Notes:          - Tax table's atomic level is standardized property
                    (STRT, CITY_NM, ST_CD, PSTL_CD) x effective dates
                    (EFF_BGN_DT, EFF_END_DT). Each property will not
                    have any overlapping effective dates.
                  - When this source tax assessment table is built,
                    the majority of the demographic features have logic
                    that carries over the latest known value from
                    previous effective date period when the current
                    period has nulls.
                    
  Enhancements?   - Add more features from tax table that might be
                    valuable.
                  - For dev version, we'll store atomic level at the
                    four property IDs, but for prod, we'll connect to
                    the STD_PROP_ID that we'll create.
===================================================================== */

CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_tax`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
) AS
SELECT
  B.CLIP
  , ARRAY_AGG(
      STRUCT(
        YR_BUILT
        , LAND_USE_CD
        , ACRES
        , LVG_SQFT
        , FULL_BATH_CNT
        , HALF_BATH_CNT
        , BEDRM_CNT
        , BLDG_CD
        , CASE WHEN POOL_IND = 'Y' THEN TRUE END AS POOL_IND
        , GRG_PRKG_SQFT
        , GRG_CD
        , BLDG_QUAL_CD
        , COND_CD
        , CASE WHEN FRPLC_IND = 'Y' THEN TRUE END AS FRPLC_IND 
        , BSMT_FINSH_CD, BSMT_TYP_CD, BSMT_SQFT
        , EXTR_WALL_CD
        , STRY_NBRS
      )
    ORDER BY COALESCE(SALE_DT, EFF_END_DT) DESC
    LIMIT 1
  )[SAFE_OFFSET(0)].*
FROM `analytics-views-thd.GEO_CONF.prop_tax` A
INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` B
  ON A.STRT = B.STRT
    AND A.CITY_NM = B.CITY_NM
    AND A.ST_CD = B.ST_CD
    AND A.PSTL_CD = B.PSTL_CD
WHERE A.EFF_END_DT = '9999-12-31'
GROUP BY 1;


INSERT `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_tax`
WITH
  -- map to legal records using parent address (e.g. apartment complex)
  t02 AS
    ( SELECT
        A.CLIP
        , ARRAY_AGG(LAND_USE_CD
            ORDER BY
              CASE WHEN LAND_USE_CD IS NOT NULL
              THEN 0 ELSE 1 END
            LIMIT 1
        )[SAFE_OFFSET(0)] LAND_USE_CD
      FROM `analytics-mkt-analytics-thd.hf_pr.clip_curr` A
      INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` B
        ON A.PRNT_CLIP = B.CLIP
      INNER JOIN `analytics-views-thd.GEO_CONF.prop_tax` C
        ON B.STRT = C.STRT
          AND B.CITY_NM = C.CITY_NM
          AND B.ST_CD = C.ST_CD
          AND B.PSTL_CD = C.PSTL_CD
      WHERE A.PRNT_CLIP IS NOT NULL
        AND EFF_END_DT = '9999-12-31'
      GROUP BY 1
    )
SELECT
  A.CLIP
  , CAST(NULL AS INT64) AS YR_BUILT
  , A.LAND_USE_CD
  , CAST(NULL AS FLOAT64) AS ACRES
  , CAST(NULL AS INT64) AS LVG_SQFT
  , CAST(NULL AS INT64) AS FULL_BATH_CNT
  , CAST(NULL AS INT64) AS HALF_BATH_CNT
  , CAST(NULL AS INT64) AS BEDRM_CNT
  , CAST(NULL AS STRING) AS BLDG_CD
  , CAST(NULL AS BOOL) AS POOL_IND
  , CAST(NULL AS FLOAT64) AS GRG_PRKG_SQFT
  , CAST(NULL AS STRING) AS GRG_CD
  , CAST(NULL AS STRING) AS BLDG_QUAL_CD
  , CAST(NULL AS STRING) AS COND_CD
  , CAST(NULL AS BOOL) AS FRPLC_IND
  , CAST(NULL AS STRING) AS BSMT_FINSH_CD
  , CAST(NULL AS STRING) AS BSMT_TYP_CD
  , CAST(NULL AS INT64) AS BSMT_SQFT
  , CAST(NULL AS STRING) AS EXTR_WALL_CD
  , CAST(NULL AS INT64) AS STRY_NBRS
FROM t02 A
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_tax` B
  ON A.CLIP = B.CLIP
WHERE B.CLIP IS NULL;













CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_tax2`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
) AS
WITH
  -- Grab all timeframes for CLIP tax effective dates
  t01 AS 
    ( SELECT
        B.CLIP
        , A.EFF_BGN_DT
        , COALESCE(
            LEAD(EFF_BGN_DT) OVER(PARTITION BY CLIP ORDER BY EFF_BGN_DT) - 1
          , DATE('9999-12-31')
        ) EFF_END_DT
      FROM `analytics-views-thd.GEO_CONF.prop_tax` A
      INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` B
        ON A.STRT = B.STRT
          AND A.CITY_NM = B.CITY_NM
          AND A.ST_CD = B.ST_CD
          AND A.PSTL_CD = B.PSTL_CD
      GROUP BY 1, 2
    )
SELECT
  A.*
  , ARRAY_AGG(CASE WHEN TRIM(CARRIER_ROUTE) != '' THEN CARRIER_ROUTE END
      ORDER BY
        CASE WHEN TRIM(COALESCE(CARRIER_ROUTE, '')) != '' THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] CARRIER_ROUTE
  , ARRAY_AGG(
      CASE WHEN EXTRACT(YEAR FROM A.EFF_BGN_DT) BETWEEN YR_BUILT
        AND EXTRACT(YEAR FROM A.EFF_END_DT)
        THEN YR_BUILT END
      ORDER BY
        CASE WHEN EXTRACT(YEAR FROM A.EFF_BGN_DT) BETWEEN YR_BUILT
            AND EXTRACT(YEAR FROM A.EFF_END_DT)
          THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS YR_BUILT
  , ARRAY_AGG(
      CASE WHEN EXTRACT(YEAR FROM A.EFF_BGN_DT) BETWEEN EFF_YR_BUILT
        AND EXTRACT(YEAR FROM A.EFF_END_DT)
        THEN EFF_YR_BUILT END
      ORDER BY
        CASE WHEN EXTRACT(YEAR FROM A.EFF_BGN_DT) BETWEEN EFF_YR_BUILT
            AND EXTRACT(YEAR FROM A.EFF_END_DT)
          THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS EFF_YR_BUILT
  , ARRAY_AGG(LAND_USE_CD
      ORDER BY
        CASE WHEN LAND_USE_CD IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
        -- A non-unknown value (e.g. 100 = Residential not classified)
        , CASE WHEN NOT REGEXP_CONTAINS(LAND_USE_CD, '00$|^9')
          THEN 0 ELSE 1 END
      LIMIT 1)[SAFE_OFFSET(0)] AS LAND_USE_CD
  , ARRAY_AGG(
      -- Latest known value of attribute even if null
      STRUCT(
        ZONING_CD
        , ST_USE_DESC
        , MBL_HM_IND
        , PROP_IND_CD
        , NBR_BLDGS
        , NBR_UNTS
        , BLDG_CD
        , BLDG_IMPR_CD
      )
      ORDER BY
        CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
    LIMIT 1)[SAFE_OFFSET(0)].*
  , ARRAY_AGG(VIEW_CD
      ORDER BY
      CASE WHEN VIEW_CD IS NOT NULL THEN 0 ELSE 1 END
      , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
      , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS VIEW_CD
  , ARRAY_AGG(LOC_INFL_CD
      ORDER BY
      CASE WHEN LOC_INFL_CD IS NOT NULL THEN 0 ELSE 1 END
      , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
      , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS LOC_INFL_CD

  , ARRAY_AGG(
      CASE WHEN
        ASSD_YR <= EXTRACT(YEAR FROM A.EFF_END_DT - 1)
      THEN
        STRUCT(
            ASSD_TOT_VAL, ASSD_LAND_VAL, ASSD_IMPR_VAL
            , APPR_TOT_VAL, APPR_LAND_VAL, APPR_IMPR_VAL
            , ASSD_YR, HMSTD_EXMPT, SR_EXMPT, DSBL_EXMPT
            , VET_EXMPT, WDW_EXMPT
          )
      ELSE NULL END IGNORE NULLS
      ORDER BY
        CASE WHEN ASSD_TOT_VAL IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN EXTRACT(YEAR FROM A.EFF_END_DT - 1) = ASSD_YR
          THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)].*
    , ARRAY_AGG(
      CASE WHEN
        C.SALE_DT <= A.EFF_END_DT
        OR C.EFF_END_DT <= A.EFF_END_DT
      THEN
          STRUCT(
            OWNR_RIGHT_CD, OWNR_OCC_CD
            , OWNR_1_FULL_NM, OWNR_1_FRST_NM, OWNR_1_LAST_NM
            , OWNR_2_FULL_NM, OWNR_2_FRST_NM, OWNR_2_LAST_NM
            , OWNR_3_FULL_NM, OWNR_3_FRST_NM, OWNR_3_LAST_NM
            , OWNR_4_FULL_NM, OWNR_4_FRST_NM, OWNR_4_LAST_NM
            , OWNR_1_CORP_IND, OWNR_2_CORP_IND, OWNR_3_CORP_IND, OWNR_4_CORP_IND
          )
        ELSE NULL END IGNORE NULLS
        ORDER BY
          CASE WHEN OWNR_1_FULL_NM IS NOT NULL THEN 0 ELSE 1 END
          , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
          , C.EFF_END_DT DESC
        LIMIT 1)[SAFE_OFFSET(0)].*
  , ARRAY_AGG(
      CASE WHEN
          TAX_YR <= EXTRACT(YEAR FROM A.EFF_END_DT)
        THEN STRUCT(TAX_AMT, TAX_YR)
      ELSE NULL END IGNORE NULLS
      ORDER BY
        CASE WHEN TAX_AMT IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN EXTRACT(YEAR FROM A.EFF_END_DT) = TAX_YR
          THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)].*
  , ARRAY_AGG(
      CASE WHEN SALE_DT < A.EFF_END_DT
      THEN STRUCT(SALE_DT, SALE_AMT)
      ELSE NULL END IGNORE NULLS
      ORDER BY
        CASE WHEN SALE_DT IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN SALE_AMT IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)].*
  , ARRAY_AGG(ACRES
      ORDER BY
        CASE WHEN ACRES IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS ACRES
  , ARRAY_AGG(LAND_SQFT
      ORDER BY
        CASE WHEN LAND_SQFT IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS LAND_SQFT
  , ARRAY_AGG(LVG_SQFT
      ORDER BY
        CASE WHEN LVG_SQFT IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS LVG_SQFT
  , ARRAY_AGG(CASE WHEN FRPLC_IND = 'Y' THEN TRUE END 
      ORDER BY
        CASE WHEN FRPLC_IND = 'Y' THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS FRPLC_IND
  , ARRAY_AGG(
      STRUCT(
        BEDRM_CNT, TOT_RM_CNT, FULL_BATH_CNT
        , HALF_BATH_CNT, BATH_FXTR_CNT
      )
      ORDER BY
        CASE WHEN BEDRM_CNT IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)].*
  , ARRAY_AGG(STRUCT(BSMT_FINSH_CD, BSMT_TYP_CD)
      ORDER BY
        CASE WHEN BSMT_FINSH_CD IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)].*
  , ARRAY_AGG(BSMT_SQFT
      ORDER BY
        CASE WHEN BSMT_SQFT IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS BSMT_SQFT
  , ARRAY_AGG(CSTRN_TYP_CD
      ORDER BY
        CASE WHEN CSTRN_TYP_CD IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS CSTRN_TYP_CD
  , ARRAY_AGG(EXTR_WALL_CD
      ORDER BY
        CASE WHEN EXTR_WALL_CD IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS EXTR_WALL_CD
  , ARRAY_AGG(COND_CD
      ORDER BY
        CASE WHEN COND_CD IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS COND_CD
  , ARRAY_AGG(FLR_CD
      ORDER BY
        CASE WHEN FLR_CD IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS FLR_CD
  , ARRAY_AGG(STRUCT(GRG_PRKG_SQFT,GRG_CD)
      ORDER BY
        CASE WHEN GRG_PRKG_SQFT IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)].*
  , ARRAY_AGG(CASE WHEN POOL_IND = 'Y' THEN TRUE END
      ORDER BY
        CASE WHEN POOL_IND = 'Y' THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] POOL_IND
  , ARRAY_AGG(BLDG_QUAL_CD
      ORDER BY
        CASE WHEN BLDG_QUAL_CD IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS BLDG_QUAL_CD
  , ARRAY_AGG(ROOF_CVR_CD
      ORDER BY
        CASE WHEN ROOF_CVR_CD IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS ROOF_CVR_CD
  , ARRAY_AGG(ROOF_TYP_CD
      ORDER BY
        CASE WHEN ROOF_TYP_CD IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS ROOF_TYP_CD
  , ARRAY_AGG(STRY_CD
      ORDER BY
        CASE WHEN STRY_CD IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS STRY_CD
  , ARRAY_AGG(STRY_NBRS
      ORDER BY
        CASE WHEN STRY_NBRS IS NOT NULL THEN 0 ELSE 1 END
        , CASE WHEN C.EFF_END_DT <= A.EFF_END_DT THEN 0 ELSE 1 END
        , C.EFF_END_DT DESC
      LIMIT 1)[SAFE_OFFSET(0)] AS STRY_NBRS
FROM t01 A 
INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` B 
  ON A.CLIP = B.CLIP
INNER JOIN `analytics-views-thd.GEO_CONF.prop_tax` C
  ON B.STRT = C.STRT
    AND B.CITY_NM = C.CITY_NM
    AND B.ST_CD = C.ST_CD
    AND B.PSTL_CD = C.PSTL_CD
    AND C.EFF_BGN_DT <= A.EFF_BGN_DT
--WHERE A.CLIP = "8428047786"
GROUP BY 1, 2, 3;
  

INSERT 
  `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_tax2`
  (CLIP, LAND_USE_CD, EFF_BGN_DT, EFF_END_DT)
WITH
  -- map to legal records using parent address (e.g. apartment complex)
  t02 AS
    ( SELECT
        A.CLIP
        , ARRAY_AGG(STRUCT(LAND_USE_CD, EFF_BGN_DT)
            ORDER BY
              CASE WHEN LAND_USE_CD IS NOT NULL
              THEN 0 ELSE 1 END
              , EFF_BGN_DT DESC
            LIMIT 1
        )[SAFE_OFFSET(0)].*
      FROM `analytics-mkt-analytics-thd.hf_pr.clip_curr` A
      INNER JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` B
        ON A.PRNT_CLIP = B.CLIP
      INNER JOIN `analytics-views-thd.GEO_CONF.prop_tax` C
        ON B.STRT = C.STRT
          AND B.CITY_NM = C.CITY_NM
          AND B.ST_CD = C.ST_CD
          AND B.PSTL_CD = C.PSTL_CD
      WHERE A.PRNT_CLIP IS NOT NULL
        AND EFF_END_DT = '9999-12-31'
      GROUP BY 1
    )
SELECT
  A.CLIP
  , A.LAND_USE_CD
  , A.EFF_BGN_DT
  , DATE('9999-12-31') EFF_END_DT
FROM t02 A
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_tax2` B
  ON A.CLIP = B.CLIP
WHERE B.CLIP IS NULL;

