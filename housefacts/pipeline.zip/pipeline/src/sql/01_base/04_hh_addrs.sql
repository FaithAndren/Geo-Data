/* =====================================================================

  Create Date:    2022-11-20  Faith Andren
  As of Date:

  Purpose:        Create x-ref of HH to best CLIP #.

  Steps:          1)  Grab all HHs tied a property address and
                      standardize address.
                  2)  Create street variations to increase match rate.
                  3)  Grab properties that only have one known city ever
                      associated with it to maximize later match rate.
                  4)  Grab properties that only have one known zip ever
                      associated with it
                  5)  Create flags for those addresses
                  5)  Join HH Properties to legal CoreLogic addresses.
                      - 1: First on standardized address
                      - 2: Next, address with units but without quadrant
                      - 3: Then, addresses without quadrants
                      - 4: Lastly, addresses without unit or quadrants
                  6)  Aggregate HH to best CLIP.

  Notes:          -   We exclude HHs that map to more than one CLIP
                      (~3,100).

  Enhancements?   -

===================================================================== */


CREATE OR REPLACE TEMP TABLE t02 AS
WITH
  -- Grab all HHs tied a property address and standardize address
  t01 AS
    ( SELECT
        HH.HH_ID AS THD_HH_ID
        , `analytics-views-thd.GEO.udf_strt_std`(
            addr_txt.addr_line1_txt
            , addr_txt.addr_line2_txt
          ) AS STRT
        , `analytics-views-thd.GEO.udf_clns_city`(addr_txt.city_nm) AS CITY_NM
        , `analytics-views-thd.GEO.udf_clns_stcd`(addr_txt.st_cd) AS ST_CD
        , `analytics-views-thd.GEO.udf_clns_zip`(addr_txt.pstl_cd) AS PSTL_CD
      FROM `pr-edw-views-thd.CUST_CORE_CONF.CUSTOMER_DETAIL_US`
      WHERE NULLIF(TRIM(addr_txt.addr_line1_txt), '') IS NOT NULL
        AND NULLIF(TRIM(addr_txt.city_nm), '') IS NOT NULL
        AND NULLIF(TRIM(addr_txt.st_cd), '') IS NOT NULL
        AND NULLIF(TRIM(addr_txt.pstl_cd), '') IS NOT NULL
        --AND COALESCE(prospect_household_flag, 0) != 3
        AND REGEXP_CONTAINS(HH.HH_ID, '^HHH')
      GROUP BY 1, 2, 3, 4, 5
      HAVING STRT IS NOT NULL
        AND CITY_NM IS NOT NULL
        AND ST_CD IS NOT NULL
        AND PSTL_CD IS NOT NULL
    )
-- Create street variations to increase later match rate.
SELECT
  A.*
  -- Street with unit & without ending directional
  , CONCAT(
      REGEXP_EXTRACT(SPLIT(STRT, ' # ')[SAFE_OFFSET(0)]
        , '(^.*) (?:N|E|S|W|NE|NW|SE|SW)$')
      , ' # ', SPLIT(STRT, ' # ')[SAFE_OFFSET(1)]
    ) AS STRT_B
  -- Street without unit #
  , SPLIT(STRT, ' # ')[SAFE_OFFSET(0)] AS STRT_C
  -- Street without unit # or ending directional
  , REGEXP_EXTRACT(SPLIT(STRT, ' # ')[SAFE_OFFSET(0)]
      , '(^.*) (?:N|E|S|W|NE|NW|SE|SW)$')  AS STRT_D
FROM t01 A;


-- Create flag for addresses that only have one known city ever
CREATE OR REPLACE TEMP TABLE t05 AS
WITH
  -- Grab properties that only have one known city ever associated with it
  t03 AS
    ( SELECT STRT, ST_CD, PSTL_CD
      FROM `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars`
      GROUP BY 1, 2, 3
      HAVING COUNT(DISTINCT CITY_NM) = 1
        AND COUNT(DISTINCT BEST_CLIP) = 1
    )
  -- Grab properties that only have one known zip ever associated with it
  , t04 AS
    ( SELECT STRT, ST_CD, CITY_NM
      FROM `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars`
      GROUP BY 1, 2, 3
      HAVING COUNT(DISTINCT PSTL_CD) = 1
        AND COUNT(DISTINCT BEST_CLIP) = 1
    )
SELECT
  A.*
  , CASE WHEN B.STRT IS NOT NULL THEN 1 ELSE 0 END NO_CITY_FLG
  , CASE WHEN C.STRT IS NOT NULL THEN 1 ELSE 0 END NO_ZIP_FLG
FROM `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars` A
LEFT JOIN t03 B
  ON A.STRT = B.STRT
    AND A.ST_CD = B.ST_CD
    AND A.PSTL_CD = B.PSTL_CD
LEFT JOIN t04 C
  ON A.STRT = C.STRT
    AND A.ST_CD = C.ST_CD
    AND A.CITY_NM = C.CITY_NM
;

-- Join HH Properties to legal CoreLogic addresses
CREATE OR REPLACE TEMP TABLE t06 AS
SELECT
  A.*
  , COALESCE(B.BEST_CLIP, C.BEST_CLIP, D.BEST_CLIP, E.BEST_CLIP) BEST_CLIP
  , CASE WHEN COALESCE(D.BEST_CLIP, E.BEST_CLIP) IS NOT NULL
    AND REGEXP_CONTAINS(A.STRT, " # ")
    THEN 1 ELSE 0 END PRNT_FLG
FROM t02 A
-- Left join on standardized address
LEFT JOIN t05 B
  ON A.STRT = B.STRT
    AND
      ( A.CITY_NM = B.CITY_NM
        OR B.NO_CITY_FLG = 1
      )
    AND A.ST_CD = B.ST_CD
    AND
      ( A.PSTL_CD = B.PSTL_CD
        OR
          ( A.CITY_NM = B.CITY_NM
            AND B.NO_ZIP_FLG = 1
          )
      )
-- Left join on standardized address with units but without quadrant
LEFT JOIN t05 C
  ON B.STRT IS NULL
    AND A.STRT_B IS NOT NULL
    AND A.STRT_B = C.STRT
    AND
      ( A.CITY_NM = C.CITY_NM
        OR C.NO_CITY_FLG = 1
      )
    AND A.ST_CD = C.ST_CD
    AND
      ( A.PSTL_CD = C.PSTL_CD
        OR
          ( A.CITY_NM = C.CITY_NM
            AND C.NO_ZIP_FLG = 1
          )
      )
-- Left join w/o Unit
LEFT JOIN t05 D
  ON COALESCE(B.STRT, C.STRT) IS NULL
    AND A.STRT_C IS NOT NULL
    AND A.STRT_C = D.STRT
    AND
      ( A.CITY_NM = D.CITY_NM
        OR D.NO_CITY_FLG = 1
      )
    AND A.ST_CD = D.ST_CD
    AND
      ( A.PSTL_CD = D.PSTL_CD
        OR
          ( A.CITY_NM = D.CITY_NM
            AND D.NO_ZIP_FLG = 1
          )
      )
-- Left join w/o unit and w/o quadrant
LEFT JOIN t05 E
  ON COALESCE(B.STRT, C.STRT, D.STRT) IS NULL
    AND A.STRT_D IS NOT NULL
    AND A.STRT_D = E.STRT
    AND
      ( A.CITY_NM = E.CITY_NM
        OR E.NO_CITY_FLG = 1
      )
    AND A.ST_CD = E.ST_CD
    AND
      ( A.PSTL_CD = E.PSTL_CD
        OR
          ( A.CITY_NM = E.CITY_NM
            AND E.NO_ZIP_FLG = 1
          )
      )
;

-- Create HH to best CLIP table
CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_dev.stg_hh_clip`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
 ) AS
SELECT
  THD_HH_ID
  , ANY_VALUE(
      STRUCT(
          STRT, CITY_NM, ST_CD, PSTL_CD
          , CASE  WHEN PRNT_FLG = 0 THEN BEST_CLIP END AS CLIP
          , CASE WHEN PRNT_FLG = 1
              THEN CONCAT(BEST_CLIP, '-#', SPLIT(STRT, ' # ')[SAFE_OFFSET(1)])
            END AS NEW_CLIP
          , CASE WHEN PRNT_FLG = 1 THEN BEST_CLIP END AS PRNT_CLIP
      )
    ).*
FROM t06
WHERE BEST_CLIP IS NOT NULL
GROUP BY 1
HAVING COUNT(DISTINCT BEST_CLIP) = 1
;
