/* =====================================================================

  Create Date:    2022-06-23    Faith Andren
  As of Date:

  Purpose:        Create list of all known owners of properties and flag
                  the current owner(s) of the property.

  Steps:          1)  Grab all property owners (historic and current)
                      for each property and flag their current ownership
                      status along with min/max effective dates.
                  2)  Array aggregate records that may indicate the same
                      person that had a potential last name change to
                      their spouse's last name.
                  3)  Create list of potential name changes.
                  4)  Unnest the array of records that may indicate one
                      person onto their own lines while associating
                      the values of a whole to each line (e.g. expanding
                      ownership dates to entire length instead of only
                      the time where they had that specific last name).
                  5)  Replace ownership flag and ownership dates with
                      values that represent the person as a whole
                      instead of their specific last name.

  Notes:          - The property deeds data comes from vendor CoreLogic
                    and is funded by the Marketing Analytics team under
                    Anand Matthew.

  Enhancements?   - We could account for non-overlapping ownership
                    effective dates (e.g. person sold their house and
                    later bought it back), but those cases are likely
                    too rare to warrant complicating the logic (making
                    it harder for others to understand).
                  - The creation of the cleansed tax/deed tables doesn't
                    use the same CLIP consolidation logic that we now
                    use, so mapping won't be as clean.
                  - We need to exclude specific transaction types from
                    the deed file (e.g. refinance).

===================================================================== */

-- Grab all property owners and flag their current ownership status
CREATE OR REPLACE TEMP TABLE t01 AS
WITH
  DEED AS
    ( SELECT
        STRT, STRT_NO_QUAD, CITY_NM, ST_CD, PSTL_CD
        , SPLIT(COALESCE(
            OWNR_FRST_NM
            , CASE WHEN REGEXP_CONTAINS(OWNR_LAST_NM, "^[a-zA-Z- ']+$")
                AND REGEXP_CONTAINS(OWNR_FULL_NM, OWNR_LAST_NM)
                THEN
                  -- Grab the first token of the full name that doesn't
                  -- contain the last name (this complex step is to account
                  -- for hyphenated names).
                  ( SELECT ARRAY_AGG(X ORDER BY PLC LIMIT 1)[SAFE_OFFSET(0)]
                    FROM UNNEST(SPLIT(OWNR_FULL_NM, ' ')) X WITH OFFSET PLC
                    WHERE 1 = 1
                      AND
                        CASE
                          WHEN REGEXP_CONTAINS(OWNR_LAST_NM, "^[a-zA-Z- ']+$")
                            THEN NOT REGEXP_CONTAINS(X, OWNR_LAST_NM)
                       END
                  )
              END
          ), ' ')[SAFE_OFFSET(0)] OWNR_FRST_NM
          , OWNR_LAST_NM
          , MIN(CASE WHEN OWNR_FLG = 1 THEN SALE_DT
            ELSE CAST(NULL AS DATE) END) MIN_OWNR_DT
          , MAX(CASE WHEN OWNR_FLG = 1 THEN EFF_END_DT
            ELSE EFF_BGN_DT - 1 END) MAX_OWNR_DT
      FROM
        `analytics-views-thd.GEO_CONF.prop_deed`
        -- Create a row for every owner by unnesting array of the
        -- the columns for current and previous owners
        , UNNEST(
            [ -- Owner One
              CASE WHEN OWNR_1_LAST_NM IS NOT NULL THEN
                STRUCT(
                  OWNR_1_FULL_NM AS OWNR_FULL_NM
                  , OWNR_1_FRST_NM AS OWNR_FRST_NM
                  , OWNR_1_LAST_NM AS OWNR_LAST_NM
                  , 1 AS OWNR_FLG
                )
              END
              -- Owner Two
              , CASE WHEN OWNR_2_LAST_NM IS NOT NULL THEN
                  STRUCT(
                    COALESCE(OWNR_2_FULL_NM, OWNR_1_FULL_NM) AS OWNR_FULL_NM
                    , OWNR_2_FRST_NM AS OWNR_FRST_NM
                    , OWNR_2_LAST_NM AS OWNR_LAST_NM
                    , 1 AS OWNR_FLG
                  )
                END
              -- Owner Two B
              , CASE WHEN OWNR_1_LAST_NM IS NOT NULL
                  AND REGEXP_CONTAINS(OWNR_1_FULL_NM, ' & ') THEN
                  STRUCT(
                    OWNR_1_FULL_NM AS OWNR_FULL_NM
                    , SPLIT(
                        SPLIT(OWNR_1_FULL_NM, ' & ')[SAFE_OFFSET(1)]
                        , ' ')[SAFE_OFFSET(0)] AS OWNR_FRST_NM
                    , OWNR_1_LAST_NM AS OWNR_LAST_NM
                    , 1 AS OWNR_FLG
                  )
                END
              -- Owner Three
              , CASE WHEN OWNR_3_LAST_NM IS NOT NULL THEN
                  STRUCT(
                    COALESCE(OWNR_3_FULL_NM, OWNR_1_FULL_NM
                      , OWNR_2_FULL_NM
                    ) AS OWNR_FULL_NM
                    , OWNR_3_FRST_NM AS OWNR_FRST_NM
                    , OWNR_3_LAST_NM AS OWNR_LAST_NM
                    , 1 AS OWNR_FLG
                  )
                END
              -- Owner Four
              , CASE WHEN OWNR_4_LAST_NM IS NOT NULL THEN
                  STRUCT(
                    COALESCE(OWNR_4_FULL_NM, OWNR_1_FULL_NM
                      , OWNR_2_FULL_NM, OWNR_3_FULL_NM
                    ) AS OWNR_FULL_NM
                    , OWNR_4_FRST_NM AS OWNR_FRST_NM
                    , OWNR_4_LAST_NM AS OWNR_LAST_NM
                    , 1 AS OWNR_FLG
                  )
                END
              -- Seller One
              , CASE WHEN SELLR_1_LAST_NM IS NOT NULL THEN
                  STRUCT(
                    SELLR_1_FULL_NM AS OWNR_FULL_NM
                    , SPLIT(SELLR_1_FRST_NM, ' ')[SAFE_OFFSET(0)] AS OWNR_FRST_NM
                    , SELLR_1_LAST_NM AS OWNR_LAST_NM
                    , 0 AS OWNR_FLG
                  )
                END
              -- Seller Two
              , CASE WHEN SELLR_2_FULL_NM IS NOT NULL THEN
                  STRUCT(
                    SELLR_2_FULL_NM AS OWNR_FULL_NM
                    , SPLIT(SELLR_2_FULL_NM, ' ')[SAFE_OFFSET(1)] AS OWNR_FRST_NM
                    , SPLIT(SELLR_2_FULL_NM, ' ')[SAFE_OFFSET(0)] AS OWNR_LAST_NM
                    , 0 AS OWNR_FLG
                  )
                END
              -- Seller Two B
              , CASE WHEN SELLR_1_FULL_NM IS NOT NULL
                  AND REGEXP_CONTAINS(SELLR_1_FULL_NM, ' & ')
                  AND SELLR_1_LAST_NM IS NOT NULL THEN
                  STRUCT(
                    SELLR_1_FULL_NM AS OWNR_FULL_NM
                    , SPLIT(
                        SPLIT(SELLR_1_FULL_NM, ' & ')[SAFE_OFFSET(1)]
                        , ' ')[SAFE_OFFSET(0)] AS OWNR_FRST_NM
                    , SELLR_1_LAST_NM AS OWNR_LAST_NM
                    , 0 AS OWNR_FLG
                  )
                END
              -- Seller Two C
              , CASE WHEN SELLR_2_FULL_NM IS NOT NULL
                  AND REGEXP_CONTAINS(SELLR_2_FULL_NM, ' & ') THEN
                  STRUCT(
                    SELLR_2_FULL_NM AS OWNR_FULL_NM
                    , SPLIT(
                        SPLIT(SELLR_2_FULL_NM, ' & ')[SAFE_OFFSET(1)]
                        , ' ')[SAFE_OFFSET(0)] AS OWNR_FRST_NM
                    , SPLIT(SELLR_2_FULL_NM, ' ')[SAFE_OFFSET(0)] AS OWNR_LAST_NM
                    , 0 AS OWNR_FLG
                  )
                END
              -- Principal Investor One
              , CASE WHEN PRIN_1_LAST_NM IS NOT NULL THEN
                  STRUCT(
                    PRIN_1_FULL_NM AS OWNR_FULL_NM
                    , SPLIT(PRIN_1_FRST_NM, ' ')[SAFE_OFFSET(0)] AS OWNR_FRST_NM
                    , PRIN_1_LAST_NM AS OWNR_LAST_NM
                    , 1 AS OWNR_FLG
                  )
                END
              -- Principal Investor Two
              , CASE WHEN PRIN_1_LAST_NM IS NOT NULL
                  AND REGEXP_CONTAINS(PRIN_1_FULL_NM, ' & ') THEN
                  STRUCT(
                    PRIN_1_FULL_NM AS OWNR_FULL_NM
                    , SPLIT(
                        SPLIT(PRIN_1_FULL_NM, ' & ')[SAFE_OFFSET(1)]
                        , ' ')[SAFE_OFFSET(0)] AS OWNR_FRST_NM
                    , PRIN_1_LAST_NM AS OWNR_LAST_NM
                    , 1 AS OWNR_FLG
                  )
                END
            ]
          ) OWNR
      WHERE OWNR_LAST_NM IS NOT NULL
        AND TRANS_TYP IN
          -- Only consider sale transactions (e.g. not refinances)
          ( "1"   -- RESALE (45% records)
            , "3" -- SUBDIVISION/NEW CONSTRUCTION (3.4% records)
            , "7" -- SELLER CARRYBACK (0.5% records)
          )
      GROUP BY 1, 2, 3, 4, 5, 6, 7
      HAVING OWNR_LAST_NM IS NOT NULL
    )
  , TAX AS
    ( SELECT
        STRT, STRT_NO_QUAD, CITY_NM, ST_CD, PSTL_CD
        , SPLIT(COALESCE(
            OWNR_FRST_NM
            , CASE WHEN REGEXP_CONTAINS(OWNR_LAST_NM, "^[a-zA-Z- ']+$")
                AND REGEXP_CONTAINS(OWNR_FULL_NM, OWNR_LAST_NM)
                THEN
                  -- Grab the first token of the full name that doesn't
                  -- contain the last name (this complex step is to account
                  -- for hyphenated names).
                  ( SELECT ARRAY_AGG(X ORDER BY PLC LIMIT 1)[SAFE_OFFSET(0)]
                    FROM UNNEST(SPLIT(OWNR_FULL_NM, ' ')) X WITH OFFSET PLC
                    WHERE 1 = 1
                      AND
                        CASE
                          WHEN REGEXP_CONTAINS(OWNR_LAST_NM, "^[a-zA-Z- ']+$")
                            THEN NOT REGEXP_CONTAINS(X, OWNR_LAST_NM)
                       END
                  )
              END
          ), ' ')[SAFE_OFFSET(0)] OWNR_FRST_NM
          , OWNR_LAST_NM
          , MIN(SALE_DT) MIN_OWNR_DT
          , MAX(EFF_END_DT) MAX_OWNR_DT
      FROM
        `analytics-views-thd.GEO_CONF.prop_tax`
        -- Create a row for every owner by unnesting array of the
        -- the columns for current and previous owners
        , UNNEST(
            [ -- Owner One
              CASE WHEN OWNR_1_LAST_NM IS NOT NULL THEN
                STRUCT(
                  OWNR_1_FULL_NM AS OWNR_FULL_NM
                  , OWNR_1_FRST_NM AS OWNR_FRST_NM
                  , OWNR_1_LAST_NM AS OWNR_LAST_NM
                  , 1 AS OWNR_FLG
                )
              END
              -- Owner Two
              , CASE WHEN OWNR_2_LAST_NM IS NOT NULL THEN
                  STRUCT(
                    COALESCE(OWNR_2_FULL_NM, OWNR_1_FULL_NM) AS OWNR_FULL_NM
                    , OWNR_2_FRST_NM AS OWNR_FRST_NM
                    , OWNR_2_LAST_NM AS OWNR_LAST_NM
                    , 1 AS OWNR_FLG
                  )
                END
              -- Owner Two B
              , CASE WHEN OWNR_1_LAST_NM IS NOT NULL
                  AND REGEXP_CONTAINS(OWNR_1_FULL_NM, ' & ') THEN
                  STRUCT(
                    OWNR_1_FULL_NM AS OWNR_FULL_NM
                    , SPLIT(
                        SPLIT(OWNR_1_FULL_NM, ' & ')[SAFE_OFFSET(1)]
                        , ' ')[SAFE_OFFSET(0)] AS OWNR_FRST_NM
                    , OWNR_1_LAST_NM AS OWNR_LAST_NM
                    , 1 AS OWNR_FLG
                  )
                END
              -- Owner Three
              , CASE WHEN OWNR_3_LAST_NM IS NOT NULL THEN
                  STRUCT(
                    COALESCE(OWNR_3_FULL_NM, OWNR_1_FULL_NM
                      , OWNR_2_FULL_NM
                    ) AS OWNR_FULL_NM
                    , OWNR_3_FRST_NM AS OWNR_FRST_NM
                    , OWNR_3_LAST_NM AS OWNR_LAST_NM
                    , 1 AS OWNR_FLG
                  )
                END
              -- Owner Four
              , CASE WHEN OWNR_4_LAST_NM IS NOT NULL THEN
                  STRUCT(
                    COALESCE(OWNR_4_FULL_NM, OWNR_1_FULL_NM
                      , OWNR_2_FULL_NM, OWNR_3_FULL_NM
                    ) AS OWNR_FULL_NM
                    , OWNR_4_FRST_NM AS OWNR_FRST_NM
                    , OWNR_4_LAST_NM AS OWNR_LAST_NM
                    , 1 AS OWNR_FLG
                  )
                END
            ]
          ) OWNR
      WHERE OWNR_LAST_NM IS NOT NULL
      GROUP BY 1, 2, 3, 4, 5, 6, 7
      HAVING OWNR_LAST_NM IS NOT NULL
    )
  , t03 AS
    ( SELECT * FROM DEED
      UNION DISTINCT
      SELECT * FROM TAX
    )
SELECT
  STRT, STRT_NO_QUAD, CITY_NM, ST_CD, PSTL_CD
  , OWNR_FRST_NM
  , OWNR_LAST_NM
  , MIN(MIN_OWNR_DT) MIN_OWNR_DT
  , MAX(MAX_OWNR_DT) MAX_OWNR_DT
FROM t03
GROUP BY 1, 2, 3, 4, 5, 6, 7;

DELETE FROM t01
WHERE OWNR_FRST_NM = 'RECORD' 
  AND OWNR_LAST_NM = 'OWNER';


-- Grab records that may indicate potential last name changes to their
-- spouse's last name.
CREATE OR REPLACE TEMP TABLE t02 AS
SELECT
  A.STRT, A.STRT_NO_QUAD, A.CITY_NM, A.ST_CD, A.PSTL_CD
  , A.MIN_OWNR_DT, A.MAX_OWNR_DT
  , B.OWNR_FRST_NM
  , ARRAY_AGG(
      STRUCT(
        B.OWNR_LAST_NM
        , B.MIN_OWNR_DT
        , B.MAX_OWNR_DT
      )
    ) PPL
  , MAX(
        CASE WHEN REGEXP_CONTAINS(B.OWNR_LAST_NM, "^[a-zA-Z- ']+$")
          THEN REGEXP_CONTAINS(A.OWNR_LAST_NM, B.OWNR_LAST_NM)
        END
        OR
        CASE WHEN REGEXP_CONTAINS(A.OWNR_LAST_NM, "^[a-zA-Z- ']+$")
          THEN REGEXP_CONTAINS(B.OWNR_LAST_NM, A.OWNR_LAST_NM)
        END
        ) SPOUSE_NAME_FLG
FROM t01 A
INNER JOIN t01 B
  ON A.STRT = B.STRT
    AND COALESCE(A.STRT_NO_QUAD, '') = COALESCE(B.STRT_NO_QUAD, '')
    AND A.CITY_NM = B.CITY_NM
    AND A.ST_CD = B.ST_CD
    AND A.PSTL_CD = B.PSTL_CD
    AND B.MIN_OWNR_DT BETWEEN A.MIN_OWNR_DT AND A.MAX_OWNR_DT
    AND B.MAX_OWNR_DT BETWEEN A.MIN_OWNR_DT AND A.MAX_OWNR_DT
    AND NOT
      ( B.MIN_OWNR_DT = A.MIN_OWNR_DT
        AND B.MAX_OWNR_DT = A.MAX_OWNR_DT
      )
    AND B.OWNR_FRST_NM != A.OWNR_FRST_NM
GROUP BY 1, 2, 3, 4, 5, 6, 7, 8
HAVING ARRAY_LENGTH(PPL) > 1
  AND SPOUSE_NAME_FLG IS TRUE
  ;

CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_dev.stg_prop_ownr_full`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
) AS
WITH
  -- Create the list of potential name changes.
  t03 AS
    ( SELECT
        A.* EXCEPT(PPL)
        , PPL.OWNR_LAST_NM AS OWNR_LAST_NM
        , PPL.MIN_OWNR_DT AS MIN_OWNR_DT_OLD
        , PPL.MAX_OWNR_DT AS MAX_OWNR_DT_OLD
      FROM t02 A, UNNEST(PPL) PPL
    )
  , t04 AS
    ( SELECT
        A.* EXCEPT(MIN_OWNR_DT, MAX_OWNR_DT)
        , COALESCE(B.MIN_OWNR_DT, A.MIN_OWNR_DT) MIN_OWNR_DT
        , COALESCE(B.MAX_OWNR_DT, A.MAX_OWNR_DT) MAX_OWNR_DT
      FROM t01 A
      LEFT JOIN t03 B
        ON A.STRT = B.STRT
          AND COALESCE(A.STRT_NO_QUAD, '') = COALESCE(B.STRT_NO_QUAD, '')
          AND A.CITY_NM = B.CITY_NM
          AND A.ST_CD = B.ST_CD
          AND A.PSTL_CD = B.PSTL_CD
          AND A.OWNR_FRST_NM = B.OWNR_FRST_NM
          AND A.OWNR_LAST_NM = B.OWNR_LAST_NM
    )
SELECT
  STRT2 STRT, CITY_NM, ST_CD, PSTL_CD
  , OWNR_FRST_NM, OWNR_LAST_NM
  , MIN(MIN_OWNR_DT) MIN_OWNR_DT
  , MAX(MAX_OWNR_DT) MAX_OWNR_DT
FROM t04, UNNEST([STRT, STRT_NO_QUAD]) STRT2
WHERE STRT2 IS NOT NULL
GROUP BY 1, 2, 3, 4, 5, 6
; -- 464,807,679


-- Create version by last name
CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_dev.stg_prop_ownr_last`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
) AS
SELECT
  STRT, CITY_NM, ST_CD, PSTL_CD
  , OWNR_LAST_NM
  , MIN(MIN_OWNR_DT) MIN_OWNR_DT
  , MAX(MAX_OWNR_DT) MAX_OWNR_DT
FROM `analytics-mkt-analytics-thd.hf_dev.stg_prop_ownr_full`
GROUP BY 1, 2, 3, 4, 5; -- 305,558,191


------------------------------------------------------------------------
-- Clip Last Name Classification
------------------------------------------------------------------------
CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_pr.clip_last_nm`
AS
SELECT
  A.CLIP
  , OWNR_LAST_NM
  , MIN(MIN_OWNR_DT) MIN_OWNR_DT
  , MAX(MAX_OWNR_DT) MAX_OWNR_DT
FROM 
  `analytics-mkt-analytics-thd.hf_pr.prop_xref` A
  , `analytics-mkt-analytics-thd.hf_dev.stg_prop_ownr_last` B
WHERE A.STRT = B.STRT
  AND A.CITY_NM = B.CITY_NM
  AND A.ST_CD = B.ST_CD
  AND A.PSTL_CD = B.PSTL_CD
GROUP BY 1, 2;

INSERT `analytics-mkt-analytics-thd.hf_pr.clip_last_nm`
SELECT 
  A.CLIP
  , TRIM(NM) AS OWNR_LAST_NM
  , MIN(A.MIN_OWNR_DT) MIN_OWNR_DT
  , MAX(A.MAX_OWNR_DT) MAX_OWNR_DT
FROM 
  `analytics-mkt-analytics-thd.hf_pr.clip_last_nm` A
  , UNNEST(SPLIT(OWNR_LAST_NM, '-')) NM
LEFT JOIN `analytics-mkt-analytics-thd.hf_pr.clip_last_nm` C 
  ON A.CLIP = C.CLIP 
    AND NM = C.OWNR_LAST_NM
WHERE REGEXP_CONTAINS(A.OWNR_LAST_NM, '-')
  AND NULLIF(TRIM(NM), '') IS NOT NULL
  AND C.CLIP IS NULL
GROUP BY 1, 2;