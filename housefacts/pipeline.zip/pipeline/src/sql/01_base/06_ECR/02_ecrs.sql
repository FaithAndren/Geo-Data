/* =====================================================================

  Create Date:    2022-11-20    Faith Andren
  As of Date:

  Purpose:        Create a list of ECRs and flag as owner/previous owner
                  of a property in order to enable analysts from
                  excluding those ECRs from HH analyses

  Steps:          1)  Grab Name of ECRs and Current HH
                  2)  Assign max ownership dates to ECR for the property
                      of it's current associated HH.
                  3)  Flag ECR as bad when they're no longer an owner
                      and no one of the same last name is an owner either.

  Notes:          -

  Enhancements?   - Include a condition where there must be a non-null
                    value for the current owner or principal investor to
                    be able to definitively say the person did in fact
                    sell their house? Because, if the latest tax record
                    didn't include owner names, this process may list
                    them as no longer living there if they didn't have
                    deed records.

===================================================================== */


CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_pr.ecr_hh_ownrs`
AS
WITH
  -- Grab Name of ECRs and Current HH
  t01 AS
    ( SELECT
        ECR_PRTY_ID
        , HH.HH_ID AS THD_HH_ID
        , SPLIT(
            NULLIF(TRIM(UPPER(ecr_prty.prsn_frst_nm)), '')
            , ' ')[SAFE_OFFSET(0)] AS FRST_NM
        , NULLIF(TRIM(UPPER(ecr_prty.prsn_last_nm)), '') AS LAST_NM
      FROM `pr-edw-views-thd.CUST_CORE_CONF.CUSTOMER_DETAIL_US`
      WHERE REGEXP_CONTAINS(HH.HH_ID, '^HHH')
    )
  -- Assign max ownership date to ECR for the property of the HH
  , t02 AS
    ( SELECT
        A.*
        , MAX(D.MAX_OWNR_DT) AS MAX_FULLNM_OWNR_DT
        , MAX(E.MAX_OWNR_DT) AS MAX_LASTNM_OWNR_DT
      FROM t01 A
      LEFT JOIN `analytics-mkt-analytics-thd.hf_pr.hh_clip` B
        ON A.THD_HH_ID = B.THD_HH_ID
      LEFT JOIN `analytics-mkt-analytics-thd.hf_pr.prop_xref` C
        ON B.PRNT_CLIP IS NULL
          AND B.CLIP = C.CLIP
      LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_prop_ownr_full` D
        ON A.LAST_NM IS NOT NULL AND A.FRST_NM IS NOT NULL
        AND C.STRT = D.STRT
        AND C.CITY_NM = D.CITY_NM
        AND C.ST_CD = D.ST_CD
        AND C.PSTL_CD = D.PSTL_CD
        AND A.FRST_NM = D.OWNR_FRST_NM
        AND A.LAST_NM = D.OWNR_LAST_NM
      LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_prop_ownr_last` E
        ON A.LAST_NM IS NOT NULL
          AND C.STRT = E.STRT
          AND C.CITY_NM = E.CITY_NM
          AND C.ST_CD = E.ST_CD
          AND C.PSTL_CD = E.PSTL_CD
          AND A.LAST_NM = E.OWNR_LAST_NM
      GROUP BY 1, 2, 3, 4
      HAVING LAST_NM IS NOT NULL
    )
-- Flag ECR as bad when they're no longer an owner and no one of the
-- same last name is an owner either.
SELECT
  A.*
  , CASE
      -- Full name listed as current owner
      WHEN MAX_FULLNM_OWNR_DT = '9999-12-31' THEN 0
      -- No one with same last name is a current owner
      WHEN MAX_LASTNM_OWNR_DT < '9999-12-31' THEN 1
      -- Someone with the same last name is a current owner
      WHEN MAX_LASTNM_OWNR_DT = '9999-12-31' THEN 0
      -- Full name is no longer a current owner
      WHEN MAX_FULLNM_OWNR_DT < '9999-12-31' THEN 1
    END ECR_HH_BAD_FLG
FROM t02 A;



  

------------------------------------------------------------------------
-- Cleanup Staging Data
------------------------------------------------------------------------
DROP TABLE `analytics-mkt-analytics-thd.hf_dev.stg_prop_ownr_full`;
DROP TABLE `analytics-mkt-analytics-thd.hf_dev.stg_prop_ownr_last`;
