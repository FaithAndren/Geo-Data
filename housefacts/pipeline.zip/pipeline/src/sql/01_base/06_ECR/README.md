# Flagging Bad ECR x HH Associations

We leverage legal property tax assessments and legal property deeds to flag certain ECR x HH associations as bad when we know that that person has since sold their house.


***
### Table

`analytics-mkt-analytics-thd.hf_pr.ecr_hh_ownrs`

* **`MAX_FULLNM_OWNR_DT`**
  * Last known date that someone with that same **first and last name** was listed as an owner of the HH property.
* **`MAX_LASTNM_OWNR_DT`**
  * Last known date that someone with that same **last name** was listed as an owner of the HH property.
* **`ECR_HH_BAD_FLG`**
  * That ECR (or someone with the same last name) was a previous owner of the HH property and someone of a different last name is now listed as owner.
    * Recommended to exclude these ECRS (where = 1) from HH rollup analyses to remove noise of movers.

| **`ECR_PRTY_ID`** | **`THD_HH_ID`** | **`FRST_NM`** | **`LAST_NM`** | **`MAX_FULLNM_OWNR_DT`** | **`MAX_LASTNM_OWNR_DT`** | **`ECR_HH_BAD_FLG`** |  
| --- | --- | --- | --- | --- | --- | --- |
| `0135C8D4DE7C000D8H` | `HHH3592f681ddb34f5a8a3fe6adfd1c4697` | `CARY` | `QUALLS` | `2021-05-26` | `2021-05-26` | `1` |    
| `013377B4D9MF00227L` | `HHHe8faa3a166a6441e93223c90dd98e0a9` | `BEVERLY` | `BUSCH` | `2019-12-31` | `2021-07-21` | `1` |    
| `01335E65AFFQ0059CK` | `HHH18f867aaafea495ba659a5f82433249b` | `EVELYN` | `KAMMIN` | `2009-06-04` | `9999-12-31` | `0` |    
| `01335E65AFGC0053OF` | `HHH01f05eba06d7422ab53ac45569a3e133` | `STEVEN` | `SAUNDERS` | _null_ | `9999-12-31` | `0` | 
| `013377B4D9PP00059V` | `HHH221a5ffb384a414f955043e3745ad0c2` | `KARISMA` | `BOTTOMS` | `9999-12-31` | `9999-12-31` | `0` |    
| `01335E65AFBW003WEY` | `HHH8701af3081684fc79cc00a5d2857c0fc` | `DIANNE` | `COLEY` | _null_ | _null_ | _null_ |    

**Above Examples**
  1. Bad ECR x HH association since Cary Qualls is no longer the current owner and the current owner does not have the last name Qualls.
  2. Bad - same as #1 but note how `MAX_LASTNM_OWNR_DT` can be different than `MAX_FULLNM_OWNR_DT`.
  3. Good - Evelyn is no longer listed as an owner, however, someone with her same last name still lives there. So since THD has her still listed as living here, we play it safe by not flagging her as bad even though she is no longer an owner.
  4. Good - We've never seen Steven as an owner at that property in legal records, however, the current owner has his last name Saunders.
  5. Good - Karisma is listed as a current owner of that property in legal tax/deed records.
  6. Unknown - We haven't seen the last name Coley listed as an owner of that property, so we cannot for sure say that Dianne probably doesn't live there at the moment.
  
  
***
### Methodology

  1. Grab all property owners (historic and current) for each property and flag their current ownership status along with min/max effective dates.
  2. Account for potential maiden name changes.
  3. Grab current ECRxHH associations.
  4. Assign max ownership dates for ECRxHH based on property deed/tax ownership records.
  5. Flag ECRxHH as bad if the ECR's full name is no longer an owner **and** no one of the same last name now owns the property.
