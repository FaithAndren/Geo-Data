------------------------------------------------------------------------
# Base Data

Logic for creating the base data (atomic level) for the HouseFacts 
pipeline: one record per U.S. property address. 

Methodology:
  * **Iteration One**: internal THD [address standardization](https://github.com/one-thd/Geo-Data/wiki/UDFs#address-standardization) formula
  * **Iteration Two**: **`(CURRENT)`** consolidated internally standardized properties
    * accounting for different spelling variations and city/zip changes
  * **Iteration Three**: vendor licensed USPS standardized/validates property

***
### Iteration One

[Standardizing](https://github.com/one-thd/Geo-Data/wiki/UDFs#address-standardization) raw property addresses using internal formulas.

**Atomic Level:** `STRT`, `CITY_NM`, `ST_CD`, `PSTL_CD`

***
### Iteration Two 

Consolidating standardized raw property addresses into parent property
IDs that represents all of its standardized address variations.

**Atomic Level:** `CLIP`

1. **Legal Property Addresses** (`01_all_clips`)
  List of all known CoreLogic standardized property addresses.

2. **Standardized Address Variations** (`02_clip_consolidation`)
  Assign a best CLIP to legal Corelogic property addresses and 
  create variations of the standardized addresses (e.g. address 
  not having quadrant [`NE`, `SE`, etc.]).

3. **Address Changes** (`03_mailing_addr`)
  Grab mailing address variations to include as spelling varitions of 
  the legal addresses to account for more cases where a property's 
  city and/or postal code changed in the past.

2. **HH Property X-ref** (`04_hh_addrs`)
  Create x-ref of `THD_HH_ID` to best `CLIP`.

5. **Property Address Base** (`05_prop_xrefs`):
  Create Final Base Property Address Table along with an x-ref 
  mapping variations to specific property (`CLIP`).

***
### Iteration Three

Externally validated standardized property addresses accepted by the
USPS from vendor licensed validation data.

**Atomic Level:** `USPS_STD_PROP_ID`

***
###






***
###
