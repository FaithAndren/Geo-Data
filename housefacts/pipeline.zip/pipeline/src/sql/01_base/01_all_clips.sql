/* =====================================================================

  Create Date:    2022-11-20  Faith Andren
  As of Date:

  Purpose:        Create list of all legal CoreLogic SITUS properties.

  Steps:          1)  Grab all legal addresses from tax & deed CoreLogic
                      files.
                  2)  For legal records that represent a range of
                      addresses, split those records to have one row per
                      address in that range.
                  3)  Unnest the address ranges to their own row and
                      assign new CLIP.
                  4)  Delete newly made cases where one of those
                      unnested address ranges already existed as a row.

  Notes:          -   In an effort to keep v1 simplified, we'll only
                      use CoreLogic property records with a CLIP#.

  Enhancements?   -   Would be ideal in later iterations to use a vendor
                      to standardize the addresses to best current
                      address.

===================================================================== */


CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_dev.stg_props_situs`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
 ) AS
WITH
  -- Grab all legal addresses from tax & deed CoreLogic files.
  t01 AS
    ( SELECT
        CLIP, COMPOSITE_PROPERTY_LINKAGE_KEY
        , NULLIF(TRIM(UPPER(SITUS_HOUSE_NUMBER)), '') SITUS_HOUSE_NUMBER
        , NULLIF(TRIM(UPPER(SITUS_HOUSE_NUMBER_SUFFIX)), '') SITUS_HOUSE_NUMBER_SUFFIX
        , NULLIF(TRIM(UPPER(SITUS_HOUSE_NUMBER_2)), '') SITUS_HOUSE_NUMBER_2
        , NULLIF(TRIM(UPPER(SITUS_DIRECTION)), '') SITUS_DIRECTION
        , NULLIF(TRIM(UPPER(SITUS_STREET_NAME)), '') SITUS_STREET_NAME
        , NULLIF(TRIM(UPPER(SITUS_MODE)), '') SITUS_MODE
        , NULLIF(TRIM(UPPER(SITUS_QUADRANT)), '') SITUS_QUADRANT
        , NULLIF(TRIM(UPPER(SITUS_UNIT_NUMBER)), '') SITUS_UNIT_NUMBER
        , `analytics-views-thd.GEO.udf_clns_city`(SITUS_CITY) SITUS_CITY
        , `analytics-views-thd.GEO.udf_clns_stcd`(SITUS_STATE) SITUS_STATE
        , `analytics-views-thd.GEO.udf_clns_zip`(SITUS_ZIP_CODE) SITUS_ZIP_CODE
        , `analytics-views-thd.GEO.udf_clns_zip4`(SITUS_ZIP_CODE) SITUS_ZIP4_CODE
        , TRANSACTION_BATCH_DATE, UPDATE_TS, 0 SBL
      FROM `analytics-mkt-analytics-thd.corelogic.OLB` -- Raw Tax Assessments
      WHERE NULLIF(CLIP, '') IS NOT NULL
      GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16
      HAVING SITUS_HOUSE_NUMBER IS NOT NULL
        AND SITUS_STREET_NAME IS NOT NULL
        AND SITUS_CITY IS NOT NULL
        AND SITUS_STATE IS NOT NULL
        AND SITUS_ZIP_CODE IS NOT NULL
      UNION DISTINCT
      SELECT DISTINCT
        CLIP, COMPOSITE_PROPERTY_LINKAGE_KEY
        , NULLIF(TRIM(UPPER(SITUS_HOUSE_NUMBER)), '') SITUS_HOUSE_NUMBER
        , NULLIF(TRIM(UPPER(SITUS_HOUSE_NUMBER_SUFFIX)), '') SITUS_HOUSE_NUMBER_SUFFIX
        , NULLIF(TRIM(UPPER(SITUS_HOUSE_NUMBER_2)), '') SITUS_HOUSE_NUMBER_2
        , NULLIF(TRIM(UPPER(SITUS_DIRECTION)), '') SITUS_DIRECTION
        , NULLIF(TRIM(UPPER(SITUS_STREET_NAME)), '') SITUS_STREET_NAME
        , NULLIF(TRIM(UPPER(SITUS_MODE)), '') SITUS_MODE
        , NULLIF(TRIM(UPPER(SITUS_QUADRANT)), '') SITUS_QUADRANT
        , NULLIF(TRIM(UPPER(SITUS_UNIT_NUMBER)), '') SITUS_UNIT_NUMBER
        , `analytics-views-thd.GEO.udf_clns_city`(SITUS_CITY) SITUS_CITY
        , `analytics-views-thd.GEO.udf_clns_stcd`(SITUS_STATE) SITUS_STATE
        , `analytics-views-thd.GEO.udf_clns_zip`(SITUS_ZIP_CODE) SITUS_ZIP_CODE
        , `analytics-views-thd.GEO.udf_clns_zip4`(SITUS_ZIP_CODE) SITUS_ZIP4_CODE
        , TRANSACTION_BATCH_DATE, UPDATE_TS, 1 SBL
      FROM `analytics-mkt-analytics-thd.corelogic.SBL_Complete` -- Raw Property Deeds
      WHERE NULLIF(CLIP, '') IS NOT NULL
      GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16
      HAVING SITUS_HOUSE_NUMBER IS NOT NULL
        AND SITUS_STREET_NAME IS NOT NULL
        AND SITUS_CITY IS NOT NULL
        AND SITUS_STATE IS NOT NULL
        AND SITUS_ZIP_CODE IS NOT NULL
    )
  -- For legal records that represent a range of addresses, split those
  -- records to have one row per address in that range.
  , t02 AS
    ( SELECT
        A.*
        , GENERATE_ARRAY(
            SAFE_CAST(SPLIT(SITUS_HOUSE_NUMBER, '-')[SAFE_OFFSET(0)] AS INT64)
            , CASE WHEN SITUS_STATE != 'HI' AND
                SAFE_CAST(SPLIT(SITUS_HOUSE_NUMBER_2, '-')[SAFE_OFFSET(0)] AS INT64) < 10000
                -- using this condition to avoid errors with generating
                -- too many values in an array (likely bade data anyway)
              THEN
                SAFE_CAST(SPLIT(SITUS_HOUSE_NUMBER_2, '-')[SAFE_OFFSET(0)] AS INT64)
              END
            , 1
          ) ADDR_RNGE
      FROM t01 A
    )
-- unnest the address ranges to their own row and assign new CLIP
SELECT
  CASE
    WHEN X IS NOT NULL
    THEN CONCAT(CLIP, '-', CAST(X AS STRING))
    ELSE CLIP
  END CLIP
  , CLIP AS PRNT_CLIP
  , A.* EXCEPT(CLIP, ADDR_RNGE)
  , `analytics-views-thd.GEO.udf_strt_std`(
        ARRAY_TO_STRING(
          [ COALESCE(CAST(X AS STRING), SITUS_HOUSE_NUMBER)
            , SITUS_DIRECTION, SITUS_STREET_NAME
            , SITUS_MODE, SITUS_QUADRANT
          ], ' ', '')
        , SITUS_UNIT_NUMBER
  ) STRT
  , `analytics-views-thd.GEO.udf_strt_std`(
        ARRAY_TO_STRING(
          [ COALESCE(CAST(X AS STRING), SITUS_HOUSE_NUMBER)
            , SITUS_DIRECTION, SITUS_STREET_NAME
            , SITUS_MODE
          ], ' ', '')
        , SITUS_UNIT_NUMBER
  ) STRT_NO_QUAD
  , ROW_NUMBER() OVER(
      PARTITION BY
        COALESCE(
            CONCAT(CLIP, '-', CAST(X AS STRING))
            , CLIP
          )
      ORDER BY
        SBL DESC
        , COALESCE(TRANSACTION_BATCH_DATE, UPDATE_TS) DESC
        , UPDATE_TS DESC
    ) ADDR_RANK
FROM t02 A
LEFT JOIN UNNEST(ADDR_RNGE) X;


-- Delete newly made cases where one of those unnested address ranges
-- already existed as its own property record & clip.
DELETE FROM `analytics-mkt-analytics-thd.hf_dev.stg_props_situs`
WHERE CLIP IN
  ( SELECT A.CLIP
    FROM `analytics-mkt-analytics-thd.hf_dev.stg_props_situs` A
    LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_props_situs` B
      ON A.CLIP != B.CLIP
        AND A.PRNT_CLIP != B.PRNT_CLIP
        AND A.STRT = B.STRT
        AND A.SITUS_CITY = B.SITUS_CITY
        AND A.SITUS_STATE = B.SITUS_STATE
        AND A.SITUS_ZIP_CODE = B.SITUS_ZIP_CODE
    WHERE A.CLIP != A.PRNT_CLIP
      AND B.CLIP = B.PRNT_CLIP
    GROUP BY 1
  )
;
