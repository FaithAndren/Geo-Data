/* =====================================================================

  Create Date:    2022-11-20  Faith Andren
  As of Date:

  Purpose:        Grab mailing address variations to include as spelling
                  varitions of the legal SITUS addresses to account for
                  more cases where a property's city and/or postal code
                  changed in the past.

  Steps:          1)  Grab all mailing addresses from tax & deed
                      CoreLogic files.
                  2)  Standardize the property address and grab best CLIP.
                  3)  Keep mailing property address street variations
                      for CLIPs where the STRT is the same as SITUS to
                      account for city and/or postal changes.
                  4)  Insert these alternate mailing addresses into the
                      SITUS property address variation list.
                  5) Insert the no quad versions if not already existing.

  Notes:          -

  Enhancements?   -

===================================================================== */


CREATE OR REPLACE TEMP TABLE t02 AS
WITH
  -- Grab all mailing addresses from tax & deed CoreLogic files.
  t01 AS
    ( SELECT
        CLIP
        , NULLIF(TRIM(UPPER(MAILING_HOUSE_NUMBER)), '') MAILING_HOUSE_NUMBER
        , NULLIF(TRIM(UPPER(MAILING_DIRECTION)), '') MAILING_DIRECTION
        , NULLIF(TRIM(UPPER(MAILING_STREET_NAME)), '') MAILING_STREET_NAME
        , NULLIF(TRIM(UPPER(MAILING_MODE)), '') MAILING_MODE
        , NULLIF(TRIM(UPPER(MAILING_QUADRANT)), '') MAILING_QUADRANT
        , NULLIF(TRIM(UPPER(MAILING_UNIT_NUMBER)), '') MAILING_UNIT_NUMBER
        , `analytics-views-thd.GEO.udf_clns_city`(MAILING_CITY) MAILING_CITY
        , `analytics-views-thd.GEO.udf_clns_stcd`(MAILING_STATE) MAILING_STATE
        , `analytics-views-thd.GEO.udf_clns_zip`(MAILING_ZIP_CODE) MAILING_ZIP_CODE
      FROM `analytics-mkt-analytics-thd.corelogic.OLB`
      WHERE NULLIF(CLIP, '') IS NOT NULL
      GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
      HAVING MAILING_HOUSE_NUMBER IS NOT NULL
        AND MAILING_STREET_NAME IS NOT NULL
        AND MAILING_CITY IS NOT NULL
        AND MAILING_STATE IS NOT NULL
        AND MAILING_ZIP_CODE IS NOT NULL
      UNION DISTINCT
      SELECT DISTINCT
        CLIP
        , NULLIF(TRIM(UPPER(MAILING_HOUSE_NUMBER)), '') MAILING_HOUSE_NUMBER
        , NULLIF(TRIM(UPPER(MAILING_DIRECTION)), '') MAILING_DIRECTION
        , NULLIF(TRIM(UPPER(MAILING_STREET_NAME)), '') MAILING_STREET_NAME
        , NULLIF(TRIM(UPPER(MAILING_MODE)), '') MAILING_MODE
        , NULLIF(TRIM(UPPER(MAILING_QUADRANT)), '') MAILING_QUADRANT
        , NULLIF(TRIM(UPPER(MAILING_UNIT_NUMBER)), '') MAILING_UNIT_NUMBER
        , `analytics-views-thd.GEO.udf_clns_city`(MAILING_CITY) MAILING_CITY
        , `analytics-views-thd.GEO.udf_clns_stcd`(MAILING_STATE) MAILING_STATE
        , `analytics-views-thd.GEO.udf_clns_zip`(MAILING_ZIP_CODE) MAILING_ZIP_CODE
      FROM `analytics-mkt-analytics-thd.corelogic.SBL_Complete`
      WHERE NULLIF(CLIP, '') IS NOT NULL
      GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
      HAVING MAILING_HOUSE_NUMBER IS NOT NULL
        AND MAILING_STREET_NAME IS NOT NULL
        AND MAILING_CITY IS NOT NULL
        AND MAILING_STATE IS NOT NULL
        AND MAILING_ZIP_CODE IS NOT NULL
    )
-- Standardize the addresses & coalesce best CLIP
SELECT
  A.*
  , `analytics-views-thd.GEO.udf_strt_std`(
        ARRAY_TO_STRING(
          [ MAILING_HOUSE_NUMBER
            , MAILING_DIRECTION, MAILING_STREET_NAME
            , MAILING_MODE, MAILING_QUADRANT
          ], ' ', '')
        , MAILING_UNIT_NUMBER
  ) STRT
  , `analytics-views-thd.GEO.udf_strt_std`(
        ARRAY_TO_STRING(
          [ MAILING_HOUSE_NUMBER
            , MAILING_DIRECTION, MAILING_STREET_NAME
            , MAILING_MODE
          ], ' ', '')
        , MAILING_UNIT_NUMBER
  ) STRT_NO_QUAD
FROM t01 A;


-- Keep mailing property address street variations for CLIPs where the
-- STRT is the same as SITUS to account for city and/or postal changes.
CREATE OR REPLACE TEMP TABLE t03 AS
SELECT
  A.STRT
  , MAX(A.STRT_NO_QUAD) STRT_NO_QUAD
  , A.MAILING_CITY AS CITY_NM
  , A.MAILING_STATE AS ST_CD
  , A.MAILING_ZIP_CODE AS PSTL_CD
  , MAX(COALESCE(B.BEST_CLIP, D.BEST_CLIP)) BEST_CLIP
FROM t02 A
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars` B
  ON A.CLIP = B.BEST_CLIP
    AND
      ( A.STRT = B.STRT
        OR A.STRT_NO_QUAD = B.STRT
      )
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_clip_xref` C
  ON A.CLIP = C.CLIP
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars` D
  ON B.BEST_CLIP IS NULL
    AND C.BEST_CLIP = D.BEST_CLIP
    AND
      ( A.STRT = D.STRT
        OR A.STRT_NO_QUAD = D.STRT
      )
WHERE COALESCE(B.BEST_CLIP, D.BEST_CLIP) IS NOT NULL
GROUP BY STRT, CITY_NM, ST_CD, PSTL_CD;


-- Insert these alternate mailing addresses into the SITUS property
-- address variation list.
INSERT `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars`
SELECT
  A.* EXCEPT(STRT_NO_QUAD)
  , 0 CURR_FLG
FROM t03 A
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars` B
  ON A.STRT = B.STRT
    AND A.CITY_NM = B.CITY_NM
    AND A.ST_CD = B.ST_CD
    AND A.PSTL_CD = B.PSTL_CD
WHERE B.STRT IS NULL
GROUP BY 1, 2, 3, 4, 5;

-- Insert the no quad versions if not already existing
INSERT `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars`
SELECT
  STRT_NO_QUAD STRT, A.* EXCEPT(STRT, STRT_NO_QUAD, BEST_CLIP)
  , MAX(A.BEST_CLIP) BEST_CLIP
  , 0 CURR_FLG
FROM t03 A
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars` B
  ON A.STRT_NO_QUAD = B.STRT
    AND A.CITY_NM = B.CITY_NM
    AND A.ST_CD = B.ST_CD
    AND A.PSTL_CD = B.PSTL_CD
WHERE B.STRT IS NULL
  AND STRT_NO_QUAD IS NOT NULL
GROUP BY 1, 2, 3, 4;
