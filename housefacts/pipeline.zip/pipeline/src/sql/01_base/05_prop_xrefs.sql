/* =====================================================================

  Create Date:    2022-11-20  Faith Andren
  As of Date:

  Purpose:        Create Final Base Property Address Tables/Views with
                  HH x Clip x-ref.

  Steps:          1)  Grab existings address variations for address xref
                      table.
                  2)  Add newly seen units from THD customer data as
                      their own clip into address xref table.
                  3)  Insert HH address variations into prop xref table.
                  4)  Create Final Tables/Views for the HouseFacts 
                      Property Base
                  5)  Cleanup Staging Data
   
  Notes:           

  Enhancements?   -

===================================================================== */


-- Grab existings address variations for address xref table
CREATE OR REPLACE TEMP TABLE t01 AS
SELECT
  STRT, CITY_NM, ST_CD, PSTL_CD
  , BEST_CLIP CLIP
  , CAST(NULL AS STRING) PRNT_CLIP
  , CURR_FLG AS CURR_CLIP_ADDR_FLG
FROM `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars`;




-- Add newly seen units from THD customer data as their own clip
INSERT t01
SELECT
  CONCAT(B.STRT, ' # ', SPLIT(A.STRT, ' # ')[SAFE_OFFSET(1)]) AS STRT
  , B.CITY_NM, B.ST_CD, B.PSTL_CD
  , ARRAY_AGG(
      STRUCT(
          A.NEW_CLIP AS CLIP
          , A.PRNT_CLIP
      )
      ORDER BY
        CASE WHEN REGEXP_CONTAINS(NEW_CLIP, '-')
          THEN 1 ELSE 0 END
        , CASE WHEN A.PRNT_CLIP IS NULL THEN 0 ELSE 1 END
        , NEW_CLIP DESC
      LIMIT 1)[SAFE_OFFSET(0)].*
  , 1 CURR_CLIP_ADDR_FLG
FROM `analytics-mkt-analytics-thd.hf_dev.stg_hh_clip` A
INNER JOIN `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars` B
  ON A.PRNT_CLIP = B.BEST_CLIP
    AND B.CURR_FLG = 1
LEFT JOIN t01 C
  ON CONCAT(B.STRT, ' # ', SPLIT(A.STRT, ' # ')[SAFE_OFFSET(1)]) = C.STRT
    AND B.CITY_NM = C.CITY_NM
    AND B.ST_CD = C.ST_CD
    AND B.PSTL_CD = C.PSTL_CD
WHERE A.NEW_CLIP IS NOT NULL
  AND C.STRT IS NULL
GROUP BY 1, 2, 3, 4;


-- insert HH address variations into prop xref table
INSERT t01
SELECT
  A.STRT
  , A.CITY_NM, A.ST_CD, A.PSTL_CD
  , ARRAY_AGG(
      STRUCT(
          COALESCE(A.CLIP, NEW_CLIP) AS CLIP
          , A.PRNT_CLIP
      )
      ORDER BY
        CASE WHEN REGEXP_CONTAINS(COALESCE(A.CLIP, NEW_CLIP), '-')
          THEN 1 ELSE 0 END
        , CASE WHEN A.PRNT_CLIP IS NULL THEN 0 ELSE 1 END
        , NEW_CLIP DESC
      LIMIT 1)[SAFE_OFFSET(0)].*
  , 0 CURR_CLIP_ADDR_FLG
FROM `analytics-mkt-analytics-thd.hf_dev.stg_hh_clip` A
LEFT JOIN t01 B
  ON A.STRT = B.STRT
    AND A.CITY_NM = B.CITY_NM
    AND A.ST_CD = B.ST_CD
    AND A.PSTL_CD = B.PSTL_CD
WHERE B.STRT IS NULL
GROUP BY 1, 2, 3, 4;



-----------------------------------------------------------------------
-- Create Final Tables/Views for the HouseFacts Property Base
------------------------------------------------------------------------

-- Create Final Base Table
CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_pr.prop_xref`
AS
SELECT *
FROM t01;

-- Create a view from the final base that selects only the current
-- version of the property
CREATE OR REPLACE VIEW
  `analytics-mkt-analytics-thd.hf_pr.clip_curr`
AS
SELECT * EXCEPT(CURR_CLIP_ADDR_FLG)
FROM `analytics-mkt-analytics-thd.hf_pr.prop_xref`
WHERE CURR_CLIP_ADDR_FLG = 1;


-- Create x-ref of HH to Best Clip
CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_pr.hh_clip`
AS
SELECT
  THD_HH_ID
  , COALESCE(CLIP, NEW_CLIP) CLIP
  , PRNT_CLIP
FROM `analytics-mkt-analytics-thd.hf_dev.stg_hh_clip`
WHERE COALESCE(CLIP, NEW_CLIP) IN
  ( SELECT CLIP
    FROM `analytics-mkt-analytics-thd.hf_pr.prop_xref`
  )
;


-----------------------------------------------------------------------
-- Cleanup Staging Data to Reduce Storage Costs
------------------------------------------------------------------------
DROP TABLE `analytics-mkt-analytics-thd.hf_dev.stg_props_situs`;
DROP TABLE `analytics-mkt-analytics-thd.hf_dev.stg_clip_xref`;
DROP TABLE `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars`;
DROP TABLE `analytics-mkt-analytics-thd.hf_dev.stg_hh_clip`;
