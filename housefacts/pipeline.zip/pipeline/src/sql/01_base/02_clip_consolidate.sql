/* =====================================================================

  Create Date:    2022-11-20  Faith Andren
  As of Date:

  Purpose:        Assign a best CLIP# to legal Corelogic SITUS addresses
                  and create rows for different spelling variations.

  Steps:          1)  Grab all distinct clip x standardized address.
                  2)  Remove non-1 ranked address records if they exist
                      as a 1-rank in another CLIP.
                  3)  Null out STRT_NO_QUAD if that version exists as
                      a STRT.
                  4)  Null out STRT_NO_QUAD if two distinct STRT have
                      the same STRT_NO_QUAD.
                  5)  Assign non-rank 1 standardized addresses to only
                      one rank 1;
                  6)  Create xref of clip groups to best clip
                  7)  Grab one CLIP per non rank1 address
                  8)  Union current address with previous address
                      variations
                  9)  remove addr rank > 1 lines where rank1 line w/o
                      quadrant exists.
                  10) grab current property variations
                  11) add other property variations

  Notes:          -

  Enhancements?   -

===================================================================== */


-- Grab all distinct clip x standardized address
CREATE OR REPLACE TEMP TABLE t01 AS
SELECT
  CLIP
  , STRT
  , MAX(CASE WHEN STRT_NO_QUAD = STRT THEN NULL ELSE STRT_NO_QUAD END) STRT_NO_QUAD
  , SITUS_CITY, SITUS_STATE, SITUS_ZIP_CODE
  , MIN(ADDR_RANK) ADDR_RANK
FROM `analytics-mkt-analytics-thd.hf_dev.stg_props_situs`
GROUP BY 1, 2, 4, 5, 6;

-- remove non-1 ranked address records if they exist as a 1-rank
-- in another CLIP
CREATE OR REPLACE TEMP TABLE t02 AS
SELECT * FROM t01 WHERE ADDR_RANK = 1
UNION ALL
SELECT A.*
FROM t01 A
LEFT JOIN t01 B
  ON A.CLIP != B.CLIP
    AND A.STRT = B.STRT
    AND A.SITUS_CITY = B.SITUS_CITY
    AND A.SITUS_STATE = B.SITUS_STATE
    AND A.SITUS_ZIP_CODE = B.SITUS_ZIP_CODE
    AND B.ADDR_RANK = 1
WHERE A.ADDR_RANK > 1
  AND B.CLIP IS NULL;

-- null out STRT_NO_QUAD if that version exists as a STRT
CREATE OR REPLACE TEMP TABLE t03 AS
SELECT DISTINCT
  A.* EXCEPT(STRT_NO_QUAD)
  , CASE
      WHEN B.STRT IS NOT NULL THEN CAST(NULL AS STRING)
      WHEN A.STRT_NO_QUAD = A.STRT THEN CAST(NULL AS STRING)
    ELSE A.STRT_NO_QUAD END STRT_NO_QUAD
FROM t02 A
LEFT JOIN t02 B
  ON A.STRT != B.STRT
    AND A.CLIP != B.CLIP
    AND A.STRT_NO_QUAD IS NOT NULL
    AND A.STRT_NO_QUAD = B.STRT
    AND A.SITUS_CITY = B.SITUS_CITY
    AND A.SITUS_STATE = B.SITUS_STATE
    AND A.SITUS_ZIP_CODE = B.SITUS_ZIP_CODE
;

-- null out STRT_NO_QUAD if two distinct STRT have the same STRT_NO_QUAD
CREATE OR REPLACE TEMP TABLE t04 AS
SELECT DISTINCT
  A.* EXCEPT(STRT_NO_QUAD)
  , CASE WHEN B.STRT IS NOT NULL
    THEN CAST(NULL AS STRING) ELSE A.STRT_NO_QUAD END STRT_NO_QUAD
FROM t03 A
LEFT JOIN t03 B
  ON A.STRT != B.STRT
    AND A.CLIP != B.CLIP
    AND A.STRT_NO_QUAD IS NOT NULL
    AND B.STRT_NO_QUAD IS NOT NULL
    AND A.STRT_NO_QUAD = B.STRT_NO_QUAD
    AND A.SITUS_CITY = B.SITUS_CITY
    AND A.SITUS_STATE = B.SITUS_STATE
    AND A.SITUS_ZIP_CODE = B.SITUS_ZIP_CODE
;

-- Assign non-rank 1 standardized addresses to only one rank 1
CREATE OR REPLACE TEMP TABLE t05 AS
SELECT
  STRT, MAX(STRT_NO_QUAD) STRT_NO_QUAD
  , SITUS_CITY, SITUS_STATE, SITUS_ZIP_CODE
  , ARRAY_AGG(DISTINCT CLIP) CLIPS
  , 1 ADDR_RANK
  , MAX(CLIP) BEST_CLIP
FROM t04
WHERE ADDR_RANK = 1
GROUP BY STRT, SITUS_CITY, SITUS_STATE, SITUS_ZIP_CODE;

-- Create xref of clip groups to best clip
CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_dev.stg_clip_xref`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
) AS
SELECT BEST_CLIP, CLIP
FROM t05, UNNEST(CLIPS) CLIP
GROUP BY 1, 2;


CREATE OR REPLACE TEMP TABLE t08 AS
WITH
  -- Grab one CLIP per non rank1 address
  t07 AS
    ( SELECT
        STRT, MAX(STRT_NO_QUAD) STRT_NO_QUAD
        , SITUS_CITY, SITUS_STATE, SITUS_ZIP_CODE
        , ARRAY_AGG(CLIP
            ORDER BY ADDR_RANK, CLIP
            LIMIT 1)[SAFE_OFFSET(0)] BEST_CLIP
        , ARRAY_AGG(DISTINCT CLIP) CLIPS
        , MIN(ADDR_RANK) ADDR_RANK
      FROM t04
      WHERE ADDR_RANK > 1
      GROUP BY STRT, SITUS_CITY, SITUS_STATE, SITUS_ZIP_CODE
    )
-- Union current address with previous address variations
SELECT A.* FROM t05 A
UNION ALL
SELECT A.* EXCEPT(BEST_CLIP), B.BEST_CLIP
FROM t07 A
INNER JOIN `analytics-mkt-analytics-thd.hf_dev.stg_clip_xref` B
  ON A.BEST_CLIP = B.CLIP
;

-- remove addr rank > 1 lines where rank1 line w/o quadrant exists
CREATE OR REPLACE TEMP TABLE t09 AS
SELECT A.*
FROM t08 A
WHERE ADDR_RANK = 1
UNION ALL
SELECT A.*
FROM t08 A
LEFT JOIN t08 B ON
  A.BEST_CLIP = B.BEST_CLIP
  AND B.ADDR_RANK = 1
  AND A.STRT = B.STRT_NO_QUAD
  AND A.SITUS_CITY = B.SITUS_CITY
  AND A.SITUS_STATE = B.SITUS_STATE
  AND A.SITUS_ZIP_CODE = B.SITUS_ZIP_CODE
WHERE A.ADDR_RANK > 1 AND B.BEST_CLIP IS NULL;

-- grab current property variations
CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars`
OPTIONS (
EXPIRATION_TIMESTAMP = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)
) AS
SELECT
  STRT
  , SITUS_CITY AS CITY_NM
  , SITUS_STATE AS ST_CD
  , SITUS_ZIP_CODE AS PSTL_CD
  , BEST_CLIP
  , CASE WHEN ADDR_RANK = 1 THEN 1 ELSE 0 END CURR_FLG
FROM t09 A;

-- add alternate address variations
INSERT `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars`
SELECT
  A.STRT_NO_QUAD STRT
  , A.SITUS_CITY AS CITY_NM
  , A.SITUS_STATE AS ST_CD
  , A.SITUS_ZIP_CODE AS PSTL_CD
  , MAX(A.BEST_CLIP) BEST_CLIP
  , 0 CURR_FLG
FROM t09 A
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_props_situs_vars` B
  ON A.STRT_NO_QUAD = B.STRT
    AND A.SITUS_CITY = B.CITY_NM
    AND A.SITUS_STATE = B.ST_CD
    AND A.SITUS_ZIP_CODE = B.PSTL_CD
WHERE A.STRT_NO_QUAD IS NOT NULL
  AND B.STRT IS NULL
GROUP BY 1, 2, 3, 4, 6;
