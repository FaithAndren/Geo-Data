# Validating our Output

- [ ] Create alert for duplicates in `prop_std_chld`

***
### Pipeline Monitoring Alerts

* Child ID Duplicate Check

  ```sql
  -- # Recs = # Distinct IDs = Max ID value
  SELECT
    COUNT(*) = COUNT(DISTINCT STD_PROP_ID)
    AND COUNT(*) = MAX(STD_PROP_ID)
  FROM `analytics-mkt-analytics-thd.hf_pr.prop_std_chld`;
  ```

***
