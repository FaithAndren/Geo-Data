from google.cloud import bigquery
import pandas as pd


def upd_desc(layer,sch_dict,cols):
    """
    Update column definitions.
    """

    for n, x in enumerate(layer):
        if x.name.upper() in sch_dict:
            src_desc = sch_dict[str(x.name).upper()]
            if x.description != src_desc and len(src_desc) > 0:
                x = bigquery.SchemaField(
                    x.name, x.field_type, x.mode, src_desc, x.fields
                )
                cols += 1
        if x.field_type == 'RECORD':
            y, cols = upd_desc(list(x.fields),sch_dict,cols)

            x = bigquery.SchemaField(
                x.name , x.field_type, x.mode, x.description, tuple(y)
            )

        layer[n] = x

    return layer, cols

def col_desc(prj, ds, tbl, col_desc_tbl):
    """
    This function updates input table/view schema descriptions
    with values from a table in biquery (COL_NM, COL_DESC).

    This allows for consistent descriptions across multiple tables
    as well as a quick way to add column definitions in bigquery.

    """

    dataset_ref = bq_client.dataset(ds, project=prj)
    table_ref = dataset_ref.table(tbl)
    table = bq_client.get_table(table_ref)
    schema = table.schema

    sch_df  = bq_client.query(
        """SELECT COL_NM, COL_DESC FROM`"""
        +col_desc_tbl.strip()+"`"
    ).result().to_dataframe()
    sch_df['COL_NM'] = sch_df['COL_NM'].str.upper().str.strip()
    sch_dict = sch_df.set_index("COL_NM")["COL_DESC"].to_dict()

    cols = 0
    schema, cols = upd_desc(schema,sch_dict,cols)

    table.schema = schema
    bq_client.update_table(table, ['schema'])

    print(str(cols)+" column descriptions added/refreshed in "+(".".join([prj, ds, tbl])))

bq_client = bigquery.Client("analytics-mkt-analytics-thd")

## Auto-update table schema with column descriptions
col_desc(
    ## TARGET TABLE PROJECT
    'analytics-mkt-analytics-thd'
    ## TARGET TABLE DATASET
    , 'hf_pr'
    ## TARGET TABLE
    , 'HouseFacts_HH'
    ## BQ LOCATION OF OF THE TABLE DESCIPTIONS (COL_NM, COL_DESC)
    , 'analytics-mkt-analytics-thd.hf_pr.col_desc'
)
