/* =====================================================================
  Create Date:    2022-12-02    Faith Andren
  As of Date:     2022-12-28    Faith Andren

  Purpose:        Create the final table and HH view for HouseFacts.

  Steps:          1)  Join HouseFact components to atomic level.
                  2)  Create HH view of HouseFacts.

  Notes:

  Enhancements?   Check inline TODO comments

===================================================================== */

CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_pr.HouseFacts`
  ( CLIP STRING NOT NULL OPTIONS(DESCRIPTION="Property ID (sourced from CoreLogic)")
    , BLDG STRUCT<
        LAND_USE_TYP STRING OPTIONS(DESCRIPTION="Property Land Use Type (residential/commercial/etc.)")
        , LAND_USE_DESC STRING OPTIONS(DESCRIPTION="Property Land Use (Single Family Residence, etc.)")
        , DWLG_TYP STRING OPTIONS(DESCRIPTION="Residential Dwelling Type")
        , YR_BUILT INT64 OPTIONS(DESCRIPTION="Home Build Year")
        , REMOD_YR INT64 OPTIONS(DESCRIPTION="The last year the home was listed as having been remodeled")
        , LVNG_SQFT INT64 OPTIONS(DESCRIPTION="Living Square Feet of the home")
        , BLDG_TYP STRING OPTIONS(DESCRIPTION="The primary building type (e.g., Bowling Alley, Supermarket).")
        , BLDG_COND STRING OPTIONS(DESCRIPTION="This represents the physical condition of the main improvement (e.g., Good, Fair, Under Construction).")
        , BLDG_QUAL STRING OPTIONS(DESCRIPTION="Type of construction quality of building (e.g., excellent, economical).")
        , EXTR_WALL_TYP STRING OPTIONS(DESCRIPTION="The type and/or finish of the exterior walls")
        , STRY_NBRS FLOAT64 OPTIONS(DESCRIPTION="Number of stories associated with the building")
        , STORM_ROOM_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installation or historical realtor comments or listed exterior features indicated home having storm/safe rooms.")
        , BEDRM_CNT INT64 OPTIONS(DESCRIPTION="Number of bedrooms in home")
      > OPTIONS(DESCRIPTION="Building Features")
    , SALE STRUCT<
        SALE_DT DATE OPTIONS(DESCRIPTION="Last sale date of property (excluding nominal sales)")
        , SALE_AMT FLOAT64 OPTIONS(DESCRIPTION="Last sale amount of property")
        , OWNR_OCPD_IND BOOLEAN OPTIONS(DESCRIPTION="CoreLogic's Owner Occupied Classification")
        , INVSTR_PRCH_IND BOOLEAN OPTIONS(DESCRIPTION="Latest property sale was an investment purchase")
      > OPTIONS(DESCRIPTION="Latest Property Sale Features")
    , MRTG STRUCT<
        CURR_HOME_VAL FLOAT64 OPTIONS(DESCRIPTION="Current home value - source Corelogic's valuation model.")
        , HOME_EQTY FLOAT64 OPTIONS(DESCRIPTION="Current Estimated Home Equity ( assuming that the homeowner paid the minimum required amount)")
        , CURR_LTV FLOAT64 OPTIONS(DESCRIPTION="Current Loan to Value. Remaining mortgage balance / current home value.")
        , NBR_LIENS INT64 OPTIONS(DESCRIPTION="Number of liens currently on the property")
        , TOT_MRTG_AMT FLOAT64 OPTIONS(DESCRIPTION="Total amount of all mortgages on the property.")
        , TOT_MRTG_CURR_BAL FLOAT64 OPTIONS(DESCRIPTION="Total estimated current amount remaining on all mortgages on the property, assuming that the homeowner paid the minimum required amount")
      > OPTIONS(DESCRIPTION="Current Mortgage Features")
    , LIST STRUCT<
        ON_MKT_IND BOOLEAN OPTIONS(DESCRIPTION="Indicates whether the home is currently on the market")
        , CURR_ON_MKT_DAYS INT64 OPTIONS(DESCRIPTION="Number of days currently on market (if on market)")
        , CURR_OFF_MKT_DAYS INT64 OPTIONS(DESCRIPTION="Number of days off market (if off market)")
        , LIST_RENT_IND BOOLEAN OPTIONS(DESCRIPTION="Property's last listing had it listed for rent")
      > OPTIONS(DESCRIPTION="Latest Property Listing Features")
    , OUTDR STRUCT<
        ACRES FLOAT64 OPTIONS(DESCRIPTION="Property Acreages")
        , POOL_IND BOOLEAN OPTIONS(DESCRIPTION="Assessed as having a pool; null = unknown")
        , PATIO_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a patio.")
        , DECK_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a deck.")
        , BALCONY_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a balcony.")
        , PORCH_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a porch.")
        , BBQ_AREA_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a bbq area.")
        , FIREPIT_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a firepit.")
        , SHED_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installation or historical realtor comments or listed exterior features indicated home having a shed.")
        , PERGOLA_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installation or historical realtor comments or listed exterior features indicated home having a pergola.")
        , GAZEBO_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installation or historical realtor comments or listed exterior features indicated home having a gazebo.")
        , IRRIG_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having an irrigation system.")
        , FENCE_TYP STRING OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated the condition of fence: not fenced/ partially fenced/fenced")
        --, Todo: Roof Type
        , LAST_INSTL_DT_ROOF DATE OPTIONS (DESCRIPTION="ROOF: Last completed ROOF building permit or THD completed installations in 022-051-010/022-051-020.")
        --, Todo: Lawn
        --, Todo: Garden
      > OPTIONS(DESCRIPTION="Outdoor Features of the Property")
    , KIT STRUCT<
        LAST_KIT_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having a kitchen renovation")
        , LAST_CTOP_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having countertops updated")
        , LAST_CAB_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having new cabinets")
      > OPTIONS(DESCRIPTION="Kitchen Features")
    , FLR STRUCT<
        FLR_WOOD_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed exterior features indicated home having hard wood flooring.")
        , LAST_FLR_WOOD_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a wooden flooring update")
        , FLR_CRPT_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed exterior features indicated home having carpets.")
        , LAST_FLR_CRPT_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a carpets update")
        , FLR_VINYL_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed exterior features indicated home having vinyl flooring.")
        , LAST_FLR_VINYL_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a vinyl flooring update")
        , FLR_TILE_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed exterior features indicated home having tile flooring.")
        , LAST_FLR_TILE_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a tile flooring update")
        , FLR_LAM_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed exterior features indicated home having laminate flooring.")
        , LAST_FLR_LAM_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a tile laminate update")
      > OPTIONS(DESCRIPTION="Flooring Features")
    , BATH STRUCT<
        FULL_BATH_CNT INT64 OPTIONS(DESCRIPTION="Number of full baths in home")
        , HALF_BATH_CNT INT64 OPTIONS(DESCRIPTION="Number of half baths in home")
        , LAST_BATH_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having a bathroom renovation")
      > OPTIONS(DESCRIPTION="Bath Features")
    , GRG STRUCT<
        GRG_TYP STRING OPTIONS(DESCRIPTION="Type of Garage or Carport")
        , GRG_FINSH_IND BOOLEAN OPTIONS(DESCRIPTION="Garage finished indicator")
        , GRG_SQFT FLOAT64 OPTIONS(DESCRIPTION="This is the total square footage of the primary garage or parking area.")
        , GRG_SPCS STRING OPTIONS(DESCRIPTION="Number of Spaces Garage Has")
        , GRG_DOOR_OPENER_IND BOOLEAN OPTIONS(DESCRIPTION="Garage listed as having a garage door opener on MLS Listing")
        , GRG_CABINETS_IND BOOLEAN OPTIONS(DESCRIPTION="Garage listed as having cabinets on MLS Listing")
        , GRG_STRG_IND BOOLEAN OPTIONS(DESCRIPTION="Garage listed as having storage on MLS Listing")
      > OPTIONS(DESCRIPTION="Garage Features")
    , BSMT STRUCT<
        BSMT_TYP STRING OPTIONS(DESCRIPTION="Basement Type")
        , BSMT_SQFT FLOAT64 OPTIONS(DESCRIPTION="Basement Sqft")
        , BSMT_FNSH_CLASS STRING OPTIONS(DESCRIPTION="Basement Finish Classification")
      > OPTIONS(DESCRIPTION="Basement Features")
    , PLMB STRUCT<
        LAST_INSTL_DT_WHTR DATE OPTIONS(DESCRIPTION="Water Heater: Last completed builing permit or THD completed installations in 026-051-010/020/030/040/060/070/080.")
        --, todo: water pump
        --, todo: Septic tank
        , LAST_INSTL_DT_WFLTR DATE OPTIONS(DESCRIPTION="Water filter: Last completed builing permit or THD completed installations in 026-053-010/020")
        , LAST_INSTL_DT_WSFTR DATE OPTIONS(DESCRIPTION="Water Softener: Last completedr builing permit or THD completed installations in 026-053-030/040")
      > OPTIONS(DESCRIPTION="Plumbing Features")
    , HVAC STRUCT<
        FRPLC_IND BOOLEAN OPTIONS(DESCRIPTION="Tax assessment or historical realtor comments or listed exterior features indicated home having a fire place.")
        , LAST_INSTL_DT_HVAC DATE OPTIONS(DESCRIPTION="HVAC: Last completed HVAC building permit or THD completed installations in 026-052-010.")
        -- Todo: Portable AC
        -- Todo: Portable Heater
        -- Todo: Attic Fans
        -- Todo: Whole House Fans
        -- Todo: Insulation?
        -- Todo: Heat Pump?
      > OPTIONS(DESCRIPTION="Heating, Ventalation, and Air Conditioning Features")
    , ELEC STRUCT<
        SOLAR_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having solar power.")   
        --SOLR    Solar
        /*
        , SMRTHM STRUCT<
          > OPTIONS(DESCRIPTION="Smart Home Items/Features")*/
        -- Todo: ELEC PANL    Electric Panel
        , LAST_INSTL_DT_BTTRY DATE OPTIONS(DESCRIPTION="Home Battery: Last THD completed installation in 027-054-003.") 
        , LAST_INSTL_DT_GNRTR DATE OPTIONS(DESCRIPTION="Generator: Last THD completed installation in 027-057-010.")   
        -- Todo: RADON MTGN   Radon Mitigation 
        -- Todo: LGHT         Lighting
      > OPTIONS(DESCRIPTION="Electric/Lighting Features")
    , APLNC STRUCT<
        LAST_ORD_DT_FRDG DATE OPTIONS(DESCRIPTION="Last Known Order Date for Fridgerator")
        , LAST_ORD_DT_FRZR DATE OPTIONS(DESCRIPTION="Last Known Order Date for Freezer (Freezer Only)")
        --, Todo: dishwasher
        , LAST_ORD_DT_WASH DATE OPTIONS(DESCRIPTION="Last Known Order Date for Washing Machine")
        , LAST_ORD_DT_DRY DATE OPTIONS(DESCRIPTION="Last Known Order Date for Dryer")
        --, Todo: cooktop
        --, Todo: microwave
        --, Todo: GRBGE DSPSL garbage disposal
        --, Todo: FRZR	freezer
      > OPTIONS(DESCRIPTION="Appliance Features (in most cases, only if purchaser still lives at property)") 
    , WIN STRUCT<
        STORM_WIN_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having storm windows.")
        , STORM_SHUTT_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having storm shutters.")
        , LAST_WIN_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having updated/upgraded windows")
        , WIN_TRTMT_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having window treatment")
        , WIN_BAY_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having bay windows")
        , WIN_INSULATED_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having insulated windows")
        --, Todo: TRTMT     Window Treatments
      > OPTIONS(DESCRIPTION="Window Features")
    , DOOR STRUCT<
        STORM_DOOR_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having storm doors.")
        , LAST_INSTL_DT_DOOR_EXTR DATE OPTIONS(DESCRIPTION="Exterior Door: Last THD completed installation.")
        , LAST_INSTL_DT_DOOR_PATIO DATE OPTIONS(DESCRIPTION="Patio Door: Last THD completed installations.")
        , LAST_INSTL_DT_DOOR_INTR DATE OPTIONS(DESCRIPTION="Interior Door: Last THD completed installation.")
      > OPTIONS(DESCRIPTION="Door Features")/*
    , STRG STRUCT<
      > OPTIONS(DESCRIPTION="Storage Features")  
    , PAINT STRUCT<
        --, Todo: 
      > OPTIONS(DESCRIPTION="Paint Features")
    , TOOL STRUCT<
        -- Todo: Lawn Mower
      > OPTIONS(DESCRIPTION="Tool Features (in most cases, only if purchaser still lives at property)")
    , DCR STRUCT<
        -- Todo: 
      > OPTIONS(DESCRIPTION="Decor Features (in most cases, only if purchaser still lives at property)")
    , WTHR STRUCT<
        -- Todo: Flood Risk
        -- Todo: Fire Risk
        -- Todo: Hurricane Risk
        -- Todo: Tornado Risk
        -- Todo: Earthquake Risk
        -- Todo: Hurricane Events
        -- Todo: Flood Events
        -- Todo: Tornado Events
        -- Todo: Earthquake events
      > OPTIONS(DESCRIPTION="Weather Features - Risks and Major Events")
    , AREA STRUCT<
        --THDSTR
        -- Todo: TSI
        -- Todo: Census
        -- Todo: HUD Income 
      > OPTIONS(DESCRIPTION="Area Features - Census, HUD, THD / Competitors")
    , ID STRUCT<
        -- Todo: HH
        -- Todo: Census
      > OPTIONS(DESCRIPTION="GeoIDs / HH")
    , RES STRUCT<
      > OPTIONS(DESCRIPTION="Resident Behavior & Demographics Features")*/
    
    
    
    )
  OPTIONS(
    DESCRIPTION="""
      Current attributes and features of a property address.
      Atomic Level: CLIP #

      HH version of HouseFacts: `analytics-mkt-analytics-thd.hf_pr.HouseFacts_HH`
      Mapping Clip to HH: `analytics-mkt-analytics-thd.hf_pr.hh_clip`
      Mapping Clip to Current Address Spelling: `analytics-mkt-analytics-thd.hf_pr.clip_curr`
      """
  ) AS
SELECT
  A.CLIP
  , STRUCT(
      UPPER(H.DESCR2) AS LAND_USE_TYP
      , UPPER(H.DESCR) AS LAND_USE_DESC
      , UPPER(CASE
          WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) = '163'
            THEN 'Single Family Residence'
          WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) IN
            ('115', '165' ,'151', '102')
            THEN 'Townhouse/Other Attached Residence'
          WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) IN ('137', '138')
            THEN 'Manfactured Home'
          WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) = '106'
            THEN 'Apartment'
          WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) IN
            ('112', '117', '116', '113')
            THEN 'Condominium'
          WHEN H.DESCR2 = "Residential" THEN "Residential Other"
          WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) IS NOT NULL
            THEN "Other"
        END) AS DWLG_TYP
      , COALESCE(C.YR_BUILT, E.YR_BUILT) AS YR_BUILT
      , CASE WHEN E.RMDL_YR > COALESCE(C.YR_BUILT, E.YR_BUILT)
        THEN E.RMDL_YR END AS REMOD_YR
      , C.LVG_SQFT AS LVNG_SQFT
      , UPPER(H2.DESCR) AS BLDG_TYP
      , UPPER(H8.DESCR) AS BLDG_COND
      , UPPER(H4.DESCR) AS BLDG_QUAL
      , UPPER(H5.DESCR) AS EXTR_WALL_TYP
      , C.STRY_NBRS
      , CASE WHEN STORM_ROOM_IND 
        OR F.STORM[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE END AS STORM_ROOM_IND
      , C.BEDRM_CNT
    ) BLDG
  , STRUCT(
      B.SALE_DT
      , B.SALE_AMT
      , COALESCE(B.OWNR_OCC_IND, D.OWNR_OCC_IND) AS OWNR_OCPD_IND
      , B.INV_PRCH_IND AS INVSTR_PRCH_IND
    ) SALE
  , STRUCT(
      D.CURR_HOME_VAL
      , D.HOME_EQUITY AS HOME_EQTY
      , D.CURR_LTV
      , D.NUM_LIENS AS NBR_LIENS
      , D.TOT_MRTG_AMT
      , D.TOT_MRTG_CURR_BAL
    ) MRTG
  , STRUCT(
      E.ON_MKT_IND
      , E.CURR_ON_MKT_DAYS
      , E.CURR_OFF_MKT_DAYS
      , E.LIST_RENT_IND
    ) LIST
  , STRUCT(
      C.ACRES
      , C.POOL_IND
      , PATIO_IND
      , DECK_IND
      , BALCONY_IND
      , PORCH_IND
      , BBQ_AREA_IND
      , FIREPIT_IND
      , CASE WHEN SHED_IND IS TRUE 
        OR F.SHED[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE END AS SHED_IND
      , CASE WHEN F.PRGL[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL 
        THEN TRUE END AS PERGOLA_IND
      , CASE WHEN F.GZBO[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL 
        THEN TRUE END AS GAZEBO_IND
      , IRRIGATION_IND AS IRRIG_IND
      , NULLIF(UPPER(SPLIT(E.FENCE, ': ')[SAFE_OFFSET(1)]), 'UNKNOWN') AS FENCE_TYP
      --, Todo: Roof Type
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ F.ROOF[SAFE_OFFSET(0)].LAST_INSTL_DT --thd install
                , CAST(CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  ) AS DATE)
                -- Todo: Add Listing
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_INSTL_DT_ROOF
      --, Todo: Lawn
      --, Todo: Garden
      
    ) OUTDR
  , STRUCT(
      ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ LAST_KIT_UPD_DT
                , CAST(CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  ) AS DATE)
                -- Todo: Add THD Installs
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_KIT_UPD_DT
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ CNTR_UPD_DT
                , CAST(CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  ) AS DATE)
                -- Todo: Add THD Installs
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_CTOP_UPD_DT 
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ CBNT_UPD_DT
                , CAST(CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  ) AS DATE)
                -- Todo: Add THD Installs
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_CAB_UPD_DT
    ) KIT
  , STRUCT(
      -- Hardwood
      CASE WHEN FLR_WOOD_IND 
        OR F.WOOD[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE 
      END AS FLR_WOOD_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ FLR_WOOD_UPD_DT
                , F.WOOD[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CASE WHEN FLR_WOOD_IND
                    THEN 
                      CAST(CONCAT(
                        CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                        , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                            = EXTRACT(YEAR FROM CURRENT_DATE) 
                          THEN '-01-01' ELSE '-12-31' END
                      ) AS DATE)
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
                  END
              ]) X
        ) AS LAST_FLR_WOOD_UPD_DT
      -- Carpet
      , CASE WHEN FLR_CRPT_IND IS TRUE 
          OR F.CRPT[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE 
        END AS FLR_CRPT_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ FLR_CRPT_UPD_DT
                , F.CRPT[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CASE WHEN FLR_CRPT_IND
                    THEN 
                      CAST(CONCAT(
                        CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                        , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                            = EXTRACT(YEAR FROM CURRENT_DATE) 
                          THEN '-01-01' ELSE '-12-31' END
                      ) AS DATE)
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
                  END
              ]) X
        ) AS LAST_FLR_CRPT_UPD_DT
      -- Vinyl / Vinyl Plank
      , CASE WHEN FLR_VINYL_IND IS TRUE 
          OR F.VINYL[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE 
        END AS FLR_VINYL_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ FLR_VINYL_UPD_DT
                , F.VINYL[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CASE WHEN FLR_VINYL_IND
                    THEN 
                      CAST(CONCAT(
                        CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                        , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                            = EXTRACT(YEAR FROM CURRENT_DATE) 
                          THEN '-01-01' ELSE '-12-31' END
                      ) AS DATE)
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
                  END
              ]) X
        ) AS LAST_FLR_VINYL_UPD_DT
      -- Tile
      , CASE WHEN FLR_TILE_IND IS TRUE 
          OR F.TILE[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE 
        END AS FLR_TILE_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ FLR_TILE_UPD_DT
                , F.TILE[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CASE WHEN FLR_TILE_IND
                    THEN 
                      CAST(CONCAT(
                        CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                        , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                            = EXTRACT(YEAR FROM CURRENT_DATE) 
                          THEN '-01-01' ELSE '-12-31' END
                      ) AS DATE)
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
                  END
              ]) X
        ) AS LAST_FLR_TILE_UPD_DT
      -- Laminate
      , CASE WHEN FLR_LAMINATE_IND IS TRUE 
          OR F.LAM[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE 
        END AS FLR_LAM_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ FLR_LAMINATE_UPD_DT
                , F.LAM[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CASE WHEN FLR_LAMINATE_IND
                    THEN 
                      CAST(CONCAT(
                        CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                        , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                            = EXTRACT(YEAR FROM CURRENT_DATE) 
                          THEN '-01-01' ELSE '-12-31' END
                      ) AS DATE)
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
                  END
              ]) X
        ) AS LAST_FLR_LAM_UPD_DT
    ) FLR
  , STRUCT(
      C.FULL_BATH_CNT
      , C.HALF_BATH_CNT
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ LAST_BATH_UPD_DT
                , CAST(CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  ) AS DATE)
                -- Todo: Add THD Installs
                -- Todo: Add Realtor Comments
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_BATH_UPD_DT
    ) BATH
  , STRUCT(
      CASE
        WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)CARPORT|COVERED')
          THEN 'CARPORT'
        WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)attached|BASEMENT|BUILT IN')
          THEN 'ATTACHED'
        WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)DETACHED|SALT BOX|PREFAB')
          THEN 'DETACHED'
        WHEN E.GRG_ATTACHED_IND THEN 'ATTACHED'
        WHEN E.GRG_DETACHED_IND THEN 'DETACHED'
        WHEN E.GRG_CARPORT_IND THEN 'CARPORT'
        WHEN H3.DESCR IS NOT NULL OR E.GRG_IND THEN 'OTHER'
      END AS GRG_TYP
      , CASE
          WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)(^| )finished') THEN FALSE
          WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)unfinished') THEN TRUE
          WHEN E.GRG_UNFINISHED_IND IS TRUE THEN TRUE
        END AS GRG_FINSH_IND
      , COALESCE(C.GRG_PRKG_SQFT, E.GRG_AREA) AS GRG_SQFT
      , CASE
          WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)(^| |-)1 CAR') THEN "1"
          WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)(^| |-)2 CAR') THEN "2"
          WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)(^| |-)3 CAR') THEN "3+"
          WHEN E.GRG_1CAR_IND THEN "1"
          WHEN E.GRG_2CAR_IND THEN "2"
          WHEN E.GRG_3CARPLUS_IND THEN "3+"
          WHEN E.GRG_SPACES = 1 THEN "1"
          WHEN E.GRG_SPACES < 3 THEN "2"
          WHEN E.GRG_SPACES > 2 THEN "3+"
        END AS GRG_SPCS
      , GRG_DOOR_OPENER_IND
      , GRG_CABINETS_IND AS GRG_CAB_IND
      , GRG_STORAGE_IND AS GRG_STRG_IND
    ) AS GRG
  , STRUCT(
      COALESCE(H7.DESCR, H6.DESCR) AS BSMT_TYP
      , BSMT_SQFT
      , CASE
          WHEN REGEXP_CONTAINS(H6.DESCR, '(?i)(^| )finished')
            OR REGEXP_CONTAINS(H7.DESCR, '(?i)(^| )finished')
            THEN 'FINISHED'
          WHEN REGEXP_CONTAINS(H6.DESCR, '(?i)PARTIALLY')
            THEN 'PARTIALLY FINISHED'
          WHEN REGEXP_CONTAINS(H6.DESCR, '(?i)(^| )unfinished')
            OR REGEXP_CONTAINS(H7.DESCR, '(?i)(^| )unfinished')
            OR UNFNSHD_BSMT_IND
            THEN 'UNFINISHED'
        END AS BSMT_FNSH_CLASS
    ) AS BSMT
  , STRUCT(
      ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ F.WHTR[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CAST(CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  ) AS DATE)
                -- Todo: Add Realtor Comments
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
      ) AS LAST_INSTL_DT_WHTR
      --, todo: water pump
      --, todo: Septic tank
      , F.WFLTR[SAFE_OFFSET(0)].LAST_INSTL_DT AS LAST_INSTL_DT_WFLTR
     ,  F.WSFTR[SAFE_OFFSET(0)].LAST_INSTL_DT AS LAST_INSTL_DT_WSFTR
    ) PLMB
  , STRUCT(
      CASE WHEN C.FRPLC_IND OR E.FIREPLACE_IND THEN TRUE END AS FRPLC_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ F.HVAC[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CAST(CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  ) AS DATE)
                -- Todo: Add Realtor Comments
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_INSTL_DT_HVAC
      -- Todo: Portable AC
      -- Todo: Portable Heater
      -- Todo: Attic Fans
      -- Todo: Whole House Fans
      -- Todo: Insulation?
      -- Todo: Heat Pump?
    ) HVAC
  , STRUCT(
      SOLAR_IND/*
      , STRUCT(
          --, Todo: 
        ) AS SMRTHM*/
      -- Todo: ELEC PANL    Electric Panel
      , F.BTTRY[SAFE_OFFSET(0)].LAST_INSTL_DT AS LAST_INSTL_DT_BTTRY
      , F.GNRTR[SAFE_OFFSET(0)].LAST_INSTL_DT AS LAST_INSTL_DT_GNRTR
      -- Todo: RADON MTGN   Radon Mitigation 
      -- Todo: LGHT         Lighting
    ) ELEC
  , STRUCT(
      G.FRDG[SAFE_OFFSET(0)].DD_ORD_DT AS LAST_ORD_DT_FRDG
      , G.FRZR[SAFE_OFFSET(0)].DD_ORD_DT AS LAST_ORD_DT_FRZR
      --, Todo: dishwasher
      , G.WASH[SAFE_OFFSET(0)].DD_ORD_DT AS LAST_ORD_DT_WASH
      , G.DRY[SAFE_OFFSET(0)].DD_ORD_DT AS LAST_ORD_DT_DRY
      --, Todo: cooktop
      --, Todo: microwave
      --, Todo: GRBGE DSPSL garbage disposal
      --, Todo: FRZR	freezer
    ) APLNC
  , STRUCT(
      STORM_WNDW_IND AS STORM_WIN_IND
      , STORM_SHUTT_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ WNDW_UPD_DT
                , CAST(CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  ) AS DATE)
                -- Todo: Add THD Installs
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_WIN_UPD_DT
      , WNDW_TRTMNT_IND AS WIN_TRTMT_IND
      , WNDW_BAY_IND AS WIN_BAY_IND
      , WNDW_INSULATED_IND AS WIN_INSULATED_IND
    ) WIN
  , STRUCT(
      CASE WHEN STORM_DOOR_IND IS TRUE
        OR F.DOOR_STRM[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE END AS STORM_DOOR_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ F.DOOR_EXTR[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CAST(CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  ) AS DATE)
                -- Todo: Add Realtor Comments?
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_INSTL_DT_DOOR_EXTR
      , F.DOOR_PATIO[SAFE_OFFSET(0)].LAST_INSTL_DT AS LAST_INSTL_DT_DOOR_PATIO
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ F.DOOR_INTR[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CAST(CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  ) AS DATE)
                -- Todo: Add Realtor Comments?
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_INSTL_DT_DOOR_INTR
    ) DOOR/*
  , STRUCT(
      --, Todo: 
    ) STRG
  , STRUCT(
      --, Todo:
    ) PAINT
  , STRUCT(
      -- Todo: Lawn Mowers
      --, Todo:
    ) TOOL
  , STRUCT(
      --, Todo:
    ) DCR
  , STRUCT(
      -- Todo: Flood Risk
      -- Todo: Fire Risk
      -- Todo: Hurricane Risk
      -- Todo: Tornado Risk
      -- Todo: Earthquake Risk
      -- Todo: Hurricane Events
      -- Todo: Flood Events
      -- Todo: Tornado Events
      -- Todo: Earthquake events
    ) WTHR
  , STRUCT(
      -- Closest THD store (euclidean)
      -- Todo: TSI
      -- Todo: Census
      -- Todo: HUD Income 
    ) AREA
  , STRUCT(
      -- Todo: HH
      -- Todo: Census
    ) ID
  , STRUCT(
      -- Todo: 
    ) RES*/


FROM `analytics-mkt-analytics-thd.hf_pr.clip_curr` A
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_deed` B
  ON A.CLIP = B.CLIP
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_tax` C
  ON A.CLIP = C.CLIP
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_lien` D
  ON A.CLIP = D.CLIP
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_list` E
  ON A.CLIP = E.CLIP
LEFT JOIN `analytics-mkt-analytics-thd.hf_pr.thd_instl_pctgry` F
  ON A.CLIP = F.CLIP
LEFT JOIN `analytics-mkt-analytics-thd.hf_pr.thd_prod_dd_pctgry` G
  ON A.CLIP = G.CLIP
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H
  ON COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) = H.CODE
    AND H.TBL = 'OLB' AND H.COL = 'LAND_USE_CD'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H2
  ON C.BLDG_CD = H2.CODE
    AND H2.TBL = 'OLB' AND H2.COL = 'BLDG'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H3
  ON C.GRG_CD = H3.CODE
    AND H3.TBL = 'OLB' AND H3.COL = 'GARAGE_CD'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H4
  ON C.BLDG_QUAL_CD = H4.CODE
    AND H4.TBL = 'OLB' AND H4.COL = 'BLDG_QUAL_CD'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H5
  ON C.EXTR_WALL_CD = H5.CODE
    AND H5.TBL = 'OLB' AND H5.COL = 'EXTR_WALL_CD'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H6
  ON C.BSMT_FINSH_CD = H6.CODE
    AND H6.TBL = 'OLB' AND H6.COL = 'BSMT_FNSH_CD'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H7
  ON C.BSMT_TYP_CD = H7.CODE
    AND H7.TBL = 'OLB' AND H7.COL = 'BSMT_TYPE_CD'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H8
  ON C.COND_CD = H8.CODE
    AND H8.TBL = 'OLB' AND H8.COL = 'COND_CD'
;

-- Create HH View
-- Note: Views don't allow column descriptions in DDL
CREATE OR REPLACE VIEW
  `analytics-mkt-analytics-thd.hf_pr.HouseFacts_HH`
AS
SELECT
  A.THD_HH_ID
  , B.* EXCEPT(CLIP)
FROM `analytics-mkt-analytics-thd.hf_pr.hh_clip` A
INNER JOIN `analytics-mkt-analytics-thd.hf_pr.HouseFacts` B
  ON A.CLIP = B.CLIP
;



/* *********************************************************************
    View of Column Descriptions
    ********************************************************************

CREATE OR REPLACE VIEW 
  `analytics-mkt-analytics-thd.hf_pr.col_desc` 
AS
SELECT 
  ( SELECT 
      ARRAY_AGG(X
        ORDER BY OFFSET DESC
        LIMIT 1
      )[SAFE_OFFSET(0)] X
    FROM UNNEST(SPLIT(field_path, '.')) X WITH OFFSET
  ) AS COL_NM
  , description AS COL_DESC
FROM analytics-mkt-analytics-thd.`region-us`.INFORMATION_SCHEMA.COLUMN_FIELD_PATHS
WHERE table_schema = "hf_pr"
  AND table_name = "HouseFacts"
GROUP BY 1, 2;

********************************************************************* */













------------------------------------------------------------


/* =====================================================================
  Create Date:    2022-12-02    Faith Andren
  As of Date:     2022-12-28    Faith Andren

  Purpose:        Create the final table and HH view for HouseFacts.

  Steps:          1)  Join HouseFact components to atomic level.
                  2)  Create HH view of HouseFacts.

  Notes:

  Enhancements?   Check inline TODO comments

===================================================================== */

CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_pr.HouseFacts`
  ( CLIP STRING NOT NULL OPTIONS(DESCRIPTION="Property ID (sourced from CoreLogic)")
    , BLDG STRUCT<
        LAND_USE_TYP STRING OPTIONS(DESCRIPTION="Property Land Use Type (residential/commercial/etc.)")
        , LAND_USE_DESC STRING OPTIONS(DESCRIPTION="Property Land Use (Single Family Residence, etc.)")
        , DWLG_TYP STRING OPTIONS(DESCRIPTION="Residential Dwelling Type")
        , YR_BUILT INT64 OPTIONS(DESCRIPTION="Home Build Year")
        , REMOD_YR INT64 OPTIONS(DESCRIPTION="The last year the home was listed as having been remodeled")
        , LVNG_SQFT INT64 OPTIONS(DESCRIPTION="Living Square Feet of the home")
        , BLDG_TYP STRING OPTIONS(DESCRIPTION="The primary building type (e.g., Bowling Alley, Supermarket).")
        , BLDG_COND STRING OPTIONS(DESCRIPTION="This represents the physical condition of the main improvement (e.g., Good, Fair, Under Construction).")
        , BLDG_QUAL STRING OPTIONS(DESCRIPTION="Type of construction quality of building (e.g., excellent, economical).")
        , EXTR_WALL_TYP STRING OPTIONS(DESCRIPTION="The type and/or finish of the exterior walls")
        , STRY_NBRS FLOAT64 OPTIONS(DESCRIPTION="Number of stories associated with the building")
        , STORM_ROOM_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installation or historical realtor comments or listed exterior features indicated home having storm/safe rooms.")
        , BEDRM_CNT INT64 OPTIONS(DESCRIPTION="Number of bedrooms in home")
      > OPTIONS(DESCRIPTION="Building Features")
    , SALE STRUCT<
        SALE_DT DATE OPTIONS(DESCRIPTION="Last sale date of property (excluding nominal sales)")
        , SALE_AMT FLOAT64 OPTIONS(DESCRIPTION="Last sale amount of property")
        , OWNR_OCPD_IND BOOLEAN OPTIONS(DESCRIPTION="CoreLogic's Owner Occupied Classification")
        , INVSTR_PRCH_IND BOOLEAN OPTIONS(DESCRIPTION="Latest property sale was an investment purchase")
      > OPTIONS(DESCRIPTION="Latest Property Sale Features")
    , MRTG STRUCT<
        CURR_HOME_VAL FLOAT64 OPTIONS(DESCRIPTION="Current home value - source Corelogic's valuation model.")
        , HOME_EQTY FLOAT64 OPTIONS(DESCRIPTION="Current Estimated Home Equity ( assuming that the homeowner paid the minimum required amount)")
        , CURR_LTV FLOAT64 OPTIONS(DESCRIPTION="Current Loan to Value. Remaining mortgage balance / current home value.")
        , NBR_LIENS INT64 OPTIONS(DESCRIPTION="Number of liens currently on the property")
        , TOT_MRTG_AMT FLOAT64 OPTIONS(DESCRIPTION="Total amount of all mortgages on the property.")
        , TOT_MRTG_CURR_BAL FLOAT64 OPTIONS(DESCRIPTION="Total estimated current amount remaining on all mortgages on the property, assuming that the homeowner paid the minimum required amount")
      > OPTIONS(DESCRIPTION="Current Mortgage Features")
    , LIST STRUCT<
        ON_MKT_IND BOOLEAN OPTIONS(DESCRIPTION="Indicates whether the home is currently on the market")
        , CURR_ON_MKT_DAYS INT64 OPTIONS(DESCRIPTION="Number of days currently on market (if on market)")
        , CURR_OFF_MKT_DAYS INT64 OPTIONS(DESCRIPTION="Number of days off market (if off market)")
        , LIST_RENT_IND BOOLEAN OPTIONS(DESCRIPTION="Property's last listing had it listed for rent")
      > OPTIONS(DESCRIPTION="Latest Property Listing Features")
    , OUTDR STRUCT<
        ACRES FLOAT64 OPTIONS(DESCRIPTION="Property Acreages")
        , POOL_IND BOOLEAN OPTIONS(DESCRIPTION="Assessed as having a pool; null = unknown")
        , PATIO_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a patio.")
        , DECK_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a deck.")
        , BALCONY_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a balcony.")
        , PORCH_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a porch.")
        , BBQ_AREA_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a bbq area.")
        , FIREPIT_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a firepit.")
        , SHED_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installation or historical realtor comments or listed exterior features indicated home having a shed.")
        , PERGOLA_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installation or historical realtor comments or listed exterior features indicated home having a pergola.")
        , GAZEBO_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installation or historical realtor comments or listed exterior features indicated home having a gazebo.")
        , IRRIG_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having an irrigation system.")
        , FENCE_TYP STRING OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated the condition of fence: not fenced/ partially fenced/fenced")
        --, Todo: FENCE_TYP
        --, Todo: Last Roof Update
        --, Todo: Lawn
        --, Todo: Garden
      > OPTIONS(DESCRIPTION="Outdoor Features of the Property")
    , KIT STRUCT<
        LAST_KIT_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having a kitchen renovation")
        , LAST_CTOP_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having countertops updated")
        , LAST_CAB_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having new cabinets")
      > OPTIONS(DESCRIPTION="Kitchen Features")
    , FLR STRUCT<
        FLR_WOOD_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed interior features indicated home having hard wood flooring.")
        , LAST_FLR_WOOD_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a wooden flooring update")
        , FLR_CRPT_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed interior features indicated home having carpets.")
        , LAST_FLR_CRPT_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a carpets update")
        , FLR_VINYL_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed interior features indicated home having vinyl flooring.")
        , LAST_FLR_VINYL_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a vinyl flooring update")
        , FLR_TILE_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed interior features indicated home having tile flooring.")
        , LAST_FLR_TILE_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a tile flooring update")
        , FLR_LAM_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed interior features indicated home having laminate flooring.")
        , LAST_FLR_LAM_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a tile laminate update")
      > OPTIONS(DESCRIPTION="Flooring Features")
    , BATH STRUCT<
        FULL_BATH_CNT INT64 OPTIONS(DESCRIPTION="Number of full baths in home")
        , HALF_BATH_CNT INT64 OPTIONS(DESCRIPTION="Number of half baths in home")
        , LAST_BATH_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having a bathroom renovation")
      > OPTIONS(DESCRIPTION="Bath Features")
    , GRG STRUCT<
        GRG_TYP STRING OPTIONS(DESCRIPTION="Type of Garage or Carport")
        , GRG_FINSH_IND BOOLEAN OPTIONS(DESCRIPTION="Garage finished indicator")
        , GRG_SQFT FLOAT64 OPTIONS(DESCRIPTION="This is the total square footage of the primary garage or parking area.")
        , GRG_SPCS STRING OPTIONS(DESCRIPTION="Number of Spaces Garage Has")
        , GRG_DOOR_OPENER_IND BOOLEAN OPTIONS(DESCRIPTION="Garage listed as having a garage door opener on MLS Listing")
        , GRG_CABINETS_IND BOOLEAN OPTIONS(DESCRIPTION="Garage listed as having cabinets on MLS Listing")
        , GRG_STRG_IND BOOLEAN OPTIONS(DESCRIPTION="Garage listed as having storage on MLS Listing")
      > OPTIONS(DESCRIPTION="Garage Features")
    , BSMT STRUCT<
        BSMT_TYP STRING OPTIONS(DESCRIPTION="Basement Type")
        , BSMT_SQFT FLOAT64 OPTIONS(DESCRIPTION="Basement Sqft")
        , BSMT_FNSH_CLASS STRING OPTIONS(DESCRIPTION="Basement Finish Classification")
      > OPTIONS(DESCRIPTION="Basement Features")
    , PLMB STRUCT<
        LAST_INSTL_DT_WHTR DATE OPTIONS(DESCRIPTION="Water Heater: Last completed water heater builing permit or THD completed installations in 026-051-010/020/030/040/060/070/080.")
        --, todo: water pump
        --, todo: Septic tank
        --, todo: WFLTR   Water Filter
      > OPTIONS(DESCRIPTION="Plumbing Features")
    , HVAC STRUCT<
        FRPLC_IND BOOLEAN OPTIONS(DESCRIPTION="Tax assessment or historical realtor comments or listed exterior features indicated home having a fire place.")
        , LAST_INSTL_DT_HVAC DATE OPTIONS(DESCRIPTION="HVAC: Last completed HVAC building permit or THD completed installations in 026-052-010.")
        -- Todo: Portable AC
        -- Todo: Portable Heater
        -- Todo: Attic Fans
        -- Todo: Whole House Fans
        -- Todo: Insulation?
        -- Todo: Heat Pump?
      > OPTIONS(DESCRIPTION="Heating, Ventalation, and Air Conditioning Features")
    , ELEC STRUCT<
        SOLAR_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having solar power.")   
        --SOLR    Solar
        /*
        , SMRTHM STRUCT<
          > OPTIONS(DESCRIPTION="Smart Home Items/Features")*/
        -- Todo: ELEC PANL    Electric Panel
        , LAST_INSTL_DT_BTTRY DATE OPTIONS(DESCRIPTION="Home Battery: Last THD completed installation in 027-054-003.") 
        , LAST_INSTL_DT_GNRTR DATE OPTIONS(DESCRIPTION="Generator: Last THD completed installation in 027-057-010.")   
        -- Todo: RADON MTGN   Radon Mitigation 
        -- Todo: LGHT         Lighting
      > OPTIONS(DESCRIPTION="Electric/Lighting Features")
    , APLNC STRUCT<
        LAST_ORD_DT_FRDG DATE OPTIONS(DESCRIPTION="Last Known Order Date for Fridgerator")
        , LAST_ORD_DT_FRZR DATE OPTIONS(DESCRIPTION="Last Known Order Date for Freezer (Freezer Only)")
        --, Todo: dishwasher
        , LAST_ORD_DT_WASH DATE OPTIONS(DESCRIPTION="Last Known Order Date for Washing Machine")
        , LAST_ORD_DT_DRY DATE OPTIONS(DESCRIPTION="Last Known Order Date for Dryer")
        --, Todo: cooktop
        --, Todo: microwave
        --, Todo: GRBGE DSPSL garbage disposal
        --, Todo: FRZR	freezer
      > OPTIONS(DESCRIPTION="Appliance Features (in most cases, only if purchaser still lives at property)") 
    , WIN STRUCT<
        STORM_WIN_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having storm windows.")
        , STORM_SHUTT_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having storm shutters.")
        , LAST_WIN_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having updated/upgraded windows")
        , WIN_TRTMT_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having window treatment")
        , WIN_BAY_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having bay windows")
        , WIN_INSULATED_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having insulated windows")
        --, Todo: TRTMT     Window Treatments
      > OPTIONS(DESCRIPTION="Window Features")
    , DOOR STRUCT<
        STORM_DOOR_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having storm doors.")
        , LAST_INSTL_DT_DOOR_EXTR DATE OPTIONS(DESCRIPTION="Exterior Door: Last THD completed installation.")
        , LAST_INSTL_DT_DOOR_PATIO DATE OPTIONS(DESCRIPTION="Patio Door: Last THD completed installations.")
        , LAST_INSTL_DT_DOOR_INTR DATE OPTIONS(DESCRIPTION="Interior Door: Last THD completed installation.")
      > OPTIONS(DESCRIPTION="Door Features")/*
    , STRG STRUCT<
      > OPTIONS(DESCRIPTION="Storage Features")  
    , PAINT STRUCT<
        --, Todo: 
      > OPTIONS(DESCRIPTION="Paint Features")
    , TOOL STRUCT<
        -- Todo: Lawn Mower
      > OPTIONS(DESCRIPTION="Tool Features (in most cases, only if purchaser still lives at property)")
    , DCR STRUCT<
        -- Todo: 
      > OPTIONS(DESCRIPTION="Decor Features (in most cases, only if purchaser still lives at property)")
    , WTHR STRUCT<
        -- Todo: Flood Risk
        -- Todo: Fire Risk
        -- Todo: Hurricane Risk
        -- Todo: Tornado Risk
        -- Todo: Earthquake Risk
        -- Todo: Hurricane Events
        -- Todo: Flood Events
        -- Todo: Tornado Events
        -- Todo: Earthquake events
      > OPTIONS(DESCRIPTION="Weather Features - Risks and Major Events")
    , AREA STRUCT<
        --THDSTR
        -- Todo: TSI
        -- Todo: Census
        -- Todo: HUD Income 
      > OPTIONS(DESCRIPTION="Area Features - Census, HUD, THD / Competitors")
    , ID STRUCT<
        -- Todo: HH
        -- Todo: Census
      > OPTIONS(DESCRIPTION="GeoIDs / HH")
    , RES STRUCT<
      > OPTIONS(DESCRIPTION="Resident Behavior & Demographics Features")*/
    
    
    
    )
  OPTIONS(
    DESCRIPTION="""
      Current attributes and features of a property address.
      Atomic Level: CLIP #

      HH version of HouseFacts: `analytics-mkt-analytics-thd.hf_pr.HouseFacts_HH`
      Mapping Clip to HH: `analytics-mkt-analytics-thd.hf_pr.hh_clip`
      Mapping Clip to Current Address Spelling: `analytics-mkt-analytics-thd.hf_pr.clip_curr`
      """
  ) AS
SELECT
  A.CLIP
  , STRUCT(
      UPPER(H.DESCR2) AS LAND_USE_TYP
      , UPPER(H.DESCR) AS LAND_USE_DESC
      , UPPER(CASE
          WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) = '163'
            THEN 'Single Family Residence'
          WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) IN
            ('115', '165' ,'151', '102')
            THEN 'Townhouse/Other Attached Residence'
          WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) IN ('137', '138')
            THEN 'Manfactured Home'
          WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) = '106'
            THEN 'Apartment'
          WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) IN
            ('112', '117', '116', '113')
            THEN 'Condominium'
          WHEN H.DESCR2 = "Residential" THEN "Residential Other"
          WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) IS NOT NULL
            THEN "Other"
        END) AS DWLG_TYP
      , COALESCE(C.YR_BUILT, E.YR_BUILT) AS YR_BUILT
      , CASE WHEN E.RMDL_YR > COALESCE(C.YR_BUILT, E.YR_BUILT)
        THEN E.RMDL_YR END AS REMOD_YR
      , C.LVG_SQFT AS LVNG_SQFT
      , UPPER(H2.DESCR) AS BLDG_TYP
      , UPPER(H8.DESCR) AS BLDG_COND
      , UPPER(H4.DESCR) AS BLDG_QUAL
      , UPPER(H5.DESCR) AS EXTR_WALL_TYP
      , C.STRY_NBRS
      , CASE WHEN STORM_ROOM_IND 
        OR F.STORM[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE END AS STORM_ROOM_IND
      , C.BEDRM_CNT
    ) BLDG
  , STRUCT(
      B.SALE_DT
      , B.SALE_AMT
      , COALESCE(B.OWNR_OCC_IND, D.OWNR_OCC_IND) AS OWNR_OCPD_IND
      , B.INV_PRCH_IND AS INVSTR_PRCH_IND
    ) SALE
  , STRUCT(
      D.CURR_HOME_VAL
      , D.HOME_EQUITY AS HOME_EQTY
      , D.CURR_LTV
      , D.NUM_LIENS AS NBR_LIENS
      , D.TOT_MRTG_AMT
      , D.TOT_MRTG_CURR_BAL
    ) MRTG
  , STRUCT(
      E.ON_MKT_IND
      , E.CURR_ON_MKT_DAYS
      , E.CURR_OFF_MKT_DAYS
      , E.LIST_RENT_IND
    ) LIST
  , STRUCT(
      C.ACRES
      , C.POOL_IND
      , PATIO_IND
      , DECK_IND
      , BALCONY_IND
      , PORCH_IND
      , BBQ_AREA_IND
      , FIREPIT_IND
      , CASE WHEN SHED_IND IS TRUE 
        OR F.SHED[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE END AS SHED_IND
      , CASE WHEN F.PRGL[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL 
        THEN TRUE END AS PERGOLA_IND
      , CASE WHEN F.GZBO[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL 
        THEN TRUE END AS GAZEBO_IND
      , IRRIGATION_IND AS IRRIG_IND
      , NULLIF(UPPER(SPLIT(E.FENCE, ': ')[SAFE_OFFSET(1)]), 'UNKNOWN') AS FENCE_TYP
      --, Todo: Roof Type
      --, Todo: Last Roof Update
      --, Todo: Lawn
      --, Todo: Garden
    ) OUTDR
  , STRUCT(
      ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ LAST_KIT_UPD_DT
                , CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  )
                -- Todo: Add THD Installs
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_KIT_UPD_DT
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ CNTR_UPD_DT
                , CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  )
                -- Todo: Add THD Installs
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_CTOP_UPD_DT 
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ CBNT_UPD_DT
                , CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  )
                -- Todo: Add THD Installs
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_CAB_UPD_DT
    ) KIT
  , STRUCT(
      -- Hardwood
      CASE WHEN FLR_WOOD_IND 
        OR F.WOOD[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE 
      END AS FLR_WOOD_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ FLR_WOOD_UPD_DT
                , F.WOOD[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CASE WHEN FLR_WOOD_IND
                    THEN 
                      CONCAT(
                        CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                        , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                            = EXTRACT(YEAR FROM CURRENT_DATE) 
                          THEN '-01-01' ELSE '-12-31' END
                      )
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
                  END
              ]) X
        ) AS LAST_FLR_WOOD_UPD_DT
      -- Carpet
      , CASE WHEN FLR_CRPT_IND IS TRUE 
          OR F.CRPT[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE 
        END AS FLR_CRPT_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ FLR_CRPT_UPD_DT
                , F.CRPT[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CASE WHEN FLR_CRPT_IND
                    THEN 
                      CONCAT(
                        CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                        , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                            = EXTRACT(YEAR FROM CURRENT_DATE) 
                          THEN '-01-01' ELSE '-12-31' END
                      )
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
                  END
              ]) X
        ) AS LAST_FLR_CRPT_UPD_DT
      -- Vinyl / Vinyl Plank
      , CASE WHEN FLR_VINYL_IND IS TRUE 
          OR F.VINYL[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE 
        END AS FLR_VINYL_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ FLR_VINYL_UPD_DT
                , F.VINYL[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CASE WHEN FLR_VINYL_IND
                    THEN 
                      CONCAT(
                        CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                        , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                            = EXTRACT(YEAR FROM CURRENT_DATE) 
                          THEN '-01-01' ELSE '-12-31' END
                      )
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
                  END
              ]) X
        ) AS LAST_FLR_VINYL_UPD_DT
      -- Tile
      , CASE WHEN FLR_TILE_IND IS TRUE 
          OR F.TILE[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE 
        END AS FLR_TILE_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ FLR_TILE_UPD_DT
                , F.TILE[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CASE WHEN FLR_TILE_IND
                    THEN 
                      CONCAT(
                        CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                        , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                            = EXTRACT(YEAR FROM CURRENT_DATE) 
                          THEN '-01-01' ELSE '-12-31' END
                      )
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
                  END
              ]) X
        ) AS LAST_FLR_TILE_UPD_DT
      -- Laminate
      , CASE WHEN FLR_LAMINATE_IND IS TRUE 
          OR F.LAM[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE 
        END AS FLR_LAM_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ FLR_LAMINATE_UPD_DT
                , F.LAM[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CASE WHEN FLR_LAM_IND
                    THEN 
                      CONCAT(
                        CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                        , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                            = EXTRACT(YEAR FROM CURRENT_DATE) 
                          THEN '-01-01' ELSE '-12-31' END
                      )
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
                  END
              ]) X
        ) AS LAST_FLR_LAM_UPD_DT
    ) FLR
  , STRUCT(
      C.FULL_BATH_CNT
      , C.HALF_BATH_CNT
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ LAST_BATH_UPD_DT
                , CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  )
                -- Todo: Add THD Installs
                -- Todo: Add Realtor Comments
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_BATH_UPD_DT
    ) BATH
  , STRUCT(
      CASE
        WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)CARPORT|COVERED')
          THEN 'CARPORT'
        WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)attached|BASEMENT|BUILT IN')
          THEN 'ATTACHED'
        WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)DETACHED|SALT BOX|PREFAB')
          THEN 'DETACHED'
        WHEN E.GRG_ATTACHED_IND THEN 'ATTACHED'
        WHEN E.GRG_DETACHED_IND THEN 'DETACHED'
        WHEN E.GRG_CARPORT_IND THEN 'CARPORT'
        WHEN H3.DESCR IS NOT NULL OR E.GRG_IND THEN 'OTHER'
      END AS GRG_TYP
      , CASE
          WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)(^| )finished') THEN FALSE
          WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)unfinished') THEN TRUE
          WHEN E.GRG_UNFINISHED_IND IS TRUE THEN TRUE
        END AS GRG_FINSH_IND
      , COALESCE(C.GRG_PRKG_SQFT, E.GRG_AREA) AS GRG_SQFT
      , CASE
          WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)(^| |-)1 CAR') THEN "1"
          WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)(^| |-)2 CAR') THEN "2"
          WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)(^| |-)3 CAR') THEN "3+"
          WHEN E.GRG_1CAR_IND THEN "1"
          WHEN E.GRG_2CAR_IND THEN "2"
          WHEN E.GRG_3CARPLUS_IND THEN "3+"
          WHEN E.GRG_SPACES = 1 THEN "1"
          WHEN E.GRG_SPACES < 3 THEN "2"
          WHEN E.GRG_SPACES > 2 THEN "3+"
        END AS GRG_SPCS
      , GRG_DOOR_OPENER_IND
      , GRG_CABINETS_IND AS GRG_CAB_IND
      , GRG_STORAGE_IND AS GRG_STRG_IND
    ) AS GRG
  , STRUCT(
      COALESCE(H7.DESCR, H6.DESCR) AS BSMT_TYP
      , BSMT_SQFT
      , CASE
          WHEN REGEXP_CONTAINS(H6.DESCR, '(?i)(^| )finished')
            OR REGEXP_CONTAINS(H7.DESCR, '(?i)(^| )finished')
            THEN 'FINISHED'
          WHEN REGEXP_CONTAINS(H6.DESCR, '(?i)PARTIALLY')
            THEN 'PARTIALLY FINISHED'
          WHEN REGEXP_CONTAINS(H6.DESCR, '(?i)(^| )unfinished')
            OR REGEXP_CONTAINS(H7.DESCR, '(?i)(^| )unfinished')
            OR UNFNSHD_BSMT_IND
            THEN 'UNFINISHED'
        END AS BSMT_FNSH_CLASS
    ) AS BSMT
  , STRUCT(
      ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ F.WHTR[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  )
                -- Todo: Add Realtor Comments
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
      ) AS LAST_INSTL_DT_WHTR
      --, todo: water pump
      --, todo: Septic tank
      --, todo: WFLTR   Water Filter (Whole House)
    ) PLMB
  , STRUCT(
      CASE WHEN C.FRPLC_IND OR E.FIREPLACE_IND THEN TRUE END AS FRPLC_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ F.HVAC[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  )
                -- Todo: Add Realtor Comments
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_INSTL_DT_HVAC
      -- Todo: Portable AC
      -- Todo: Portable Heater
      -- Todo: Attic Fans
      -- Todo: Whole House Fans
      -- Todo: Insulation?
      -- Todo: Heat Pump?
    ) HVAC
  , STRUCT(
      SOLAR_IND/*
      , STRUCT(
          --, Todo: 
        ) AS SMRTHM*/
      -- Todo: ELEC PANL    Electric Panel
      , F.BTTRY[SAFE_OFFSET(0)].LAST_INSTL_DT AS LAST_INSTL_DT_BTTRY
      , F.GNRTR[SAFE_OFFSET(0)].LAST_INSTL_DT AS LAST_INSTL_DT_GNRTR
      -- Todo: RADON MTGN   Radon Mitigation 
      -- Todo: LGHT         Lighting
    ) ELEC
  , STRUCT(
      G.FRDG[SAFE_OFFSET(0)].DD_ORD_DT AS LAST_ORD_DT_FRDG
      , G.FRZR[SAFE_OFFSET(0)].DD_ORD_DT AS LAST_ORD_DT_FRZR
      --, Todo: dishwasher
      , G.WASH[SAFE_OFFSET(0)].DD_ORD_DT AS LAST_ORD_DT_WASH
      , G.DRY[SAFE_OFFSET(0)].DD_ORD_DT AS LAST_ORD_DT_DRY
      --, Todo: cooktop
      --, Todo: microwave
      --, Todo: GRBGE DSPSL garbage disposal
      --, Todo: FRZR	freezer
    ) APLNC
  , STRUCT(
      STORM_WNDW_IND AS STORM_WIN_IND
      , STORM_SHUTT_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ WNDW_UPD_DT
                , CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  )
                -- Todo: Add THD Installs
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_WIN_UPD_DT
      , WNDW_TRTMNT_IND AS WIN_TRTMT_IND
      , WNDW_BAY_IND AS WIN_BAY_IND
      , WNDW_INSULATED_IND AS WIN_INSULATED_IND
    ) WIN
  , STRUCT(
      CASE WHEN STORM_DOOR_IND IS TRUE
        OR F.DOOR_STRM[SAFE_OFFSET(0)].LAST_INSTL_DT IS NOT NULL
        THEN TRUE END AS STORM_DOOR_IND
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ F.DOOR_EXTR[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  )
                -- Todo: Add Realtor Comments?
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_INSTL_DT_DOOR_EXTR
      , F.DOOR_PATIO[SAFE_OFFSET(0)].LAST_INSTL_DT AS LAST_INSTL_DT_DOOR_PATIO
      , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
          FROM UNNEST(
              [ F.DOOR_INTR[SAFE_OFFSET(0)].LAST_INSTL_DT
                , CONCAT(
                    CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                    , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                        = EXTRACT(YEAR FROM CURRENT_DATE) 
                      THEN '-01-01' ELSE '-12-31' END
                  )
                -- Todo: Add Realtor Comments?
                -- Todo: Add Building Permits
                -- Todo: Add Assumed DIY Install
              ]) X
        ) AS LAST_INSTL_DT_DOOR_INTR
    ) DOOR/*
  , STRUCT(
      --, Todo: 
    ) STRG
  , STRUCT(
      --, Todo:
    ) PAINT
  , STRUCT(
      -- Todo: Lawn Mowers
      --, Todo:
    ) TOOL
  , STRUCT(
      --, Todo:
    ) DCR
  , STRUCT(
      -- Todo: Flood Risk
      -- Todo: Fire Risk
      -- Todo: Hurricane Risk
      -- Todo: Tornado Risk
      -- Todo: Earthquake Risk
      -- Todo: Hurricane Events
      -- Todo: Flood Events
      -- Todo: Tornado Events
      -- Todo: Earthquake events
    ) WTHR
  , STRUCT(
      -- Closest THD store (euclidean)
      -- Todo: TSI
      -- Todo: Census
      -- Todo: HUD Income 
    ) AREA
  , STRUCT(
      -- Todo: HH
      -- Todo: Census
    ) ID
  , STRUCT(
      -- Todo: 
    ) RES*/


FROM `analytics-mkt-analytics-thd.hf_pr.clip_curr` A
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_deed` B
  ON A.CLIP = B.CLIP
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_tax` C
  ON A.CLIP = C.CLIP
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_lien` D
  ON A.CLIP = D.CLIP
LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_list` E
  ON A.CLIP = E.CLIP
LEFT JOIN `analytics-mkt-analytics-thd.hf_pr.thd_instl_pctgry` F
  ON A.CLIP = F.CLIP
LEFT JOIN `analytics-mkt-analytics-thd.hf_pr.thd_prod_dd_pctgry` G
  ON A.CLIP = G.CLIP
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H
  ON COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) = H.CODE
    AND H.TBL = 'OLB' AND H.COL = 'LAND_USE_CD'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H2
  ON C.BLDG_CD = H2.CODE
    AND H2.TBL = 'OLB' AND H2.COL = 'BLDG'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H3
  ON C.GRG_CD = H3.CODE
    AND H3.TBL = 'OLB' AND H3.COL = 'GARAGE_CD'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H4
  ON C.BLDG_QUAL_CD = H4.CODE
    AND H4.TBL = 'OLB' AND H4.COL = 'BLDG_QUAL_CD'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H5
  ON C.EXTR_WALL_CD = H5.CODE
    AND H5.TBL = 'OLB' AND H5.COL = 'EXTR_WALL_CD'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H6
  ON C.BSMT_FINSH_CD = H6.CODE
    AND H6.TBL = 'OLB' AND H6.COL = 'BSMT_FNSH_CD'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H7
  ON C.BSMT_TYP_CD = H7.CODE
    AND H7.TBL = 'OLB' AND H7.COL = 'BSMT_TYPE_CD'
LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H8
  ON C.COND_CD = H8.CODE
    AND H8.TBL = 'OLB' AND H8.COL = 'COND_CD'
;

-- Create HH View
-- Note: Views don't allow column descriptions in DDL
CREATE OR REPLACE VIEW
  `analytics-mkt-analytics-thd.hf_pr.HouseFacts_HH`
AS
SELECT
  A.THD_HH_ID
  , B.* EXCEPT(CLIP)
FROM `analytics-mkt-analytics-thd.hf_pr.hh_clip` A
INNER JOIN `analytics-mkt-analytics-thd.hf_pr.HouseFacts` B
  ON A.CLIP = B.CLIP
;



/* *********************************************************************
    View of Column Descriptions
    ********************************************************************

CREATE OR REPLACE VIEW 
  `analytics-mkt-analytics-thd.hf_pr.col_desc` 
AS
SELECT 
  ( SELECT 
      ARRAY_AGG(X
        ORDER BY OFFSET DESC
        LIMIT 1
      )[SAFE_OFFSET(0)] X
    FROM UNNEST(SPLIT(field_path, '.')) X WITH OFFSET
  ) AS COL_NM
  , description AS COL_DESC
FROM analytics-mkt-analytics-thd.`region-us`.INFORMATION_SCHEMA.COLUMN_FIELD_PATHS
WHERE table_schema = "hf_pr"
  AND table_name = "HouseFacts"
GROUP BY 1, 2;

********************************************************************* */


CREATE OR REPLACE TABLE
  `analytics-mkt-analytics-thd.hf_pr.HouseFacts2`
  ( CLIP STRING NOT NULL OPTIONS(DESCRIPTION="Property ID (sourced from CoreLogic)")
    , EFF_BGN_DT DATE 
    , EFF_END_DT DATE
    , BLDG STRUCT<
        LAND_USE_TYP STRING OPTIONS(DESCRIPTION="Property Land Use Type (residential/commercial/etc.)")
        , LAND_USE_DESC STRING OPTIONS(DESCRIPTION="Property Land Use (Single Family Residence, etc.)")
        , DWLG_TYP STRING OPTIONS(DESCRIPTION="Residential Dwelling Type")
        , YR_BUILT INT64 OPTIONS(DESCRIPTION="Home Build Year")
        , REMOD_YR INT64 OPTIONS(DESCRIPTION="The last year the home was listed as having been remodeled")
        , LVNG_SQFT INT64 OPTIONS(DESCRIPTION="Living Square Feet of the home")
        , BLDG_TYP STRING OPTIONS(DESCRIPTION="The primary building type (e.g., Bowling Alley, Supermarket).")
        , BLDG_COND STRING OPTIONS(DESCRIPTION="This represents the physical condition of the main improvement (e.g., Good, Fair, Under Construction).")
        , BLDG_QUAL STRING OPTIONS(DESCRIPTION="Type of construction quality of building (e.g., excellent, economical).")
        , EXTR_WALL_TYP STRING OPTIONS(DESCRIPTION="The type and/or finish of the exterior walls")
        , STRY_NBRS FLOAT64 OPTIONS(DESCRIPTION="Number of stories associated with the building")
        , STORM_ROOM_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installation or historical realtor comments or listed exterior features indicated home having storm/safe rooms.")
        , BEDRM_CNT INT64 OPTIONS(DESCRIPTION="Number of bedrooms in home")
      > OPTIONS(DESCRIPTION="Building Features")
    , SALE STRUCT<
        SALE_DT DATE OPTIONS(DESCRIPTION="Last sale date of property (excluding nominal sales)")
        , SALE_AMT FLOAT64 OPTIONS(DESCRIPTION="Last sale amount of property")
        , OWNR_OCPD_IND BOOLEAN OPTIONS(DESCRIPTION="CoreLogic's Owner Occupied Classification")
        , INVSTR_PRCH_IND BOOLEAN OPTIONS(DESCRIPTION="Latest property sale was an investment purchase")
      > OPTIONS(DESCRIPTION="Latest Property Sale Features")
    , MRTG STRUCT<
        HOME_VAL FLOAT64 OPTIONS(DESCRIPTION="Current home value - source Corelogic's valuation model.")
        , HOME_EQTY FLOAT64 OPTIONS(DESCRIPTION="Current Estimated Home Equity ( assuming that the homeowner paid the minimum required amount)")
        , MRTG_LTV FLOAT64 OPTIONS(DESCRIPTION="Current Loan to Value. Remaining mortgage balance / current home value.")
        , NBR_LIENS INT64 OPTIONS(DESCRIPTION="Number of liens currently on the property")
        , TOT_MRTG_AMT FLOAT64 OPTIONS(DESCRIPTION="Total amount of all mortgages on the property.")
        , TOT_MRTG_CURR_BAL FLOAT64 OPTIONS(DESCRIPTION="Total estimated current amount remaining on all mortgages on the property, assuming that the homeowner paid the minimum required amount")
      > OPTIONS(DESCRIPTION="Current Mortgage Features")
    , LIST STRUCT<
        ON_MKT_IND BOOLEAN OPTIONS(DESCRIPTION="Indicates whether the home is currently on the market")
        , ON_MKT_DAYS INT64 OPTIONS(DESCRIPTION="Number of days currently on market (if on market)")
        , OFF_MKT_DAYS INT64 OPTIONS(DESCRIPTION="Number of days off market (if off market)")
        , LIST_RENT_IND BOOLEAN OPTIONS(DESCRIPTION="Property's last listing had it listed for rent")
      > OPTIONS(DESCRIPTION="Latest Property Listing Features")
    , OUTDR STRUCT<
        ACRES FLOAT64 OPTIONS(DESCRIPTION="Property Acreages")
        , POOL_IND BOOLEAN OPTIONS(DESCRIPTION="Assessed as having a pool; null = unknown")
        , PATIO_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a patio.")
        , DECK_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a deck.")
        , BALCONY_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a balcony.")
        , PORCH_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a porch.")
        , BBQ_AREA_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a bbq area.")
        , FIREPIT_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having a firepit.")
        , SHED_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installation or historical realtor comments or listed exterior features indicated home having a shed.")
        , PERGOLA_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installation or historical realtor comments or listed exterior features indicated home having a pergola.")
        , GAZEBO_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installation or historical realtor comments or listed exterior features indicated home having a gazebo.")
        , IRRIG_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having an irrigation system.")
        , FENCE_TYP STRING OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated the condition of fence: not fenced/ partially fenced/fenced")
        --, Todo: FENCE_TYP
        --, Todo: Last Roof Update
        --, Todo: Lawn
        --, Todo: Garden
      > OPTIONS(DESCRIPTION="Outdoor Features of the Property")
    , KIT STRUCT<
        LAST_KIT_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having a kitchen renovation")
        , LAST_CTOP_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having countertops updated")
        , LAST_CAB_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having new cabinets")
      > OPTIONS(DESCRIPTION="Kitchen Features")
    , FLR STRUCT<
        FLR_WOOD_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed interior features indicated home having hard wood flooring.")
        , LAST_FLR_WOOD_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a wooden flooring update")
        , FLR_CRPT_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed interior features indicated home having carpets.")
        , LAST_FLR_CRPT_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a carpets update")
        , FLR_VINYL_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed interior features indicated home having vinyl flooring.")
        , LAST_FLR_VINYL_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a vinyl flooring update")
        , FLR_TILE_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed interior features indicated home having tile flooring.")
        , LAST_FLR_TILE_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a tile flooring update")
        , FLR_LAM_IND BOOLEAN OPTIONS(DESCRIPTION="THD Installs or Historical realtor comments or listed interior features indicated home having laminate flooring.")
        , LAST_FLR_LAM_UPD_DT DATE OPTIONS(DESCRIPTION="Last date THD install or listed as having a tile laminate update")
      > OPTIONS(DESCRIPTION="Flooring Features")
    , BATH STRUCT<
        FULL_BATH_CNT INT64 OPTIONS(DESCRIPTION="Number of full baths in home")
        , HALF_BATH_CNT INT64 OPTIONS(DESCRIPTION="Number of half baths in home")
        , LAST_BATH_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having a bathroom renovation")
      > OPTIONS(DESCRIPTION="Bath Features")
    , GRG STRUCT<
        GRG_TYP STRING OPTIONS(DESCRIPTION="Type of Garage or Carport")
        , GRG_FINSH_IND BOOLEAN OPTIONS(DESCRIPTION="Garage finished indicator")
        , GRG_SQFT FLOAT64 OPTIONS(DESCRIPTION="This is the total square footage of the primary garage or parking area.")
        , GRG_SPCS STRING OPTIONS(DESCRIPTION="Number of Spaces Garage Has")
        , GRG_DOOR_OPENER_IND BOOLEAN OPTIONS(DESCRIPTION="Garage listed as having a garage door opener on MLS Listing")
        , GRG_CABINETS_IND BOOLEAN OPTIONS(DESCRIPTION="Garage listed as having cabinets on MLS Listing")
        , GRG_STRG_IND BOOLEAN OPTIONS(DESCRIPTION="Garage listed as having storage on MLS Listing")
      > OPTIONS(DESCRIPTION="Garage Features")
    , BSMT STRUCT<
        BSMT_TYP STRING OPTIONS(DESCRIPTION="Basement Type")
        , BSMT_SQFT FLOAT64 OPTIONS(DESCRIPTION="Basement Sqft")
        , BSMT_FNSH_CLASS STRING OPTIONS(DESCRIPTION="Basement Finish Classification")
      > OPTIONS(DESCRIPTION="Basement Features")
    , PLMB STRUCT<
        LAST_INSTL_DT_WHTR DATE OPTIONS(DESCRIPTION="Water Heater: Last completed water heater builing permit or THD completed installations in 026-051-010/020/030/040/060/070/080.")
        --, todo: water pump
        --, todo: Septic tank
        --, todo: WFLTR   Water Filter
      > OPTIONS(DESCRIPTION="Plumbing Features")
    , HVAC STRUCT<
        FRPLC_IND BOOLEAN OPTIONS(DESCRIPTION="Tax assessment or historical realtor comments or listed exterior features indicated home having a fire place.")
        , LAST_INSTL_DT_HVAC DATE OPTIONS(DESCRIPTION="HVAC: Last completed HVAC building permit or THD completed installations in 026-052-010.")
        -- Todo: Portable AC
        -- Todo: Portable Heater
        -- Todo: Attic Fans
        -- Todo: Whole House Fans
        -- Todo: Insulation?
        -- Todo: Heat Pump?
      > OPTIONS(DESCRIPTION="Heating, Ventalation, and Air Conditioning Features")
    , ELEC STRUCT<
        SOLAR_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having solar power.")   
        --SOLR    Solar
        /*
        , SMRTHM STRUCT<
          > OPTIONS(DESCRIPTION="Smart Home Items/Features")*/
        -- Todo: ELEC PANL    Electric Panel
        , LAST_INSTL_DT_BTTRY DATE OPTIONS(DESCRIPTION="Home Battery: Last THD completed installation in 027-054-003.") 
        , LAST_INSTL_DT_GNRTR DATE OPTIONS(DESCRIPTION="Generator: Last THD completed installation in 027-057-010.")   
        -- Todo: RADON MTGN   Radon Mitigation 
        -- Todo: LGHT         Lighting
      > OPTIONS(DESCRIPTION="Electric/Lighting Features")
    , APLNC STRUCT<
        LAST_ORD_DT_FRDG DATE OPTIONS(DESCRIPTION="Last Known Order Date for Fridgerator")
        , LAST_ORD_DT_FRZR DATE OPTIONS(DESCRIPTION="Last Known Order Date for Freezer (Freezer Only)")
        --, Todo: dishwasher
        , LAST_ORD_DT_WASH DATE OPTIONS(DESCRIPTION="Last Known Order Date for Washing Machine")
        , LAST_ORD_DT_DRY DATE OPTIONS(DESCRIPTION="Last Known Order Date for Dryer")
        --, Todo: cooktop
        --, Todo: microwave
        --, Todo: GRBGE DSPSL garbage disposal
        --, Todo: FRZR	freezer
      > OPTIONS(DESCRIPTION="Appliance Features (in most cases, only if purchaser still lives at property)") 
    , WIN STRUCT<
        STORM_WIN_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having storm windows.")
        , STORM_SHUTT_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having storm shutters.")
        , LAST_WIN_UPD_DT DATE OPTIONS(DESCRIPTION="Last date listed as having updated/upgraded windows")
        , WIN_TRTMT_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having window treatment")
        , WIN_BAY_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having bay windows")
        , WIN_INSULATED_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having insulated windows")
        --, Todo: TRTMT     Window Treatments
      > OPTIONS(DESCRIPTION="Window Features")
    , DOOR STRUCT<
        STORM_DOOR_IND BOOLEAN OPTIONS(DESCRIPTION="Historical realtor comments or listed exterior features indicated home having storm doors.")
        , LAST_INSTL_DT_DOOR_EXTR DATE OPTIONS(DESCRIPTION="Exterior Door: Last THD completed installation.")
        , LAST_INSTL_DT_DOOR_PATIO DATE OPTIONS(DESCRIPTION="Patio Door: Last THD completed installations.")
        , LAST_INSTL_DT_DOOR_INTR DATE OPTIONS(DESCRIPTION="Interior Door: Last THD completed installation.")
      > OPTIONS(DESCRIPTION="Door Features")/*
    , STRG STRUCT<
      > OPTIONS(DESCRIPTION="Storage Features")  
    , PAINT STRUCT<
        --, Todo: 
      > OPTIONS(DESCRIPTION="Paint Features")
    , TOOL STRUCT<
        -- Todo: Lawn Mower
      > OPTIONS(DESCRIPTION="Tool Features (in most cases, only if purchaser still lives at property)")
    , DCR STRUCT<
        -- Todo: 
      > OPTIONS(DESCRIPTION="Decor Features (in most cases, only if purchaser still lives at property)")
    , WTHR STRUCT<
        -- Todo: Flood Risk
        -- Todo: Fire Risk
        -- Todo: Hurricane Risk
        -- Todo: Tornado Risk
        -- Todo: Earthquake Risk
        -- Todo: Hurricane Events
        -- Todo: Flood Events
        -- Todo: Tornado Events
        -- Todo: Earthquake events
      > OPTIONS(DESCRIPTION="Weather Features - Risks and Major Events")
    , AREA STRUCT<
        --THDSTR
        -- Todo: TSI
        -- Todo: Census
        -- Todo: HUD Income 
      > OPTIONS(DESCRIPTION="Area Features - Census, HUD, THD / Competitors")
    , ID STRUCT<
        -- Todo: HH
        -- Todo: Census
      > OPTIONS(DESCRIPTION="GeoIDs / HH")
    , RES STRUCT<
      > OPTIONS(DESCRIPTION="Resident Behavior & Demographics Features")*/
    
    
    
    )
  OPTIONS(
    DESCRIPTION="""
      Historical attributes and features of a property address.
      Atomic Level: CLIP # & Effective Dates
      """
  ) AS
WITH
  t01 AS
    ( SELECT CLIP, EFF_BGN_DT
      FROM `analytics-mkt-analytics-thd.hf_pr.thd_instl_pctgry2`
      GROUP BY 1, 2
      UNION DISTINCT
      SELECT CLIP, EFF_BGN_DT
      FROM `analytics-mkt-analytics-thd.hf_pr.thd_prod_dd_pctgry2`
      GROUP BY 1, 2
      UNION DISTINCT
      SELECT CLIP, EFF_BGN_DT
      FROM `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_tax2`
      GROUP BY 1, 2
      UNION DISTINCT
      SELECT CLIP, EFF_BGN_DT
      FROM `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_deed2`
      GROUP BY 1, 2
      UNION DISTINCT
      SELECT CLIP, EFF_BGN_DT
      FROM `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_lien2`
      GROUP BY 1, 2
      UNION DISTINCT
      SELECT CLIP, EFF_BGN_DT
      FROM `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_list2`
      GROUP BY 1, 2
    )
  , t02 AS
    ( SELECT 
        CLIP
        , EFF_BGN_DT
        , COALESCE(
            LEAD(EFF_BGN_DT) OVER(PARTITION BY CLIP ORDER BY EFF_BGN_DT)
          , DATE('9999-12-31')
        ) EFF_END_DT
      FROM t01
      GROUP BY 1, 2
    )
  , t03 AS 
    ( SELECT
        A.*
        , UPPER(H.DESCR2) AS LAND_USE_TYP
        , UPPER(H.DESCR) AS LAND_USE_DESC
        , UPPER(CASE
            WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) = '163'
              THEN 'Single Family Residence'
            WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) IN
              ('115', '165' ,'151', '102')
              THEN 'Townhouse/Other Attached Residence'
            WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) IN ('137', '138')
              THEN 'Manfactured Home'
            WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) = '106'
              THEN 'Apartment'
            WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) IN
              ('112', '117', '116', '113')
              THEN 'Condominium'
            WHEN H.DESCR2 = "Residential" THEN "Residential Other"
            WHEN COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) IS NOT NULL
              THEN "Other"
          END) AS DWLG_TYP
        , COALESCE(C.YR_BUILT, E.YR_BUILT) AS YR_BUILT
        , CASE WHEN E.RMDL_YR > COALESCE(C.YR_BUILT, E.YR_BUILT)
          THEN E.RMDL_YR END AS REMOD_YR
        , C.LVG_SQFT AS LVNG_SQFT
        , UPPER(H2.DESCR) AS BLDG_TYP
        , UPPER(H8.DESCR) AS BLDG_COND
        , UPPER(H4.DESCR) AS BLDG_QUAL
        , UPPER(H5.DESCR) AS EXTR_WALL_TYP
        , C.STRY_NBRS
        , CASE WHEN STORM_ROOM_IND 
          OR F.STORM IS NOT NULL
          THEN TRUE END AS STORM_ROOM_IND
        , C.BEDRM_CNT
        , B.SALE_DT
        , B.SALE_AMT
        , COALESCE(B.OWNR_OCC_IND, D.OWNR_OCC_IND) AS OWNR_OCPD_IND
        , B.INV_PRCH_IND AS INVSTR_PRCH_IND
        , D.HOME_VAL
        , D.HOME_EQUITY AS HOME_EQTY
        , D.LTV AS MRTG_LTV
        , D.NUM_LIENS AS NBR_LIENS
        , D.TOT_MRTG_AMT
        , D.TOT_MRTG_CURR_BAL
        , E.ON_MKT_IND
        -- Number of days currently on market (if on market)
        , CASE WHEN E.ON_MKT_IND IS TRUE
            THEN DATE_DIFF(CURRENT_DATE, E.ORIG_LIST_DT, DAY)
          END AS ON_MKT_DAYS
        -- Number of days off market (if off market)
        , CASE WHEN E.ON_MKT_IND IS FALSE
            THEN DATE_DIFF(CURRENT_DATE, E.OFF_MKT_DT, DAY)
          END AS OFF_MKT_DAYS -- you will see nulls for inserted props
        --, E.CURR_OFF_MKT_DAYS
        , E.LIST_RENT_IND
        , C.ACRES
        , C.POOL_IND
        , PATIO_IND
        , DECK_IND
        , BALCONY_IND
        , PORCH_IND
        , BBQ_AREA_IND
        , FIREPIT_IND
        , CASE WHEN SHED_IND IS TRUE 
          OR F.SHED IS NOT NULL
          THEN TRUE END AS SHED_IND
        , CASE WHEN F.PRGL IS NOT NULL 
          THEN TRUE END AS PERGOLA_IND
        , CASE WHEN F.GZBO IS NOT NULL 
          THEN TRUE END AS GAZEBO_IND
        , IRRIGATION_IND AS IRRIG_IND
        , NULLIF(UPPER(SPLIT(E.FENCE, ': ')[SAFE_OFFSET(1)]), 'UNKNOWN') AS FENCE_TYP
        --, Todo: Roof Type
        --, Todo: Last Roof Update
        --, Todo: Lawn
        --, Todo: Garden
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ LAST_KIT_UPD_DT
                  , CAST(CONCAT(
                      CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                      , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                          = EXTRACT(YEAR FROM CURRENT_DATE) 
                        THEN '-01-01' ELSE '-12-31' END
                    ) AS DATE)
                  -- Todo: Add THD Installs
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                ]) X
          ) AS LAST_KIT_UPD_DT
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ CNTR_UPD_DT
                  , CAST(CONCAT(
                      CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                      , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                          = EXTRACT(YEAR FROM CURRENT_DATE) 
                        THEN '-01-01' ELSE '-12-31' END
                    ) AS DATE)
                  -- Todo: Add THD Installs
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                ]) X
          ) AS LAST_CTOP_UPD_DT 
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ CBNT_UPD_DT
                  , CAST(CONCAT(
                      CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                      , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                          = EXTRACT(YEAR FROM CURRENT_DATE) 
                        THEN '-01-01' ELSE '-12-31' END
                    ) AS DATE)
                  -- Todo: Add THD Installs
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                ]) X
          ) AS LAST_CAB_UPD_DT
        -- Hardwood
        , CASE WHEN FLR_WOOD_IND 
          OR F.WOOD IS NOT NULL
          THEN TRUE 
        END AS FLR_WOOD_IND
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ FLR_WOOD_UPD_DT
                  , F.WOOD
                  , CASE WHEN FLR_WOOD_IND
                      THEN 
                        CAST(CONCAT(
                          CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                          , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                              = EXTRACT(YEAR FROM CURRENT_DATE) 
                            THEN '-01-01' ELSE '-12-31' END
                        ) AS DATE)
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                    END
                ]) X
          ) AS LAST_FLR_WOOD_UPD_DT
        -- Carpet
        , CASE WHEN FLR_CRPT_IND IS TRUE 
            OR F.CRPT IS NOT NULL
          THEN TRUE 
          END AS FLR_CRPT_IND
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ FLR_CRPT_UPD_DT
                  , F.CRPT
                  , CASE WHEN FLR_CRPT_IND
                      THEN 
                        CAST(CONCAT(
                          CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                          , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                              = EXTRACT(YEAR FROM CURRENT_DATE) 
                            THEN '-01-01' ELSE '-12-31' END
                        ) AS DATE)
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                    END
                ]) X
          ) AS LAST_FLR_CRPT_UPD_DT
        -- Vinyl / Vinyl Plank
        , CASE WHEN FLR_VINYL_IND IS TRUE 
            OR F.VINYL IS NOT NULL
          THEN TRUE 
          END AS FLR_VINYL_IND
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ FLR_VINYL_UPD_DT
                  , F.VINYL
                  , CASE WHEN FLR_VINYL_IND
                      THEN 
                        CAST(CONCAT(
                          CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                          , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                              = EXTRACT(YEAR FROM CURRENT_DATE) 
                            THEN '-01-01' ELSE '-12-31' END
                        ) AS DATE)
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                    END
                ]) X
          ) AS LAST_FLR_VINYL_UPD_DT
        -- Tile
        , CASE WHEN FLR_TILE_IND IS TRUE 
            OR F.TILE IS NOT NULL
          THEN TRUE 
          END AS FLR_TILE_IND
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ FLR_TILE_UPD_DT
                  , F.TILE
                  , CASE WHEN FLR_TILE_IND
                      THEN 
                        CAST(CONCAT(
                          CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                          , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                              = EXTRACT(YEAR FROM CURRENT_DATE) 
                            THEN '-01-01' ELSE '-12-31' END
                        ) AS DATE)
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                    END
                ]) X
          ) AS LAST_FLR_TILE_UPD_DT
        -- Laminate
        , CASE WHEN FLR_LAMINATE_IND IS TRUE 
            OR F.LAM IS NOT NULL
          THEN TRUE 
          END AS FLR_LAM_IND
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ FLR_LAMINATE_UPD_DT
                  , F.LAM
                  , CASE WHEN FLR_LAMINATE_IND
                      THEN 
                        CAST(CONCAT(
                          CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                          , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                              = EXTRACT(YEAR FROM CURRENT_DATE) 
                            THEN '-01-01' ELSE '-12-31' END
                        ) AS DATE)
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                    END
                ]) X
          ) AS LAST_FLR_LAM_UPD_DT
        , C.FULL_BATH_CNT
        , C.HALF_BATH_CNT
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ LAST_BATH_UPD_DT
                  , CAST(CONCAT(
                      CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                      , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                          = EXTRACT(YEAR FROM CURRENT_DATE) 
                        THEN '-01-01' ELSE '-12-31' END
                    ) AS DATE)
                  -- Todo: Add THD Installs
                  -- Todo: Add Realtor Comments
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                ]) X
          ) AS LAST_BATH_UPD_DT
        , CASE
            WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)CARPORT|COVERED')
              THEN 'CARPORT'
            WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)attached|BASEMENT|BUILT IN')
              THEN 'ATTACHED'
            WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)DETACHED|SALT BOX|PREFAB')
              THEN 'DETACHED'
            WHEN E.GRG_ATTACHED_IND THEN 'ATTACHED'
            WHEN E.GRG_DETACHED_IND THEN 'DETACHED'
            WHEN E.GRG_CARPORT_IND THEN 'CARPORT'
            WHEN H3.DESCR IS NOT NULL OR E.GRG_IND THEN 'OTHER'
          END AS GRG_TYP
        , CASE
            WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)(^| )finished') THEN FALSE
            WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)unfinished') THEN TRUE
            WHEN E.GRG_UNFINISHED_IND IS TRUE THEN TRUE
          END AS GRG_FINSH_IND
        , COALESCE(C.GRG_PRKG_SQFT, E.GRG_AREA) AS GRG_SQFT
        , CASE
            WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)(^| |-)1 CAR') THEN "1"
            WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)(^| |-)2 CAR') THEN "2"
            WHEN REGEXP_CONTAINS(H3.DESCR, '(?i)(^| |-)3 CAR') THEN "3+"
            WHEN E.GRG_1CAR_IND THEN "1"
            WHEN E.GRG_2CAR_IND THEN "2"
            WHEN E.GRG_3CARPLUS_IND THEN "3+"
            WHEN E.GRG_SPACES = 1 THEN "1"
            WHEN E.GRG_SPACES < 3 THEN "2"
            WHEN E.GRG_SPACES > 2 THEN "3+"
          END AS GRG_SPCS
        , GRG_DOOR_OPENER_IND
        , GRG_CABINETS_IND AS GRG_CAB_IND
        , GRG_STORAGE_IND AS GRG_STRG_IND
        , COALESCE(H7.DESCR, H6.DESCR) AS BSMT_TYP
        , BSMT_SQFT
        , CASE
            WHEN REGEXP_CONTAINS(H6.DESCR, '(?i)(^| )finished')
              OR REGEXP_CONTAINS(H7.DESCR, '(?i)(^| )finished')
              THEN 'FINISHED'
            WHEN REGEXP_CONTAINS(H6.DESCR, '(?i)PARTIALLY')
              THEN 'PARTIALLY FINISHED'
            WHEN REGEXP_CONTAINS(H6.DESCR, '(?i)(^| )unfinished')
              OR REGEXP_CONTAINS(H7.DESCR, '(?i)(^| )unfinished')
              OR UNFNSHD_BSMT_IND
              THEN 'UNFINISHED'
          END AS BSMT_FNSH_CLASS
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ F.WHTR
                  , CAST(CONCAT(
                      CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                      , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                          = EXTRACT(YEAR FROM CURRENT_DATE) 
                        THEN '-01-01' ELSE '-12-31' END
                    ) AS DATE)
                  -- Todo: Add Realtor Comments
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                ]) X
          ) AS LAST_INSTL_DT_WHTR
        --, todo: water pump
        --, todo: Septic tank
        --, todo: WFLTR   Water Filter (Whole House)
        , C.FRPLC_IND
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ F.HVAC
                  , CAST(CONCAT(
                      CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                      , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                          = EXTRACT(YEAR FROM CURRENT_DATE) 
                        THEN '-01-01' ELSE '-12-31' END
                    ) AS DATE)
                  -- Todo: Add Realtor Comments
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                ]) X
          ) AS LAST_INSTL_DT_HVAC
        -- Todo: Portable AC
        -- Todo: Portable Heater
        -- Todo: Attic Fans
        -- Todo: Whole House Fans
        -- Todo: Insulation?
        -- Todo: Heat Pump?
        , SOLAR_IND/*
        , STRUCT(
            --, Todo: 
          ) AS SMRTHM*/
        -- Todo: ELEC PANL    Electric Panel
        , F.BTTRY AS LAST_INSTL_DT_BTTRY
        , F.GNRTR AS LAST_INSTL_DT_GNRTR
        -- Todo: RADON MTGN   Radon Mitigation 
        -- Todo: LGHT         Lighting
        , G.FRDG AS LAST_ORD_DT_FRDG
        , G.FRZR AS LAST_ORD_DT_FRZR
        --, Todo: dishwasher
        , G.WASH AS LAST_ORD_DT_WASH
        , G.DRY AS LAST_ORD_DT_DRY
        --, Todo: cooktop
        --, Todo: microwave
        --, Todo: GRBGE DSPSL garbage disposal
        --, Todo: FRZR	freezer
        , STORM_WNDW_IND AS STORM_WIN_IND
        , STORM_SHUTT_IND
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ WNDW_UPD_DT
                  , CAST(CONCAT(
                      CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                      , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                          = EXTRACT(YEAR FROM CURRENT_DATE) 
                        THEN '-01-01' ELSE '-12-31' END
                    ) AS DATE)
                  -- Todo: Add THD Installs
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                ]) X
          ) AS LAST_WIN_UPD_DT
        , WNDW_TRTMNT_IND AS WIN_TRTMT_IND
        , WNDW_BAY_IND AS WIN_BAY_IND
        , WNDW_INSULATED_IND AS WIN_INSULATED_IND
        , CASE WHEN STORM_DOOR_IND IS TRUE
          OR F.DOOR_STRM IS NOT NULL
          THEN TRUE END AS STORM_DOOR_IND
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ F.DOOR_EXTR
                  , CAST(CONCAT(
                      CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                      , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                          = EXTRACT(YEAR FROM CURRENT_DATE) 
                        THEN '-01-01' ELSE '-12-31' END
                    ) AS DATE)
                  -- Todo: Add Realtor Comments?
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                ]) X
          ) AS LAST_INSTL_DT_DOOR_EXTR
        , F.DOOR_PATIO AS LAST_INSTL_DT_DOOR_PATIO
        , ( SELECT MAX(CASE WHEN X <= CURRENT_DATE THEN X END)
            FROM UNNEST(
                [ F.DOOR_INTR
                  , CAST(CONCAT(
                      CAST(COALESCE(C.YR_BUILT, E.YR_BUILT) AS STRING)
                      , CASE WHEN COALESCE(C.YR_BUILT, E.YR_BUILT) 
                          = EXTRACT(YEAR FROM CURRENT_DATE) 
                        THEN '-01-01' ELSE '-12-31' END
                    ) AS DATE)
                  -- Todo: Add Realtor Comments?
                  -- Todo: Add Building Permits
                  -- Todo: Add Assumed DIY Install
                ]) X
          ) AS LAST_INSTL_DT_DOOR_INTR
        --, Todo: STRG.*
        --, Todo: PAINT.*
        -- Todo: TOOL.*
        --, Todo: Lawn Mowers
        --, Todo: DCR.*
        --, Todo: WTHR.*
        -- Todo: Flood Risk
        -- Todo: Fire Risk
        -- Todo: Hurricane Risk
        -- Todo: Tornado Risk
        -- Todo: Earthquake Risk
        -- Todo: Hurricane Events
        -- Todo: Flood Events
        -- Todo: Tornado Events
        -- Todo: Earthquake events
        -- Todo: AREA.*
        -- Closest THD store (euclidean)
        -- Todo: TSI
        -- Todo: Census
        -- Todo: HUD Income 
        -- Todo: ID.*
        -- Todo: HH
        -- Todo: Census
        -- Todo: RES.*
      FROM t02 A
      LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_deed2` B
        ON A.CLIP = B.CLIP
          AND A.EFF_BGN_DT BETWEEN B.EFF_BGN_DT AND B.EFF_END_DT
      LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_tax2` C
        ON A.CLIP = C.CLIP
          AND A.EFF_BGN_DT BETWEEN C.EFF_BGN_DT AND C.EFF_END_DT
      LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_lien2` D
        ON A.CLIP = D.CLIP
          AND A.EFF_BGN_DT BETWEEN D.EFF_BGN_DT AND D.EFF_END_DT
      LEFT JOIN `analytics-mkt-analytics-thd.hf_dev.stg_cpnt_list2` E
        ON A.CLIP = E.CLIP
          AND A.EFF_BGN_DT BETWEEN E.EFF_BGN_DT AND E.EFF_END_DT
      LEFT JOIN `analytics-mkt-analytics-thd.hf_pr.thd_instl_pctgry2` F
        ON A.CLIP = F.CLIP
          AND A.EFF_BGN_DT BETWEEN F.EFF_BGN_DT AND F.EFF_END_DT
      LEFT JOIN `analytics-mkt-analytics-thd.hf_pr.thd_prod_dd_pctgry2` G
        ON A.CLIP = G.CLIP
          AND A.EFF_BGN_DT BETWEEN G.EFF_BGN_DT AND G.EFF_END_DT
      LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H
        ON COALESCE(C.LAND_USE_CD, B.LAND_USE_CD) = H.CODE
          AND H.TBL = 'OLB' AND H.COL = 'LAND_USE_CD'
      LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H2
        ON C.BLDG_CD = H2.CODE
          AND H2.TBL = 'OLB' AND H2.COL = 'BLDG'
      LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H3
        ON C.GRG_CD = H3.CODE
          AND H3.TBL = 'OLB' AND H3.COL = 'GARAGE_CD'
      LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H4
        ON C.BLDG_QUAL_CD = H4.CODE
          AND H4.TBL = 'OLB' AND H4.COL = 'BLDG_QUAL_CD'
      LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H5
        ON C.EXTR_WALL_CD = H5.CODE
          AND H5.TBL = 'OLB' AND H5.COL = 'EXTR_WALL_CD'
      LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H6
        ON C.BSMT_FINSH_CD = H6.CODE
          AND H6.TBL = 'OLB' AND H6.COL = 'BSMT_FNSH_CD'
      LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H7
        ON C.BSMT_TYP_CD = H7.CODE
          AND H7.TBL = 'OLB' AND H7.COL = 'BSMT_TYPE_CD'
      LEFT JOIN `analytics-views-thd.GEO.cl_cd_xref` H8
        ON C.COND_CD = H8.CODE
          AND H8.TBL = 'OLB' AND H8.COL = 'COND_CD'
      WHERE A.EFF_END_DT >= CURRENT_DATE-1095
    )
  , t04 AS 
    ( SELECT 
        A.* EXCEPT(EFF_BGN_DT, EFF_END_DT)
        , `analytics-views-thd.GEO.udf_mrg_intvls`(
            ARRAY_AGG(
              STRUCT(
                UNIX_MILLIS(TIMESTAMP(EFF_BGN_DT)) AS intervalStart
                , UNIX_MILLIS(TIMESTAMP(EFF_END_DT)) AS intervalEnd
              )
            ) ) AS intervals
      FROM t03 A
      GROUP BY 
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10
        , 11, 12, 13, 14, 15, 16, 17, 18, 19, 20
        , 21, 22, 23, 24, 25, 26, 27, 28, 29, 30
        , 31, 32, 33, 34, 35, 36, 37, 38, 39, 40
        , 41, 42, 43, 44, 45, 46, 47, 48, 49, 50
        , 51, 52, 53, 54, 55, 56, 57, 58, 59, 60
        , 61, 62, 63, 64, 65, 66, 67, 68, 69, 70
        , 71, 72, 73, 74, 75, 76, 77, 78, 79, 80
        , 81, 82, 83, 84, 85, 86, 87
    )
SELECT
  CLIP
  , CAST(TIMESTAMP_MILLIS(i.intervalStart) AS DATE) EFF_BGN_DT
  , CASE WHEN
      CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE) = '9999-12-31'
      THEN CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE)
      ELSE DATE_SUB( CAST(TIMESTAMP_MILLIS(i.intervalEnd) AS DATE), INTERVAL 1 DAY)
      END EFF_END_DT
  , STRUCT(
      LAND_USE_TYP, LAND_USE_DESC, DWLG_TYP, YR_BUILT, REMOD_YR
      , LVNG_SQFT, BLDG_TYP, BLDG_COND, BLDG_QUAL, EXTR_WALL_TYP
      , STRY_NBRS, STORM_ROOM_IND, BEDRM_CNT
    ) BLDG
  , STRUCT(
      SALE_DT, SALE_AMT, OWNR_OCPD_IND, INVSTR_PRCH_IND
    ) SALE
  , STRUCT(
      HOME_VAL, HOME_EQTY, MRTG_LTV, NBR_LIENS, TOT_MRTG_AMT
      , TOT_MRTG_CURR_BAL
    ) MRTG
  , STRUCT(
      ON_MKT_IND, ON_MKT_DAYS, OFF_MKT_DAYS, LIST_RENT_IND
    ) LIST
  , STRUCT(
      ACRES, POOL_IND, PATIO_IND, DECK_IND, BALCONY_IND, PORCH_IND
      , BBQ_AREA_IND, FIREPIT_IND, SHED_IND, PERGOLA_IND, GAZEBO_IND
      , IRRIG_IND, FENCE_TYP
      --, Todo: Roof Type
      --, Todo: Last Roof Update
      --, Todo: Lawn
      --, Todo: Garden
    ) OUTDR
  , STRUCT(
      LAST_KIT_UPD_DT, LAST_CTOP_UPD_DT, LAST_CAB_UPD_DT
    ) KIT
  , STRUCT(
      FLR_WOOD_IND, LAST_FLR_WOOD_UPD_DT
      , FLR_CRPT_IND, LAST_FLR_CRPT_UPD_DT
      , FLR_VINYL_IND, LAST_FLR_VINYL_UPD_DT
      , FLR_TILE_IND, LAST_FLR_TILE_UPD_DT
      , FLR_LAM_IND, LAST_FLR_LAM_UPD_DT
    ) FLR
  , STRUCT(
      FULL_BATH_CNT, HALF_BATH_CNT, LAST_BATH_UPD_DT
    ) BATH
  , STRUCT(
      GRG_TYP, GRG_FINSH_IND, GRG_SQFT, GRG_SPCS
      , GRG_DOOR_OPENER_IND, GRG_CAB_IND, GRG_STRG_IND
    ) AS GRG
  , STRUCT(
      BSMT_TYP, BSMT_SQFT, BSMT_FNSH_CLASS
    ) AS BSMT
  , STRUCT(
      LAST_INSTL_DT_WHTR
      --, todo: water pump
      --, todo: Septic tank
      --, todo: WFLTR   Water Filter (Whole House)
    ) PLMB
  , STRUCT(
      FRPLC_IND
      , LAST_INSTL_DT_HVAC
      -- Todo: Portable AC
      -- Todo: Portable Heater
      -- Todo: Attic Fans
      -- Todo: Whole House Fans
      -- Todo: Insulation?
      -- Todo: Heat Pump?
    ) HVAC
  , STRUCT(
      SOLAR_IND/*
      , STRUCT(
          --, Todo: 
        ) AS SMRTHM*/
      -- Todo: ELEC PANL    Electric Panel
      , LAST_INSTL_DT_BTTRY
      , LAST_INSTL_DT_GNRTR
      -- Todo: RADON MTGN   Radon Mitigation 
      -- Todo: LGHT         Lighting
    ) ELEC
  , STRUCT(
      LAST_ORD_DT_FRDG
      , LAST_ORD_DT_FRZR
      --, Todo: dishwasher
      , LAST_ORD_DT_WASH
      , LAST_ORD_DT_DRY
      --, Todo: cooktop
      --, Todo: microwave
      --, Todo: GRBGE DSPSL garbage disposal
      --, Todo: FRZR	freezer
    ) APLNC
  , STRUCT(
      STORM_WIN_IND, STORM_SHUTT_IND, LAST_WIN_UPD_DT
      , WIN_TRTMT_IND, WIN_BAY_IND, WIN_INSULATED_IND
    ) WIN
  , STRUCT(
      STORM_DOOR_IND, LAST_INSTL_DT_DOOR_EXTR, LAST_INSTL_DT_DOOR_PATIO
      , LAST_INSTL_DT_DOOR_INTR
    ) DOOR
FROM
  t04 A
  , UNNEST(intervals) i
;