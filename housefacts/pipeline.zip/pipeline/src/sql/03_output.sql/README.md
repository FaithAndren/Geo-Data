# HouseFacts Output Data


* **Property HouseFacts** (`housefacts`):
  Final HouseFacts output data with components in structs.

* **Property to Household ID** (`prop_std_hh_xref`):
  Mapping standardized parent property to THD's household ID to enable
  linking data to campaigns that are based on `THD_HH_ID`. This will be
  a table that we allow external access to across the enterprise.

***
